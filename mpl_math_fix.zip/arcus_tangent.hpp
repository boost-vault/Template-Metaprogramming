// Copyright (C) 2005 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_ARCUS_TANGENT_HPP_INCLUDED
#define BOOST_MPL_MATH_ARCUS_TANGENT_HPP_INCLUDED

/*
 * Defines the BOOST_MPL_CFG_NO_NESTED_FORWARDING macro.
 */
#include <boost/mpl/aux_/config/forwarding.hpp>

/*
 * Defines the BOOST_MPL_AUX_LAMBDA_SUPPORT macro.
 */
#include <boost/mpl/aux_/lambda_support.hpp>

/*
 * Defines the boost::mpl::apply2 metafunction.
 */
#include <boost/mpl/apply.hpp>

/*
 * Defines the boost::mpl::eval_if metafunction.
 */
#include <boost/mpl/eval_if.hpp>

/*
 * Defines the boost::mpl::tag metafunction.
 */
#include <boost/mpl/tag.hpp>

/*
 * Defines the boost::mpl::int_ numeric metatype.
 */
#include <boost/mpl/int.hpp>

/*
 * Defines the boost::mpl::less numeric metafunction.
 */
#include <boost/mpl/less.hpp>

/*
 * Defines the boost::mpl::plus, boost::mpl::minus, boost::mpl::times, and
 * boost::mpl::divides numeric metafunctions.
 */
#include <boost/mpl/arithmetic.hpp>

namespace boost { namespace mpl { namespace math {
    template <typename NumericTag>
    struct arcus_tangent_impl
    {
        /*
         * Compile-time Taylor series.
         */
        template <
            typename Arg
          , typename I
          , typename SeriesCount
        >
        struct series
        {
         private:
            typedef typename eval_if<
                    less<I,SeriesCount>
                    , series<Arg,typename I::next,SeriesCount>
                    , int_<1>
                    >::type
                    next_term;
            BOOST_STATIC_CONSTANT(int,coefficient1=(2*I::value));
            BOOST_STATIC_CONSTANT(int,coefficient2=(2*I::value+1));
         public:
            typedef typename plus<
                        int_<1>,
                        divides<
                            times<
                                int_<coefficient1>,
                                Arg,
                                next_term
                            >,
                            int_<coefficient2>
                        >
                    >::type type;
        };

        template <typename Arg>
        struct initial_arg {
            typedef typename times<Arg,Arg>::type arg_square;
            typedef typename divides<Arg,plus<int_<1>,arg_square> >::type init;
            typedef typename times<init,Arg>::type arg;
        };

        template <
            typename Arg
          , typename SeriesCount
        >
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
            : times<
                typename initial_arg<Arg>::init,
                typename series<
                    typename initial_arg<Arg>::arg,
                    int_<1>,
                    SeriesCount
                >::type
            >
        {
#else
        {
            /*
             * Metafunction class return type.
             */
            typedef typename times<
                typename initial_arg<Arg>::init,
                typename series<
                    typename initial_arg<Arg>::arg,
                    int_<1>,
                    SeriesCount
                >::type
            >::type type;
#endif  /* BOOST_MPL_CFG_NO_NESTED_FORWARDING */
        };
    };

    template <
        typename Arg
      , typename SeriesCount = int_<12>
    >
    struct arcus_tangent
      : apply2<
            arcus_tangent_impl<typename tag<Arg>::type>
          , Arg
          , SeriesCount
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , arcus_tangent
          , (Arg,SeriesCount)
        )
    };
}}}  // namespace boost::mpl::math

#endif  /* BOOST_MPL_MATH_ARCUS_TANGENT_HPP_INCLUDED */
