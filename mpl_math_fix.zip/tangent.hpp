// Copyright (C) 2005 Cromwell D. Enage
// Copyright (C) 2005 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_TANGENT_HPP_INCLUDED
#define BOOST_MPL_MATH_TANGENT_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_TANGENT_SERIES
#define BOOST_MPL_LIMIT_MATH_TANGENT_SERIES 8
#endif

/*
 * Defines the BOOST_MPL_CFG_NO_NESTED_FORWARDING macro.
 */
#include <boost/mpl/aux_/config/forwarding.hpp>

/*
 * Defines the BOOST_MPL_AUX_LAMBDA_SUPPORT macro.
 */
#include <boost/mpl/aux_/lambda_support.hpp>

/*
 * Defines the boost::mpl::apply2 metafunction.
 */
#include <boost/mpl/apply.hpp>

/*
 * Defines the boost::mpl::tag metafunction.
 */
#include <boost/mpl/tag.hpp>

/*
 * Defines the boost::mpl::int_ numeric metatype.
 */
#include <boost/mpl/int.hpp>

/*
 * Defines the boost::mpl::divides numeric metafunction.
 */
#include <boost/mpl/divides.hpp>

/*
 * Defines the boost::mpl::minus numeric metafunction.
 */
#include <boost/mpl/minus.hpp>

#define BOOST_MPL_MATH_TANGENT_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        typedef typename minus< \
                    int_<1+(BOOST_MPL_LIMIT_MATH_TANGENT_SERIES-x-1)*2> \
                  , divides< \
                        angle_squared \
                      , BOOST_PP_CAT(prefix, x) \
                    > \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct tangent_impl
    {
        /*
         * Continued fraction representation (http://functions.wolfram.com/ElementaryFunctions/Tan/10)
         */
        template <typename Angle>
        struct apply
        {
         private:
            typedef typename times<Angle,Angle>::type
                    angle_squared;
            typedef int_<1>
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_TANGENT_SERIES
              , BOOST_MPL_MATH_TANGENT_MACRO
              , term_
            )
                    last_term;
         public:

            /*
             * Metafunction class return type.
             */
            typedef typename divides<Angle,last_term>::type
                    type;
        };
    };

    template <typename Angle>
    struct tangent
      : apply1<
            tangent_impl<typename tag<Angle>::type>
          , Angle
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            1
          , tangent
          , (Angle)
        )
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_LIMIT_MATH_TANGENT_SERIES
#undef BOOST_MPL_MATH_TANGENT_MACRO

#endif  /* BOOST_MPL_MATH_TANGENT_HPP_INCLUDED */
