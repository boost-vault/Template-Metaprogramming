// Copyright (C) 2005 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_ARCUS_SINE_HPP_INCLUDED
#define BOOST_MPL_MATH_ARCUS_SINE_HPP_INCLUDED

/*
 * Defines the BOOST_MPL_CFG_NO_NESTED_FORWARDING macro.
 */
#include <boost/mpl/aux_/config/forwarding.hpp>

/*
 * Defines the BOOST_MPL_AUX_LAMBDA_SUPPORT macro.
 */
#include <boost/mpl/aux_/lambda_support.hpp>

/*
 * Defines the boost::mpl::apply2 metafunction.
 */
#include <boost/mpl/apply.hpp>

/*
 * Defines the boost::mpl::eval_if metafunction.
 */
#include <boost/mpl/eval_if.hpp>

/*
 * Defines the boost::mpl::tag metafunction.
 */
#include <boost/mpl/tag.hpp>

/*
 * Defines the boost::mpl::int_ numeric metatype.
 */
#include <boost/mpl/int.hpp>

/*
 * Defines the boost::mpl::less numeric metafunction.
 */
#include <boost/mpl/less.hpp>

/*
 * Defines the boost::mpl::plus, boost::mpl::minus, boost::mpl::times, and
 * boost::mpl::divides numeric metafunctions.
 */
#include <boost/mpl/arithmetic.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct arcus_sine_impl
    {
        /*
         * Compile-time Taylor series.
         */
        template <
            typename ArgSquare
          , typename I
          , typename SeriesCount
        >
        struct series
        {
         private:
            typedef typename eval_if<
                    less<I,SeriesCount>
                    , series<ArgSquare,typename I::next,SeriesCount>
                    , int_<0>
                    >::type
                    next_term;
            BOOST_STATIC_CONSTANT(int,coefficient1=(2*I::value+1));
            BOOST_STATIC_CONSTANT(int,coefficient2=2*(I::value+1));
         public:
            typedef typename divides<
                        plus<
                            int_<coefficient2>,
                            times<
                                int_<coefficient1*coefficient1>,
                                ArgSquare,
                                next_term
                            >
                        >,
                        int_<coefficient1*coefficient2>
                    >::type type;
        };

        template <
            typename Arg
          , typename SeriesCount
        >
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : times<Arg,typename series<times<Arg,Arg>,int_<0>,SeriesCount>::type>
        {
#else
        {
            /*
             * Metafunction class return type.
             */
            typedef typename times<
                        Arg
                      , typename series<times<Arg,Arg>,int_<0>,SeriesCount>::type
                    >::type
                    type;
#endif  /* BOOST_MPL_CFG_NO_NESTED_FORWARDING */
        };
    };

    template <
        typename Arg
      , typename SeriesCount = int_<12>
    >
    struct arcus_sine
      : apply2<
            arcus_sine_impl<typename tag<Arg>::type>
          , Arg
          , SeriesCount
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , arcus_sine
          , (Arg,SeriesCount)
        )
    };
}}}  // namespace boost::mpl::math

#endif  /* BOOST_MPL_MATH_ARCUS_SINE_HPP_INCLUDED */
