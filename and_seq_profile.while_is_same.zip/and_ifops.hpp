#define AND_IFOPS_IS_SAME
#ifdef AND_IFOPS_IS_SAME
#include <boost/type_traits/is_same.hpp>
#else
#include <boost/mpl/equal.hpp>
#endif
#include <boost/mpl/next.hpp>
#include <boost/mpl/deref.hpp>
#include <boost/mpl/eval_if.hpp>

namespace boost
{
namespace mpl
{
  template
  < class IterEnd
  >
struct and_ifops
{
      template
      < class IterNow
      >
    struct then_
    : next<IterNow>
    {
    };
    
      template
      < class IterNow
      >
    struct if_
    {
            typedef typename
        #ifdef AND_IFOPS_IS_SAME
          is_same
        #else
          equal
        #endif
          < IterNow
          , IterEnd
          >::type
        is_empty
        ;
            typedef typename
          mpl::eval_if
          < is_empty
          , false_
          , deref<IterNow>
          >::type
        type
        ;
    };
    
};

}//exit mpl namespace
}//exit boost namespace
