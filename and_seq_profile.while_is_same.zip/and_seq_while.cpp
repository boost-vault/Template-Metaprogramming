
#include <and_ifops.hpp>
#include <while.hpp>
#include <boost/mpl/begin_end.hpp>
/* Calculate the mpl::and_ of a sequence of nullary logical metafunctions.*/    
template <typename Seq>
struct and_seq 
  {
          typedef typename
        boost::mpl::end<Seq>::type
      end_seq
      ;
          typedef typename
        boost::mpl::while_
        < typename boost::mpl::begin<Seq>
        , boost::mpl::and_ifops<end_seq>
        >::type
      end_state
      ;
          typedef typename
      #ifdef AND_IFOPS_IS_SAME
        boost::is_same
      #else
        boost::mpl::equal
      #endif
        < end_seq
        , end_state
        >::type
      type
      ;
    
  };
  
#include <and_seq_instances.hpp>
