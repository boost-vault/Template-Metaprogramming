// Copyright Larry Evans 2009
//
#include <boost/mpl/eval_if.hpp>
namespace boost
{
namespace mpl
{
      template
      < class State
      , class IfOps
      >
    struct while_
    : eval_if
      < typename IfOps::template if_<typename State::type>::type
      , while_
        < typename IfOps::template then_<typename State::type>
        , IfOps
        >
      , State
      >
    {
    };
    
}//exit mpl namespace
}//exit boost namespace
