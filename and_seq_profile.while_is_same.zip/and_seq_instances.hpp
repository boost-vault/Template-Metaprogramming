#include <boost/mpl/vector.hpp>
    typedef
  boost::mpl::vector3
  < boost::mpl::true_
  , boost::mpl::true_
  , boost::mpl::true_
  >
and_true3_seq
;
    typedef
  and_seq<and_true3_seq>
and_seq_true3
;
    typedef
  and_seq_true3::type
and_true3_result
;

#ifdef DO_MPL_ASSERT
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
  //#define DO_WHILE_DEBUG
  #ifndef DO_WHILE_DEBUG
    MPL_ASSERT(( and_true3_result ));
  #else
    typedef boost::mpl::begin<and_true3_seq> then0;
    typedef boost::mpl::end<and_true3_seq>::type end_seq;
    typedef boost::mpl::and_ifops<end_seq> ifops;
    typedef ifops::then_<then0::type> then1;
    typedef ifops::then_<then1::type> then2;
    typedef ifops::then_<then2::type> then3;
    typedef ifops::if_<then3::type> if3;
    typedef and_seq_true3::end_while end_while;
    MPL_ASSERT    (( is_same<and_seq_true3::end_seq,end_seq> ));
    MPL_ASSERT_NOT(( is_same<then0::type,end_seq> ));
    MPL_ASSERT    ((         then0::type          ));
    MPL_ASSERT_NOT(( is_same<then1::type,end_seq> ));
    MPL_ASSERT    ((         then1::type          ));
    MPL_ASSERT_NOT(( is_same<then2::type,end_seq> ));
    MPL_ASSERT    ((         then2::type          ));
    MPL_ASSERT    (( is_same<then3::type,end_seq> ));
    MPL_ASSERT    ((           if3::is_empty      ));
    MPL_ASSERT_NOT((           if3::type          ));
        typedef 
      boost::mpl::eval_if
      < if3::type
      , false_
      , then3
      >::type
    eval_if3;
//    MPL_ASSERT    (( then3 ));
    MPL_ASSERT    (( is_same<eval_if3,end_seq>    ));
    //MPL_ASSERT    (( is_same<end_while::type,void_*> ));
  #endif
}
#endif
