#ifndef CPP_METAPROG_CHAP7_EXERCISE8_CROSS_NPRODUCT_VIEW_HPP
#define CPP_METAPROG_CHAP7_EXERCISE8_CROSS_NPRODUCT_VIEW_HPP
//solution to excercise 7.8 using transform_view
//but for n>1 sequences instead of just n==2 sequences.
#include <boost/mpl/transform_view.hpp>
#include <boost/mpl/single_view.hpp>
#include <boost/mpl/joint_view.hpp>
#include <boost/mpl/list.hpp>
#include <boost/mpl/push_front.hpp>
#include <boost/mpl/fold.hpp>
#include <boost/mpl/empty_sequence.hpp>

namespace boost{namespace mpl{

  template<class Row, class Column>
  struct
row_column_view
: list<Row,Column>
{
    typedef row_column_view type;
    typedef list<Row,Column> super_type;
};
  template<class Row, class Row0, class Column>
  struct
row_column_view
  < Row
  , row_column_view<Row0,Column>
  >
: push_front
  <   typename
    row_column_view
    < Row0
    , Column
    >::super_type
  , Row
  >::type
{
    typedef row_column_view type;
        typedef
        typename
      push_front
      <   typename
        row_column_view
        < Row0
        , Column
        >::super_type
      , Row
      >::type
    super_type
    ;
};

  template<class Row, class Columns>
  struct
row_view
: transform_view<Columns,row_column_view<Row, arg<1> > >
{
};

  template<class Rows, class Columns>
  struct
cross_product_view
: fold
  < transform_view
    < Rows
    , row_view<arg<1>, Columns> 
    >
  , empty_sequence
  , joint_view
    < arg<2>
    , arg<1>
    >
  >::type
{
    typedef cross_product_view type;
};

struct construct_product_one
/**@brief
 *  one element for cross_product, i.e.
 *  cross_product<X,construct_product_one> == X
 */
{};
  template<class Domain>
  struct
cross_product_view
  < Domain, construct_product_one>
{
    typedef Domain type;
};
  template<class Domain>
  struct
cross_product_view
  < construct_product_one, Domain>
{
    typedef Domain type;
};

struct cross_product_zero
/**@brief
 *  zero element for cross_product, i.e.
 *  cross_product<X,cross_product_zero> == cross_product_zero
 */
{};
  template<class Domain>
  struct
cross_product_view
  < Domain, cross_product_zero>
{
    typedef cross_product_zero type;
};
  template<class Domain>
  struct
cross_product_view
  < cross_product_zero, Domain>
{
    typedef cross_product_zero type;
};

  template
  < class Domains
  >
  struct
cross_nproduct_view
  : fold
    < Domains
    , construct_product_one
    , cross_product_view<arg<2>,arg<1> >
    >::type
{
};

}}//exit boost::mpl namespace
#endif
