#define INDENT_PRINT
#ifdef INDENT_PRINT
#include <boost/utility/trace_scope.hpp>
#else
#include <iostream>
typedef std::ostream marg_ostream;
static marg_ostream& mout(){ return std::cout;}
void operator++(marg_ostream&){}
void operator--(marg_ostream&){}
namespace utility
{
    struct trace_scope
    {
        trace_scope(char const*)
        {}
    };
}
#endif

#include "cross_nproduct_view.hpp"

#include <boost/mpl/for_each.hpp>
#include <boost/mpl/size.hpp>

namespace boost{namespace mpl{

struct cross_product_print
{
    struct print_element_delim
    /**@brief
     *  Print's sequence element with
     *  delimiters and indentation.
     */
    {
        typedef print_element_delim my_type;
        
        print_element_delim(cross_product_print const& a_pt)
        : my_pt(a_pt)
        , my_count(0)
        {}
        
        template<class Element>
        void operator()(Element const& a_elem)
        {
            if(my_count==0)
            {
                mout()<<"{ ";
            }
            else
            {
                mout()<<", ";
            }
            ++my_count;
            ++mout();
            my_pt(a_elem);
            --mout();
        }
        
        template<class Seq>
        static void _(cross_product_print const& a_pt)
        {
            print_element_delim pe(a_pt);
            for_each<Seq>(pe);
            mout()<<"}\n";
        }
     private:
        cross_product_print const& my_pt;
        unsigned my_count;
    };

    template<class Other>
    void operator()(Other const& a_other)const
    {
        mout()<<a_other<<"\n";
    }
    template<class Row, class Col>
    void operator()(row_column_view<Row,Col>const& a_arg)const
    {
        typedef typename row_column_view<Row,Col>::super_type seq_type;
        mout()<<"row_column_view\n";
        mout()<<"size="<<size<seq_type>::type::value<<"\n";
        print_element_delim::_<seq_type>(*this);
    }
    template<class Rows, class Cols>
    void operator()(cross_product_view<Rows,Cols> const& a_arg)const
    {
        mout()<<"cross_product_view<Rows,Cols>\n";
        typedef cross_product_view<Rows,Cols> seq_type;
        print_element_delim::_<seq_type>(*this);
    }
    template<class Domains>
    void operator()(cross_nproduct_view<Domains> const& a_arg)const
    {
        mout()<<"cross_nproduct_view<Domains>\n";
        typedef cross_nproduct_view<Domains> seq_type;
        print_element_delim::_<seq_type>(*this);
    }
    
    template<class Seq>
    static void _(void)
    {
        cross_product_print pt;
        Seq s;
        pt(s);
    }
};
}}//exit boost::mpl namespace

#include <boost/mpl/range_c.hpp>

  template
  < int Value
  >
  marg_ostream&
operator<<
  ( marg_ostream& sout
  , boost::mpl::integral_c<int,Value>
  )
{
    sout<<Value;
    return sout;
}    

namespace boost{namespace mpl{

typedef range_c<int,0,2> seq0;
typedef range_c<int,100,102> seq1;
typedef range_c<int,2000,2002> seq2;

void test_product(void)
{
#if 0 
    ::utility::trace_scope ts("test_product");
    typedef cross_product_view<seq0,seq1> type;
    cross_product_print::_<type>();
#endif
}

void test_2product(void)
{
#if 0
    ::utility::trace_scope ts("test_2product");
    typedef cross_nproduct_view<list<seq0,seq1> > type01;
    cross_product_print::_<type01>();
    {
        ::utility::trace_scope ts("test_23product");
        typedef cross_product_view<seq2,type01> type201;
        cross_product_print::_<type201>();
    }
#endif
}

void test_3(void)
{
#if 1
    ::utility::trace_scope ts("test3");
  #define LOCAL_3
  #ifdef LOCAL_3
    typedef range_c<int,    0,    1> seq0;
    typedef range_c<int,  100,  102> seq1;
    typedef range_c<int, 2000, 2002> seq2;
    typedef range_c<int,30000,30003> seq3;
        typedef 
      list
      < seq0
      , seq1
      , seq2
      , seq3
      > 
    domains;
  #else
        typedef 
      list
      < seq0
      , seq1
      , seq2
      > 
    domains;
  #endif
    typedef cross_nproduct_view<domains> type;
    unsigned const size_type=size<type>::type::value;
    mout()<<"size_type="<<size_type<<"\n";
    cross_product_print::_<type>();
#endif
}

}}//exit boost::mpl namespace

int
main(int argc, char* argv[])
{
    using namespace boost::mpl;
    test_product();
    test_2product();
    test_3();
    return 0;
}
