// Copyright (C) 2005 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_TRIBOOL_TAG_HPP_INCLUDED
#define BOOST_MPL_TRIBOOL_TAG_HPP_INCLUDED

/*
 * Defines the boost::mpl::int_ numeric metatype.
 */
#include <boost/mpl/int.hpp>

namespace boost {
  namespace mpl {

    struct tribool_tag : public int_<-8>
    {
    };
  }  // namespace mpl
}  // namespace boost

#endif  /* BOOST_MPL_TRIBOOL_TAG_HPP_INCLUDED */
