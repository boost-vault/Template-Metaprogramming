// Copyright (C) 2005 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_TRIBOOL_HPP_INCLUDED
#define BOOST_MPL_TRIBOOL_HPP_INCLUDED

/*
 * Defines the workaround macros for ill-conforming compilers.
 */
#include <boost/config.hpp>

/*
 * Defines the BOOST_MPL_CFG_NO_NESTED_FORWARDING macro.
 */
#include <boost/mpl/aux_/config/forwarding.hpp>

/*
 * Defines the BOOST_WORKAROUND macro.
 */
#include <boost/mpl/aux_/config/workaround.hpp>

/*
 * Defines the BOOST_MPL_AUX_SELF_TYPEDEF macro.
 */
#include <boost/mpl/aux_/self_typedef.hpp>

/*
 * Defines the boost::mpl::if_ metafunction.
 */
#include <boost/mpl/if.hpp>

/*
 * Defines the boost::mpl::eval_if metafunction.
 */
#include <boost/mpl/eval_if.hpp>

/*
 * Defines the boost::mpl::true_ and boost::mpl::false_ numeric metaconstants.
 */
#include <boost/mpl/bool.hpp>

/*
 * Defines the boost::mpl::integral_c numeric metatype and the
 * boost::mpl::tribool_tag and boost::mpl::integral_c_tag numeric tags.
 */
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/tribool_tag.hpp>

/*
 * Declares the boost::mpl::false_tribool, boost::mpl::true_tribool, and
 * boost::mpl::indeterminate_tribool logical metaconstants.
 */
#include <boost/mpl/tribool_fwd.hpp>

/*
 * Defines the BOOST_MPL_AUX_NUMERIC_CAST numeric metafunction class.
 */
#include <boost/mpl/numeric_cast.hpp>

/*
 * Defines the boost::mpl::equal_to and boost::mpl::not_equal_to logical
 * metafunctions and the boost::mpl::equal_to_impl, and
 * boost::mpl::not_equal_to_impl logical metafunction classes.
 */
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>

/*
 * Defines the boost::mpl::and_, boost::mpl::or_, and boost::mpl::not_ logical
 * metafunctions.
 */
#include <boost/mpl/logical.hpp>

/*
 * Defines the boost::is_same metafunction.
 */
#include <boost/type_traits/is_same.hpp>

/*
 * Defines the boost::is_base_of metafunction.
 */
#include <boost/type_traits/is_base_of.hpp>

/*
 * Defines the boost::mpl::runtime_value_impl metafunction class.
 */
#include <boost/mpl/runtime_value.hpp>

/*
 * Defines the boost::logic::tribool class and the
 * boost::logic::indeterminate keyword.
 */
#include <boost/logic/tribool.hpp>

namespace boost { namespace mpl {

    struct false_tribool
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(false_tribool)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef tribool_tag
                tag;

        /*
         * Runtime value type.
         */
        typedef boost::logic::tribool
                value_type;

        /*
         * Runtime value.
         */
        operator value_type() const
        {
            return value_type(false);
        }
    };

    struct true_tribool
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(true_tribool)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef tribool_tag
                tag;

        /*
         * Runtime value type.
         */
        typedef boost::logic::tribool
                value_type;

        /*
         * Runtime value.
         */
        operator value_type() const
        {
            return value_type(true);
        }
    };

    struct indeterminate_tribool
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(indeterminate_tribool)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef tribool_tag
                tag;

        /*
         * Runtime value type.
         */
        typedef boost::logic::tribool
                value_type;

        /*
         * Runtime value.
         */
        operator value_type() const
        {
            return value_type(boost::logic::indeterminate);
        }
    };

    /*
     * Semantics are parallel to that of safe_bool().
     */
    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<tribool_tag,integral_c_tag>
    {
        template <typename T>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : if_<
                typename if_<
                    is_same<true_tribool,T>
                  , true_
                  , is_base_of<true_tribool,T>
                >::type
              , true_
              , false_
            >
        {
#else
        {
            /*
             * Metafunction class return type.
             */
            typedef typename if_<
                        typename if_<
                            is_same<true_tribool,T>
                          , true_
                          , is_base_of<true_tribool,T>
                        >::type
                      , true_
                      , false_
                    >::type
                    type;
#endif  /* BOOST_MPL_CFG_NO_NESTED_FORWARDING */
        };
    };

  namespace tribool_ {

    template <typename T1, typename T2>
    struct equal_to_helper
      : eval_if<
            typename if_<
                is_same<true_tribool,T1>
              , true_
              , is_base_of<true_tribool,T1>
            >::type
          , if_<
                or_<
                    is_same<true_tribool,T2>
                  , is_base_of<true_tribool,T2>
                >
              , true_tribool
              , false_tribool
            >
          , if_<
                or_<
                    is_same<false_tribool,T2>
                  , is_base_of<false_tribool,T2>
                >
              , true_tribool
              , false_tribool
            >
        >::type
    {
    };
  }  // namespace tribool_

    template <>
    struct equal_to_impl<tribool_tag,tribool_tag>
    {
        template <typename T1, typename T2>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                typename if_<
                    typename if_<
                        is_same<indeterminate_tribool,T1>
                      , true_
                      , is_base_of<indeterminate_tribool,T1>
                    >::type
                  , true_
                  , or_<
                        is_same<indeterminate_tribool,T2>
                      , is_base_of<indeterminate_tribool,T2>
                    >
                >::type
              , indeterminate_tribool
              , tribool_::equal_to_helper<T1,T2>
            >
        {
#else
        {
            /*
             * Metafunction class return type.
             */
            typedef typename eval_if<
                        typename if_<
                            typename if_<
                                is_same<indeterminate_tribool,T1>
                              , true_
                              , is_base_of<indeterminate_tribool,T1>
                            >::type
                          , true_
                          , or_<
                                is_same<indeterminate_tribool,T2>
                              , is_base_of<indeterminate_tribool,T2>
                            >
                        >::type
                      , indeterminate_tribool
                      , tribool_::equal_to_helper<T1,T2>
                    >::type
                    type;
#endif  /* BOOST_MPL_CFG_NO_NESTED_FORWARDING */
        };
    };

  namespace tribool_ {

    template <typename T1, typename T2>
    struct not_equal_to_helper
      : eval_if<
            typename if_<
                is_same<true_tribool,T1>
              , true_
              , is_base_of<true_tribool,T1>
            >::type
          , if_<
                or_<
                    is_same<false_tribool,T2>
                  , is_base_of<false_tribool,T2>
                >
              , true_tribool
              , false_tribool
            >
          , if_<
                or_<
                    is_same<true_tribool,T2>
                  , is_base_of<true_tribool,T2>
                >
              , true_tribool
              , false_tribool
            >
        >::type
    {
    };
  }  // namespace tribool_

    template <>
    struct not_equal_to_impl<tribool_tag,tribool_tag>
    {
        template <typename T1, typename T2>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                typename if_<
                    typename if_<
                        is_same<indeterminate_tribool,T1>
                      , true_
                      , is_base_of<indeterminate_tribool,T1>
                    >::type
                  , true_
                  , or_<
                        is_same<indeterminate_tribool,T2>
                      , is_base_of<indeterminate_tribool,T2>
                    >
                >::type
              , indeterminate_tribool
              , tribool_::not_equal_to_helper<T1,T2>
            >
        {
#else
        {
            /*
             * Metafunction class return type.
             */
            typedef typename eval_if<
                        typename if_<
                            typename if_<
                                is_same<indeterminate_tribool,T1>
                              , true_
                              , is_base_of<indeterminate_tribool,T1>
                            >::type
                          , true_
                          , or_<
                                is_same<indeterminate_tribool,T2>
                              , is_base_of<indeterminate_tribool,T2>
                            >
                        >::type
                      , indeterminate_tribool
                      , tribool_::not_equal_to_helper<T1,T2>
                    >::type
                    type;
#endif  /* BOOST_MPL_CFG_NO_NESTED_FORWARDING */
        };
    };

    /*
     * Currently none of the following logical metafunctions are forwarded from
     * *_impl specializations.  For now, neither nested invocations nor lambda
     * expressions involving these metafunctions will work with tribools.  Also,
     * and_ and or_ have an arity that is, by default, greater than two, so
     * we're not even close to enumerating the results of all possible
     * combinations.
     */

    template <>
    struct and_<false_tribool,false_tribool>
      : false_tribool
    {
    };

    template <>
    struct and_<false_tribool,true_tribool>
      : false_tribool
    {
    };

    template <>
    struct and_<false_tribool,indeterminate_tribool>
      : false_tribool
    {
    };

    template <>
    struct and_<false_tribool,false_>
      : false_
    {
    };

    template <>
    struct and_<false_tribool,true_>
      : false_
    {
    };

    template <>
    struct and_<true_tribool,false_tribool>
      : false_tribool
    {
    };

    template <>
    struct and_<true_tribool,true_tribool>
      : true_tribool
    {
    };

    template <>
    struct and_<true_tribool,indeterminate_tribool>
      : indeterminate_tribool
    {
    };

    template <>
    struct and_<true_tribool,false_>
      : false_
    {
    };

    template <>
    struct and_<true_tribool,true_>
      : true_
    {
    };

    template <>
    struct and_<indeterminate_tribool,false_tribool>
      : false_tribool
    {
    };

    template <>
    struct and_<indeterminate_tribool,true_tribool>
      : indeterminate_tribool
    {
    };

    template <>
    struct and_<indeterminate_tribool,indeterminate_tribool>
      : indeterminate_tribool
    {
    };

    template <>
    struct and_<indeterminate_tribool,false_>
      : false_
    {
    };

    template <>
    struct and_<indeterminate_tribool,true_>
      : false_
    {
    };

    template <>
    struct and_<false_,false_tribool>
      : false_
    {
    };

    template <>
    struct and_<false_,true_tribool>
      : false_
    {
    };

    template <>
    struct and_<false_,indeterminate_tribool>
      : false_
    {
    };

    template <>
    struct and_<true_,false_tribool>
      : false_
    {
    };

    template <>
    struct and_<true_,true_tribool>
      : true_
    {
    };

    template <>
    struct and_<true_,indeterminate_tribool>
      : false_
    {
    };

    template <>
    struct or_<false_tribool,false_tribool>
      : false_tribool
    {
    };

    template <>
    struct or_<false_tribool,true_tribool>
      : true_tribool
    {
    };

    template <>
    struct or_<false_tribool,indeterminate_tribool>
      : indeterminate_tribool
    {
    };

    template <>
    struct or_<false_tribool,false_>
      : false_
    {
    };

    template <>
    struct or_<false_tribool,true_>
      : true_
    {
    };

    template <>
    struct or_<true_tribool,false_tribool>
      : true_tribool
    {
    };

    template <>
    struct or_<true_tribool,true_tribool>
      : true_tribool
    {
    };

    template <>
    struct or_<true_tribool,indeterminate_tribool>
      : true_tribool
    {
    };

    template <>
    struct or_<true_tribool,false_>
      : true_
    {
    };

    template <>
    struct or_<true_tribool,true_>
      : true_
    {
    };

    template <>
    struct or_<indeterminate_tribool,false_tribool>
      : indeterminate_tribool
    {
    };

    template <>
    struct or_<indeterminate_tribool,true_tribool>
      : true_tribool
    {
    };

    template <>
    struct or_<indeterminate_tribool,indeterminate_tribool>
      : indeterminate_tribool
    {
    };

    template <>
    struct or_<indeterminate_tribool,false_>
      : false_
    {
    };

    template <>
    struct or_<indeterminate_tribool,true_>
      : true_
    {
    };

    template <>
    struct or_<false_,false_tribool>
      : false_
    {
    };

    template <>
    struct or_<false_,true_tribool>
      : true_
    {
    };

    template <>
    struct or_<false_,indeterminate_tribool>
      : false_
    {
    };

    template <>
    struct or_<true_,false_tribool>
      : true_
    {
    };

    template <>
    struct or_<true_,true_tribool>
      : true_
    {
    };

    template <>
    struct or_<true_,indeterminate_tribool>
      : true_
    {
    };

    template <>
    struct not_<false_tribool>
      : true_tribool
    {
    };

    template <>
    struct not_<true_tribool>
      : false_tribool
    {
    };

    template <>
    struct not_<indeterminate_tribool>
      : indeterminate_tribool
    {
    };

  namespace tribool_ {

    /*
     * By default, we assume that ResultType is constructible from bool.
     */
    template <typename ResultType>
    struct runtime_value_helper
    {
        static ResultType eval(const boost::logic::tribool& b)
        {
            bool safe_b = b;

            return ResultType(safe_b);
        }
    };

    template <>
    struct runtime_value_helper<const boost::logic::tribool&>
    {
        static const boost::logic::tribool& eval(const boost::logic::tribool& b)
        {
            return b;
        }
    };

    template <>
    struct runtime_value_helper<bool>
    {
        static bool eval(const boost::logic::tribool& b)
        {
            bool safe_b = b;

            return safe_b;
        }
    };
  }  // namespace tribool_

    template <>
    struct runtime_value_impl<tribool_tag>
    {
        template <typename ResultType>
        struct apply
        {
            BOOST_MPL_AUX_SELF_TYPEDEF(apply)

            template <typename T>
            static ResultType eval(const T& b)
            {
                return tribool_::runtime_value_helper<ResultType>::eval(T());
            }
        };
    };
}}  // namespace boost::mpl

#endif  /* BOOST_MPL_TRIBOOL_HPP_INCLUDED */
