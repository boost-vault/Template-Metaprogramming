// Copyright (C) 2005 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

/*
 * Defines the std::ostream class and std::cout, its global instance.
 */
#include <iostream>

/*
 * Defines the std::boolalpha I/O manipulator.
 */
#include <iomanip>

/*
 * Defines the boost::mpl::false_tribool, boost::mpl::true_tribool, and
 * boost::mpl::indeterminate_tribool logical metaconstants.
 */
#include <boost/mpl/tribool.hpp>

/*
 * Defines the boost::mpl::equal_to and boost::mpl::not_equal_to logical
 * metafunctions.
 */
#include <boost/mpl/comparison.hpp>

/*
 * Defines the boost::mpl::and_, boost::mpl::or_, and boost::mpl::not_ logical
 * metafunctions.
 */
#include <boost/mpl/logical.hpp>

/*
 * Defines the boost::mpl::runtime_value unary function struct template.
 */
#include <boost/mpl/runtime_value.hpp>

/*
 * Defines the boost::logic::tribool class.
 */
#include <boost/logic/tribool.hpp>

/*
 * Defines the interaction between std::ostream and boost::logic::tribool.
 */
#include <boost/logic/tribool_io.hpp>

int main()
{
    boost::mpl::runtime_value<const boost::logic::tribool&> tribool_value;

    std::cout << std::boolalpha;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::false_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::false_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::false_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::true_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::true_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::true_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::indeterminate_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::indeterminate_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "==";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::equal_to<
                boost::mpl::indeterminate_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::false_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::false_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::false_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::true_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::true_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::true_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::indeterminate_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::indeterminate_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "!=";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_equal_to<
                boost::mpl::indeterminate_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::false_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::false_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::false_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::true_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::true_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::true_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::indeterminate_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::indeterminate_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "&&";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::and_<
                boost::mpl::indeterminate_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::false_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::false_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::false_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::true_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::true_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::true_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::indeterminate_tribool
              , boost::mpl::false_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::indeterminate_tribool
              , boost::mpl::true_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << "||";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::or_<
                boost::mpl::indeterminate_tribool
              , boost::mpl::indeterminate_tribool
            >::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression !";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_<boost::mpl::false_tribool>::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression !";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_<boost::mpl::true_tribool>::type()
        ) << "." << std::endl;

    std::cout << "The triboolean expression !";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout <<
        tribool_value(
            boost::mpl::not_<boost::mpl::indeterminate_tribool>::type()
        ) << "." << std::endl;

    boost::mpl::runtime_value<bool> bool_value;

    std::cout << "The boolean value of the triboolean ";
    std::cout << tribool_value(boost::mpl::false_tribool()) << " is ";
    std::cout << bool_value(boost::mpl::false_tribool());
    std::cout << "." << std::endl;

    std::cout << "The boolean value of the triboolean ";
    std::cout << tribool_value(boost::mpl::true_tribool()) << " is ";
    std::cout << bool_value(boost::mpl::true_tribool());
    std::cout << "." << std::endl;

    std::cout << "The boolean value of the triboolean ";
    std::cout << tribool_value(boost::mpl::indeterminate_tribool()) << " is ";
    std::cout << bool_value(boost::mpl::indeterminate_tribool());
    std::cout << "." << std::endl;

    return 0;
}
