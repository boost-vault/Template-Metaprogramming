// Copyright (C) 2005 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

/*
 * Defines the boost::mpl::true_ and boost::mpl::false_ logical metaconstants.
 */
#include <boost/mpl/bool.hpp>

/*
 * Defines the boost::mpl::false_tribool, boost::mpl::true_tribool, and
 * boost::mpl::indeterminate_tribool logical metaconstants.
 */
#include <boost/mpl/tribool.hpp>

/*
 * Defines the boost::mpl::equal_to and boost::mpl::not_equal_to logical
 * metafunctions.
 */
#include <boost/mpl/comparison.hpp>

/*
 * Defines the boost::mpl::and_, boost::mpl::or_, and boost::mpl::not_ logical
 * metafunctions.
 */
#include <boost/mpl/logical.hpp>

/*
 * Defines the boost::is_same metafunction.
 */
#include <boost/type_traits/is_same.hpp>

/*
 * Defines the MPL_TEST_CASE and MPL_ASSERT* macros.
 * Also pulls in the boost::mpl namespace.
 */
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    MPL_ASSERT((
        is_same<
            equal_to<false_tribool,false_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<false_tribool,true_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<false_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<false_tribool,false_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<false_tribool,true_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<true_tribool,false_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<true_tribool,true_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<true_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<true_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<true_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<indeterminate_tribool,false_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<indeterminate_tribool,true_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<indeterminate_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<indeterminate_tribool,false_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<indeterminate_tribool,true_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<false_,false_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<false_,true_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<false_,indeterminate_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<true_,false_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<true_,true_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<true_,indeterminate_tribool>::type
          , false_
        >
    ));
}

MPL_TEST_CASE()
{
    MPL_ASSERT((
        is_same<
            not_equal_to<false_tribool,false_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<false_tribool,true_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<false_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<false_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<false_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<true_tribool,false_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<true_tribool,true_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<true_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<true_tribool,false_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<true_tribool,true_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<indeterminate_tribool,false_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<indeterminate_tribool,true_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_equal_to<indeterminate_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<indeterminate_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<indeterminate_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<false_,false_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<false_,true_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<false_,indeterminate_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<true_,false_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            equal_to<true_,true_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            not_equal_to<true_,indeterminate_tribool>::type
          , true_
        >
    ));
}

MPL_TEST_CASE()
{
    MPL_ASSERT((
        is_same<
            and_<false_tribool,false_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<false_tribool,true_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<false_tribool,indeterminate_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<false_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<false_tribool,true_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<true_tribool,false_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<true_tribool,true_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<true_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<true_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<true_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<indeterminate_tribool,false_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<indeterminate_tribool,true_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            and_<indeterminate_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<indeterminate_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<indeterminate_tribool,true_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<false_,false_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<false_,true_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<false_,indeterminate_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<true_,false_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<true_,true_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            and_<true_,indeterminate_tribool>::type
          , false_
        >
    ));
}

MPL_TEST_CASE()
{
    MPL_ASSERT((
        is_same<
            or_<false_tribool,false_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<false_tribool,true_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<false_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<false_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<false_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<true_tribool,false_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<true_tribool,true_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<true_tribool,indeterminate_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<true_tribool,false_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<true_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<indeterminate_tribool,false_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<indeterminate_tribool,true_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            or_<indeterminate_tribool,indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<indeterminate_tribool,false_>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<indeterminate_tribool,true_>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<false_,false_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<false_,true_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<false_,indeterminate_tribool>::type
          , false_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<true_,false_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<true_,true_tribool>::type
          , true_
        >
    ));
    MPL_ASSERT((
        equal_to<
            or_<true_,indeterminate_tribool>::type
          , true_
        >
    ));
}

MPL_TEST_CASE()
{
    MPL_ASSERT((
        is_same<
            not_<false_tribool>::type
          , true_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_<true_tribool>::type
          , false_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            not_<indeterminate_tribool>::type
          , indeterminate_tribool
        >
    ));
    MPL_ASSERT((
        is_same<
            equal_to<
                not_equal_to<indeterminate_tribool,false_tribool>
              , true_tribool
            >::type
          , indeterminate_tribool
        >
    ));
}
