// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_AUX_CONFIG_ENDIAN_HPP_INCLUDED
#define BOOST_MPL_AUX_CONFIG_ENDIAN_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/mpl/aux_/config/workaround.hpp>

#if !defined(BOOST_MPL_CFG_IS_BIG_ENDIAN)

#if defined(sun) || defined(__sun) || defined(__sgi)  // Edit this.
#define BOOST_MPL_CFG_IS_BIG_ENDIAN
#endif  // Compiler detection

#endif  // BOOST_MPL_CFG_IS_BIG_ENDIAN

#endif  // BOOST_MPL_AUX_CONFIG_ENDIAN_HPP_INCLUDED

