// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_AUX_CONFIG_MATH_DOUBLE_HPP_INCLUDED
#define BOOST_MPL_AUX_CONFIG_MATH_DOUBLE_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/mpl/aux_/config/workaround.hpp>

#if !defined(BOOST_MPL_CFG_NO_MATH_DOUBLE_MACRO)

#if defined(__GNUC__) || !defined(BOOST_MSVC)
#define BOOST_MPL_CFG_NO_MATH_DOUBLE_MACRO
#endif  // Compiler detection

#endif  // BOOST_MPL_CFG_NO_MATH_DOUBLE_MACRO

#endif  // BOOST_MPL_AUX_CONFIG_MATH_DOUBLE_HPP_INCLUDED

