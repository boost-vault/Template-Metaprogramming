// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_AUX_SELF_TYPEDEF_HPP_INCLUDED
#define BOOST_MPL_AUX_SELF_TYPEDEF_HPP_INCLUDED

// workaround macros for ill-conforming compilers
#include <boost/config.hpp>
// BOOST_WORKAROUND
#include <boost/mpl/aux_/config/workaround.hpp>

/*
 * This macro assumes that all metafunctions are defined as "struct",
 * not "class".
 */
#if BOOST_WORKAROUND(__EDG_VERSION__, <= 238)
#define BOOST_MPL_AUX_SELF_TYPEDEF(name) typedef struct name type;
#else
#define BOOST_MPL_AUX_SELF_TYPEDEF(name) typedef name type;
#endif

#endif  // BOOST_MPL_AUX_SELF_TYPEDEF_HPP_INCLUDED

