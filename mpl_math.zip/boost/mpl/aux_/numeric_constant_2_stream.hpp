// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_AUX_NUMERIC_CONSTANT_2_STREAM_HPP_INCLUDED
#define BOOST_MPL_AUX_NUMERIC_CONSTANT_2_STREAM_HPP_INCLUDED

#include <boost/mpl/integral_c_tag.hpp>
#include <boost/mpl/math/double_tag.hpp>

namespace boost { namespace mpl { namespace aux {

    template <typename NumericTag>
    struct numeric_constant_2_stream
    {
        template <typename NumericConstant, typename OutputStream>
        static void extract(NumericConstant const& n, OutputStream& out)
        {
            NumericConstant::extract(out);
        }
    };

    template <>
    struct numeric_constant_2_stream<boost::mpl::math::double_tag>
    {
        template <typename IntegralConstant, typename OutputStream>
        static void extract(IntegralConstant const& n, OutputStream& out)
        {
            out << n;
        }
    };

    template <>
    struct numeric_constant_2_stream<integral_c_tag>
    {
        template <typename IntegralConstant, typename OutputStream>
        static void extract(IntegralConstant const& n, OutputStream& out)
        {
            out << IntegralConstant::value;
        }
    };
}}}  // namespace boost::mpl::aux

#endif  // BOOST_MPL_AUX_NUMERIC_CONSTANT_2_STREAM_HPP_INCLUDED

