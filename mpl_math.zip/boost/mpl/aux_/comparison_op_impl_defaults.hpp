// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_AUX_COMPARISON_OP_IMPL_DEFAULTS_HPP_INCLUDED
#define BOOST_MPL_AUX_COMPARISON_OP_IMPL_DEFAULTS_HPP_INCLUDED

#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/not.hpp>

/*
 * Convenience macro for defining metafunction class specializations of
 * boost::mpl::less_equal_impl, boost::mpl::greater_impl,
 * boost::mpl::greater_equal_impl, and boost::mpl::not_equal_impl
 * with respect to the tag type of main_type.
 *
 * Preconditions:
 * * The main_type##_tag numeric tag must be already defined.
 * * The boost::mpl::less metafunction must be already defined.
 * * This macro must be invoked from within the global namespace.
 */
#define BOOST_MPL_AUX_COMPARISON_OP_IMPL_DEFAULTS(main_type) \
namespace boost { namespace mpl { \
    template <> \
    struct less_equal_impl< \
        BOOST_PP_CAT(main_type,_tag) \
      , BOOST_PP_CAT(main_type,_tag) \
    > \
    { \
        template <typename N1, typename N2> \
        struct apply \
        { \
            typedef typename not_<less<N2,N1> >::type \
                    type; \
        }; \
    }; \
    template <> \
    struct greater_impl< \
        BOOST_PP_CAT(main_type,_tag) \
      , BOOST_PP_CAT(main_type,_tag) \
    > \
    { \
        template <typename N1, typename N2> \
        struct apply \
        { \
            typedef typename less<N2,N1>::type \
                    type; \
        }; \
    }; \
    template <> \
    struct greater_equal_impl< \
        BOOST_PP_CAT(main_type,_tag) \
      , BOOST_PP_CAT(main_type,_tag) \
    > \
    { \
        template <typename N1, typename N2> \
        struct apply \
        { \
            typedef typename not_<less<N1,N2> >::type \
                    type; \
        }; \
    }; \
    template <> \
    struct not_equal_to_impl< \
        BOOST_PP_CAT(main_type,_tag) \
      , BOOST_PP_CAT(main_type,_tag) \
    > \
    { \
        template <typename N1, typename N2> \
        struct apply \
        { \
            typedef typename not_<equal_to<N1,N2> >::type \
                    type; \
        }; \
    }; \
}} \
    /**/

#endif  // BOOST_MPL_AUX_COMPARISON_OP_IMPL_DEFAULTS_HPP_INCLUDED

