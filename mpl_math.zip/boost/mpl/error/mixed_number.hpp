// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_ERROR_MIXED_NUMBER_HPP_INCLUDED
#define BOOST_MPL_ERROR_MIXED_NUMBER_HPP_INCLUDED

namespace boost { namespace mpl { namespace error {

    /*
     * Leave member typedefs or static constants undefined to trigger a
     * compile-time error if a mixed_number_c or mixed_number is initialized
     * with a rational part whose denominator is less than zero.
     */
    struct negative_denominator
    {
    };

    /*
     * Leave member typedefs or static constants undefined to trigger a
     * compile-time error if a mixed_number_c or mixed_number is initialized
     * with a nonzero integral part and a negative fractional part.
     */
    struct nonzero_integral_part_negative_fractional_part
    {
    };

    /*
     * Leave member typedefs or static constants undefined to trigger a
     * compile-time error if a mixed_number_c or mixed_number is initialized
     * with a fractional part whose denominator is less than its numerator.
     */
    struct improper_fractional_part
    {
    };
}}}  // namespace boost::mpl::error

#endif  // BOOST_MPL_ERROR_MIXED_NUMBER_HPP_INCLUDED

