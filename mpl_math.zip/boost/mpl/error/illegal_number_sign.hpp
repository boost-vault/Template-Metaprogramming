// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_ERROR_ILLEGAL_NUMBER_SIGN_HPP_INCLUDED
#define BOOST_MPL_ERROR_ILLEGAL_NUMBER_SIGN_HPP_INCLUDED

namespace boost { namespace mpl { namespace error {

    /*
     * Leave member typedefs or static constants undefined to trigger
     * a compile-time error if neither '+' nor '-' are used.
     */
    struct illegal_number_sign
    {
    };
}}}  // namespace boost::mpl::error

#endif  /* BOOST_MPL_ERROR_ILLEGAL_NUMBER_SIGN_HPP_INCLUDED */

