// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_RUNTIME_CAST_HPP_INCLUDED
#define BOOST_MPL_RUNTIME_CAST_HPP_INCLUDED

#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/integral_c_tag.hpp>

namespace boost {
  namespace mpl {

    template <typename NumericTag>
    struct runtime_value_impl;

    template <>
    struct runtime_value_impl<integral_c_tag>
    {
        template <typename ResultType>
        struct apply
        {
            BOOST_MPL_AUX_SELF_TYPEDEF(apply)

            template <typename IntegralConstant>
            static ResultType eval(IntegralConstant const& n)
            {
                return static_cast<ResultType>(IntegralConstant::value);
            }
        };
    };

    template <typename ResultType, typename NumericConstant>
    ResultType runtime_cast(const NumericConstant& n)
    {
        typedef typename apply_wrap1<
                    runtime_value_impl<typename NumericConstant::tag>
                  , ResultType
                >::type
                impl_type;

        return impl_type::eval(n);
    }
  }  // namespace mpl
}  // namespace boost

#endif  // BOOST_MPL_RUNTIME_CAST_HPP_INCLUDED

