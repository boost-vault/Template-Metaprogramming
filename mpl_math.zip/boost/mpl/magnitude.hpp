// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MAGNITUDE_HPP_INCLUDED
#define BOOST_MPL_MAGNITUDE_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/tag.hpp>
#include <boost/mpl/is_numeric_constant.hpp>
#include <boost/mpl/math/abs.hpp>

namespace boost { namespace mpl {
  namespace aux {

    template <typename T>
    struct magnitude_default
    {
        typedef typename T::magnitude type;
    };
  }  // namespace aux

    template <typename Tag>
    struct magnitude_impl
    {
        template <typename T>
        struct apply
#ifndef BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_numeric_constant<T>
              , math::abs<T>
              , aux::magnitude_default<T>
            >
        {
#else
        {
            typedef typename eval_if<
                        is_numeric_constant<T>
                      , math::abs<T>
                      , aux::magnitude_default<T>
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename T>
    struct magnitude
      : apply_wrap1<magnitude_impl<typename tag<T>::type>,T>::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, magnitude, (T))
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MAGNITUDE_HPP_INCLUDED

