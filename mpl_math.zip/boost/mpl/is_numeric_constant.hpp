// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_IS_NUMERIC_CONSTANT_HPP_INCLUDED
#define BOOST_MPL_IS_NUMERIC_CONSTANT_HPP_INCLUDED

#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/tag.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/is_integral_constant.hpp>

namespace boost { namespace mpl {
  namespace aux {

    template <typename Tag>
    struct is_numeric_constant_tag
      : eval_if<
            is_integral_constant<Tag>
          , eval_if<boost::mpl::math::is_negative<Tag>,false_,true_>
          , false_
        >::type
    {
    };
  }  // namespace aux

    /*
     * Let INTEGRAL_CONSTANT be a model of Integral Constant (e.g. int_).
     * Let NUMERIC_CONSTANT be a model of Numeric Constant.
     *
     * NUMERIC_CONSTANT must follow this convention:
     *
     *     struct NUMERIC_CONSTANT_tag : public INTEGRAL_CONSTANT<TAG_VAL> {};
     *
     *     template <...>
     *     struct NUMERIC_CONSTANT
     *     {
     *         typedef NUMERIC_CONSTANT type;
     *         typedef NUMERIC_CONSTANT_tag tag;
     *         ...
     *     };
     *
     * where TAG_VAL is a positive integer.
     */
    template <typename T>
    struct is_numeric_constant
      : eval_if<
            aux::is_numeric_constant_tag<typename tag<T>::type>
          , true_
          , is_integral_constant<T>
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, is_numeric_constant, (T))
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_IS_NUMERIC_CONSTANT_HPP_INCLUDED

