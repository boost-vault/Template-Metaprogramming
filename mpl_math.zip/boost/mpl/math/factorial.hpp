// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_FACTORIAL_HPP_INCLUDED
#define BOOST_MPL_MATH_FACTORIAL_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/error/input_out_of_domain.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct factorial_impl
    {
        template <typename IntegralConstant>
        struct step
        {
         private:
            typedef typename prior<IntegralConstant>::type
                    n_minus_one;
            typedef typename eval_if<
                        is_zero<n_minus_one>
                      , IntegralConstant
                      , step<n_minus_one>
                    >::type
                    next_term;

         public:
            typedef typename times<IntegralConstant,next_term>::type
                    type;
        };

        template <typename IntegralConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_negative<IntegralConstant>
              , boost::mpl::error::input_out_of_domain
              , eval_if<
                    is_zero<IntegralConstant>
                  , next<IntegralConstant>
                  , step<IntegralConstant>
                >
            >
        {
#else
        {
            typedef typename eval_if<
                        is_negative<IntegralConstant>
                      , boost::mpl::error::input_out_of_domain
                      , eval_if<
                            is_zero<IntegralConstant>
                          , next<IntegralConstant>
                          , step<IntegralConstant>
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename IntegralConstant>
    struct factorial
      : apply_wrap1<
            factorial_impl<typename IntegralConstant::tag>
          , IntegralConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, factorial, (IntegralConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_FACTORIAL_HPP_INCLUDED

