// Copyright (C) 2005-2011 Peder Holt
// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_ARCUS_COSINE_HPP_INCLUDED
#define BOOST_MPL_MATH_ARCUS_COSINE_HPP_INCLUDED

#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/arcus_sine.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/pi_fwd.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericConstant>
    struct arcus_cosine
      : minus<
            divides<
                pi_dispatch<typename NumericConstant::tag>
              , two_dispatch<typename NumericConstant::tag>
            >
          , arcus_sine<NumericConstant>
        >
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, arcus_cosine, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_ARCUS_COSINE_HPP_INCLUDED

