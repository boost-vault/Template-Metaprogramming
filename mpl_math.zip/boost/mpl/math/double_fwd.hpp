// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_FWD_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/preprocessor/repetition/enum_params_with_a_default.hpp>

namespace boost { namespace mpl { namespace math {

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t Value>
#else
    template <typename IntType, IntType Value>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct integral_c_to_double;

    template <typename IntegralConstant>
    struct integral_to_double;

    template <long Value>
    struct long_to_double;

    template <
        BOOST_PP_ENUM_PARAMS_WITH_A_DEFAULT(40, unsigned char a, 0xff)
    >
    struct string_c_to_double;
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_FWD_HPP_INCLUDED

