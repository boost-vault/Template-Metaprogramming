// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_SIMPLIFIED_RATIONAL_C_HPP_INCLUDED
#define BOOST_MPL_MATH_SIMPLIFIED_RATIONAL_C_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/simplified_rational_c_fwd.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/rational.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * Each template instance encapsulates a Rational Constant.
     */
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t N, boost::intmax_t D>
#else
    template <typename IntType, IntType N, IntType D>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct simplified_rational_c
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(simplified_rational_c)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef rational_c_tag tag;

        /*
         * The relevant parts of a Rational Constant.
         */
        typedef boost::rational<IntType> value_type;
        typedef IntType int_type;

#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
        enum {num = N, den = D};
#else
        static const int_type num = N;
        static const int_type den = D;
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

        operator value_type() const
        {
            return value_type(num, den);
        }
    };
}}}  // namespace boost::mpl::math

/*
 * Operator overload for outputting simplified_rational_c instances
 * using an output stream.  NOT FOR BITSHIFTING!
 */
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
template <
    typename OutputStream
  , typename IntType
  , boost::intmax_t N
  , boost::intmax_t D
>
#else
template <typename OutputStream, typename IntType, IntType N, IntType D>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
inline OutputStream& operator<<(
    OutputStream& out
  , boost::mpl::math::simplified_rational_c<IntType,N,D> const& r
)
{
    return out << boost::rational<IntType>(N,D);
}

#endif  // BOOST_MPL_MATH_SIMPLIFIED_RATIONAL_C_HPP_INCLUDED

