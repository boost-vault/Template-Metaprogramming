// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RECIPROCAL_HPP_INCLUDED
#define BOOST_MPL_MATH_RECIPROCAL_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/numeric_cast.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/error/zero_divisor.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct reciprocal_impl
    {
        template <typename NumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_zero<NumericConstant>
              , boost::mpl::error::zero_divisor
              , divides<int_<1>,NumericConstant>
            >
        {
#else
        {
            typedef typename eval_if<
                        is_zero<NumericConstant>
                      , boost::mpl::error::zero_divisor
                      , divides<int_<1>,NumericConstant>
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename NumericTag, typename IntegralConstant>
    struct reciprocal_integral
      : apply_wrap1<
            reciprocal_impl<NumericTag>
          , typename apply_wrap1<
                BOOST_MPL_AUX_NUMERIC_CAST<
                    typename IntegralConstant::tag
                  , NumericTag
                >
              , IntegralConstant
            >::type
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , reciprocal_integral
          , (NumericTag,IntegralConstant)
        )
    };

    template <typename NumericConstant>
    struct reciprocal
      : apply_wrap1<
            reciprocal_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, reciprocal, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RECIPROCAL_HPP_INCLUDED

