// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_NUMERATOR_HPP_INCLUDED
#define BOOST_MPL_MATH_NUMERATOR_HPP_INCLUDED

#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/math/numerator_fwd.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * By default, assume that NumericConstant is an Integral Constant.
     */
    template <typename NumericTag>
    struct numerator_impl
    {
        template <typename NumericConstant>
        struct apply
        {
            typedef NumericConstant type;
        };
    };

    template <typename NumericConstant>
    struct numerator
      : apply_wrap1<
            numerator_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, numerator, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_NUMERATOR_HPP_INCLUDED

