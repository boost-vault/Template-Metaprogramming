// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_E_HPP_INCLUDED
#define BOOST_MPL_MATH_E_HPP_INCLUDED

#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/math/e_fwd.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct e_dispatch
      : exponential<typename one_dispatch<NumericTag>::type>::type
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_E_HPP_INCLUDED

