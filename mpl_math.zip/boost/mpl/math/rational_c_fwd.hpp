// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_FWD_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * The default second argument enables explicit conversion
     * from an Integral Constant to a Rational Constant.
     */
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t N, boost::intmax_t D = 1>
#else
    template <typename IntType, IntType N, IntType D = 1>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct rational_c;
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_FWD_HPP_INCLUDED

