// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_LCM_HPP_INCLUDED
#define BOOST_MPL_MATH_LCM_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/config/eti.hpp>
#include <boost/mpl/aux_/msvc_eti_base.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/gcd.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag1, typename NumericTag2>
    struct lcm_impl
    {
        template <typename NumericConstant1, typename NumericConstant2>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_zero<NumericConstant1>
              , NumericConstant1
              , eval_if<
                    is_zero<NumericConstant2>
                  , NumericConstant2
                  , times<
                        divides<
                            NumericConstant1
                          , gcd<NumericConstant1,NumericConstant2>
                        >
                      , NumericConstant2
                    >
                >
            >
        {
#else
        {
            typedef typename eval_if<
                        is_zero<NumericConstant1>
                      , NumericConstant1
                      , eval_if<
                            is_zero<NumericConstant2>
                          , NumericConstant2
                          , times<
                                divides<
                                    NumericConstant1
                                  , gcd<NumericConstant1,NumericConstant2>
                                >
                              , NumericConstant2
                            >
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename NumericConstant1, typename NumericConstant2>
    struct lcm
#if !defined(BOOST_MPL_CFG_MSVC_ETI_BUG)
      : lcm_impl<
            typename NumericConstant1::tag
          , typename NumericConstant2::tag
        >::BOOST_NESTED_TEMPLATE apply<NumericConstant1,NumericConstant2>::type
#else
      : boost::mpl::aux::msvc_eti_base<
            typename apply_wrap2<
                lcm_impl<
                    typename NumericConstant1::tag
                  , typename NumericConstant2::tag
                >
              , NumericConstant1
              , NumericConstant2
            >::type
        >::type
#endif  // BOOST_MPL_CFG_MSVC_ETI_BUG
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , lcm
          , (NumericConstant1, NumericConstant2)
        )
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_LCM_HPP_INCLUDED

