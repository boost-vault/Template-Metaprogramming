// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_EQUAL_TO_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_EQUAL_TO_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/equal_to.hpp>

namespace boost { namespace mpl {

    template <>
    struct equal_to_impl<math::rational_c_tag,math::rational_c_tag>
    {
        template <typename RationalConstant1, typename RationalConstant2>
        struct apply
        {
         private:
            BOOST_STATIC_CONSTANT(
                bool
              , value = (
                    (RationalConstant1::num == RationalConstant2::num)
                 && (
                        (0 == RationalConstant1::num)
                     || (RationalConstant1::den == RationalConstant2::den)
                    )
                )
            );

         public:
            typedef integral_c<bool,value> type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_RATIONAL_C_EQUAL_TO_HPP_INCLUDED

