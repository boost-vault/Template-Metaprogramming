// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_TIMES_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_TIMES_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/largest_int.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/integral_gcd.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/rational_c/aux_/simplify.hpp>

namespace boost { namespace mpl {

    template <>
    struct times_impl<math::rational_c_tag,math::rational_c_tag>
    {
        template <typename RationalConstant1, typename RationalConstant2>
        struct apply
        {
         private:
            typedef typename aux::largest_int<
                        typename RationalConstant1::int_type
                      , typename RationalConstant2::int_type
                    >::type
                    int_type;
            BOOST_STATIC_CONSTANT(
                int_type
              , gcd_1 = (
                    math::integral_gcd<
                        int_type
                      , RationalConstant1::num
                      , RationalConstant2::den
                    >::value
                )
            );
            BOOST_STATIC_CONSTANT(
                int_type
              , gcd_2 = (
                    math::integral_gcd<
                        int_type
                      , RationalConstant2::num
                      , RationalConstant1::den
                    >::value
                )
            );
            BOOST_STATIC_CONSTANT(
                int_type
              , numerator = (
                    (RationalConstant1::num / gcd_1)
                  * (RationalConstant2::num / gcd_2)
                )
            );
            BOOST_STATIC_CONSTANT(
                int_type
              , denominator = (
                    (RationalConstant1::den / gcd_2)
                  * (RationalConstant2::den / gcd_1)
                )
            );

         public:
            typedef typename math::aux::simplify_rational_c<
                        int_type
                      , numerator
                      , denominator
                    >::type
                    type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_RATIONAL_C_TIMES_HPP_INCLUDED

