// Copyright (C) 2005-2008 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_AUX_SIMPLIFY_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_AUX_SIMPLIFY_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/type_traits/is_signed.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/rational_c/macros.hpp>
#include <boost/mpl/math/simplified_rational_c.hpp>

namespace boost { namespace mpl { namespace math {
  namespace aux {

    template <typename IntType>
    struct simplify_rational_c_helper
    {
        template <IntType N, IntType D>
        struct apply_signed
        {
         private:
            BOOST_STATIC_CONSTANT(
                IntType
              , num = BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(
                    IntType
                  , N
                  , D
                )
            );
            BOOST_STATIC_CONSTANT(
                IntType
              , den = BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(
                    IntType
                  , N
                  , D
                )
            );

         public:
            typedef simplified_rational_c<IntType,num,den> type;
        };

        template <IntType N, IntType D>
        struct apply_unsigned
        {
         private:
            BOOST_STATIC_CONSTANT(
                IntType
              , num = BOOST_MPL_MATH_RATIONAL_C_UNSIGNED_NUMERATOR(
                    IntType
                  , N
                  , D
                )
            );
            BOOST_STATIC_CONSTANT(
                IntType
              , den = BOOST_MPL_MATH_RATIONAL_C_UNSIGNED_DENOMINATOR(
                    IntType
                  , N
                  , D
                )
            );

         public:
            typedef simplified_rational_c<IntType,num,den> type;
        };

        template <IntType N, IntType D>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                boost::is_signed<IntType>
              , apply_signed<N,D>
              , apply_unsigned<N,D>
            >
        {
#else
        {
            typedef typename eval_if<
                        boost::is_signed<IntType>
                      , apply_signed<N,D>
                      , apply_unsigned<N,D>
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t N, boost::intmax_t D>
#else
    template <typename IntType, IntType N, IntType D>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct simplify_rational_c
      : simplify_rational_c_helper<
            IntType
        >::BOOST_NESTED_TEMPLATE apply<N,D>
    {
    };
  }  // namespace aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_AUX_SIMPLIFY_HPP_INCLUDED

