// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_E_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_E_HPP_INCLUDED

#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/e_fwd.hpp>
#include <boost/mpl/math/double_/e.hpp>
#include <boost/mpl/math/double_/aux_/to_simplified_rational_c.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct e_dispatch<rational_c_tag>
      : double_::aux::to_simplified_rational_c<e_dispatch<double_tag> >::type
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_E_HPP_INCLUDED

