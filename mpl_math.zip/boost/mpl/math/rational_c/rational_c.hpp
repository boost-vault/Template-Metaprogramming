// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_RATIONAL_C_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_RATIONAL_C_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/simplified_rational_c.hpp>
#include <boost/mpl/math/rational_c_fwd.hpp>
#include <boost/mpl/math/rational_c/aux_/simplify.hpp>
#include <boost/mpl/math/rational_c/numeric.hpp>
#include <boost/mpl/math/rational_c/comparison.hpp>
#include <boost/mpl/math/rational_c/arithmetic.hpp>
#include <boost/mpl/math/rational_c/constants.hpp>
#include <boost/mpl/math/rational_c/runtime_cast.hpp>
#include <boost/mpl/numeric_cast.hpp>

namespace boost { namespace mpl {
  namespace math {

    /*
     * Each template instance encapsulates a Rational Constant.
     */
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t N, boost::intmax_t D>
#else
    template <typename IntType, IntType N, IntType D>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct rational_c : aux::simplify_rational_c<IntType,N,D>::type
    {
    };
  }  // namespace math

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<integral_c_tag,math::rational_c_tag>
    {
        template <typename IntegralConstant>
        struct apply
        {
            typedef math::simplified_rational_c<
                        typename IntegralConstant::value_type
                      , IntegralConstant::value
                      , 1
                    >
                    type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_RATIONAL_C_RATIONAL_C_HPP_INCLUDED

