// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_NUMERIC_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_NUMERIC_HPP_INCLUDED

#include <boost/mpl/math/rational_c/is_zero.hpp>
#include <boost/mpl/math/rational_c/is_negative.hpp>
#include <boost/mpl/math/rational_c/numerator.hpp>
#include <boost/mpl/math/rational_c/denominator.hpp>
#include <boost/mpl/math/rational_c/integral_part.hpp>
#include <boost/mpl/math/rational_c/fractional_part.hpp>

#endif  // BOOST_MPL_MATH_RATIONAL_C_NUMERIC_HPP_INCLUDED

