// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_IS_ZERO_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_IS_ZERO_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/is_zero.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct is_zero_impl<rational_c_tag>
    {
        template <typename RationalConstant>
        struct apply
        {
#if defined(BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC)
         private:
            BOOST_STATIC_CONSTANT(bool, value = (0 == RationalConstant::num));

         public:
            typedef integral_c<bool,value> type;
#else
            typedef integral_c<bool,0 == RationalConstant::num> type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_IS_ZERO_HPP_INCLUDED

