// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_MACROS_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_MACROS_HPP_INCLUDED

#include <boost/mpl/math/integral_gcd.hpp>

#define BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(IntType, N, D) \
        ( \
            (((D) < 0) ? -static_cast<IntType>(N) : (N)) \
          / (boost::mpl::math::integral_gcd<IntType,N,D>::value) \
        ) \
/**/

#define BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(IntType, N, D) \
        ( \
            (((D) < 0) ? -static_cast<IntType>(D) : (D)) \
          / (boost::mpl::math::integral_gcd<IntType,N,D>::value) \
        ) \
/**/

#define BOOST_MPL_MATH_RATIONAL_C_UNSIGNED_NUMERATOR(IntType, N, D) \
        ((N) / (boost::mpl::math::integral_gcd<IntType,N,D>::value)) \
/**/

#define BOOST_MPL_MATH_RATIONAL_C_UNSIGNED_DENOMINATOR(IntType, N, D) \
        ((D) / (boost::mpl::math::integral_gcd<IntType,N,D>::value)) \
/**/

#endif  // BOOST_MPL_MATH_RATIONAL_C_MACROS_HPP_INCLUDED

