// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_ONE_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_ONE_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/simplified_rational_c.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct one_dispatch<rational_c_tag>
      : simplified_rational_c<boost::intmax_t,1,1>
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_ONE_HPP_INCLUDED

