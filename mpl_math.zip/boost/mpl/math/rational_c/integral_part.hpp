// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_INTEGRAL_PART_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_INTEGRAL_PART_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/integral_part.hpp>
#include <boost/mpl/integral_c.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct integral_part_impl<rational_c_tag>
    {
        template <typename RationalConstant>
        struct apply
        {
#if defined(BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC)
         private:
            BOOST_STATIC_CONSTANT(
                typename RationalConstant::int_type
              , value = (RationalConstant::num / RationalConstant::den)
            );

         public:
            typedef integral_c<typename RationalConstant::int_type,value>
                    type;
#else
            typedef integral_c<
                        typename RationalConstant::int_type
                      , (RationalConstant::num / RationalConstant::den)
                    >
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_INTEGRAL_PART_HPP_INCLUDED

