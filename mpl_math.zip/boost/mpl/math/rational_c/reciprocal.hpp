// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_RECIPROCAL_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_RECIPROCAL_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/type_traits/is_signed.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/error/zero_divisor.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/rational_c/macros.hpp>
#include <boost/mpl/math/reciprocal.hpp>
#include <boost/mpl/math/simplified_rational_c.hpp>

namespace boost { namespace mpl { namespace math {
  namespace aux {

    template <typename IntType>
    struct rational_c_reciprocal_helper
    {
        template <IntType N, IntType D>
        struct apply_signed
        {
         private:
            BOOST_STATIC_CONSTANT(
                IntType
              , num = ((N < 0) ? -D : D)
            );
            BOOST_STATIC_CONSTANT(
                IntType
              , den = ((N < 0) ? -N : N)
            );

         public:
            typedef simplified_rational_c<IntType,num,den> type;
        };

        template <IntType N, IntType D>
        struct apply_unsigned
        {
            typedef simplified_rational_c<IntType,D,N> type;
        };

        template <IntType N, IntType D>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if_c<
                0 == N
              , boost::mpl::error::zero_divisor
              , eval_if<
                    boost::is_signed<IntType>
                  , apply_signed<N,D>
                  , apply_unsigned<N,D>
                >
            >
        {
#else
        {
#if defined(BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC)
         private:
            BOOST_STATIC_CONSTANT(bool, has_zero_numerator = (0 == N));

         public:
            typedef typename eval_if_c<
                        has_zero_numerator
                      , boost::mpl::error::zero_divisor
                      , eval_if<
                            boost::is_signed<IntType>
                          , apply_signed<N,D>
                          , apply_unsigned<N,D>
                        >
                    >::type
                    type;
#else
            typedef typename eval_if_c<
                        0 == N
                      , boost::mpl::error::zero_divisor
                      , eval_if<
                            boost::is_signed<IntType>
                          , apply_signed<N,D>
                          , apply_unsigned<N,D>
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename RationalConstant>
    struct rational_c_reciprocal
      : rational_c_reciprocal_helper<
            typename RationalConstant::int_type
        >::BOOST_NESTED_TEMPLATE apply<
            RationalConstant::num
          , RationalConstant::den
        >
    {
    };
  }  // namespace aux

    template <>
    struct reciprocal_impl<rational_c_tag>
    {
        template <typename RationalConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : aux::rational_c_reciprocal<RationalConstant>
        {
#else
        {
            typedef typename aux::rational_c_reciprocal<
                        RationalConstant
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_RATIONAL_C_RECIPROCAL_HPP_INCLUDED

