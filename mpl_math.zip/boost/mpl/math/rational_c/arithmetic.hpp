// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_ARITHMETIC_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_ARITHMETIC_HPP_INCLUDED

#include <boost/mpl/math/rational_c/negate.hpp>
#include <boost/mpl/math/rational_c/plus.hpp>
#include <boost/mpl/math/rational_c/minus.hpp>
#include <boost/mpl/math/rational_c/times.hpp>
#include <boost/mpl/math/rational_c/reciprocal.hpp>
#include <boost/mpl/math/rational_c/divides.hpp>

#endif  // BOOST_MPL_MATH_RATIONAL_C_ARITHMETIC_HPP_INCLUDED

