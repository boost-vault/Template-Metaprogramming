// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_IS_ZERO_HPP_INCLUDED
#define BOOST_MPL_MATH_IS_ZERO_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/negate.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct is_zero_impl
    {
        template <typename NumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : equal_to<negate<NumericConstant>,NumericConstant>
        {
#else
        {
            typedef typename equal_to<
                        negate<NumericConstant>
                      , NumericConstant
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <>
    struct is_zero_impl<integral_c_tag>
    {
        template <typename NumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : equal_to<
                NumericConstant
              , integral_c<typename NumericConstant::value_type,0>
            >
        {
#else
        {
            typedef typename equal_to<
                        NumericConstant
                      , integral_c<
                            typename NumericConstant::value_type
                          , 0
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename NumericConstant>
    struct is_zero
      : apply_wrap1<
            is_zero_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, is_zero, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_IS_ZERO_HPP_INCLUDED

