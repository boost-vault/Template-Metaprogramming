// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/math/mixed_number_c/mixed_number_c.hpp>
#include <boost/mpl/numeric_cast.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/aux_/to_simplified_rational_c.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/convert_rational_c.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/convert_rational.hpp>

namespace boost { namespace mpl {

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<
        math::double_tag
      , math::mixed_number_c_tag
    >
    {
        template <typename DoubleConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::rational_to_mixed_number_c<
                typename math::double_::aux::to_simplified_rational_c<
                    DoubleConstant
                >::type
            >
        {
#else
        {
            typedef typename math::rational_to_mixed_number_c<
                        typename math::double_::aux::to_simplified_rational_c<
                            DoubleConstant
                        >::type
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<
        math::rational_c_tag
      , math::mixed_number_c_tag
    >
    {
        template <typename RationalConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::mixed_number_c_::aux::convert_rational_c<
                RationalConstant::num
              , RationalConstant::den
            >
        {
#else
        {
            typedef typename math::mixed_number_c_::aux::convert_rational_c<
                        RationalConstant::num
                      , RationalConstant::den
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_HPP_INCLUDED

