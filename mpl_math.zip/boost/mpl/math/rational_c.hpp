// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_RATIONAL_C_HPP_INCLUDED
#define BOOST_MPL_MATH_RATIONAL_C_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/rational_c/rational_c.hpp>
#include <boost/mpl/numeric_cast.hpp>
#include <boost/mpl/math/double_/aux_/to_simplified_rational_c.hpp>

namespace boost { namespace mpl {

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<math::double_tag,math::rational_c_tag>
    {
        template <typename DoubleConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::double_::aux::to_simplified_rational_c<DoubleConstant>
        {
#else  // ifndef BOOST_MPL_CFG_NO_NESTED_FORWARDING
        {
            typedef typename math::double_::aux::to_simplified_rational_c<
                        DoubleConstant
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_RATIONAL_C_HPP_INCLUDED

