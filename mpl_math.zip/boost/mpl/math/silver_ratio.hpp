// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_SILVER_RATIO_HPP_INCLUDED
#define BOOST_MPL_MATH_SILVER_RATIO_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_SILVER_RATIO_SERIES
#define BOOST_MPL_LIMIT_MATH_SILVER_RATIO_SERIES 24
#endif

#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/silver_ratio_fwd.hpp>

#define BOOST_MPL_MATH_SILVER_RATIO_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        typedef typename plus< \
                    divides< \
                        one_dispatch<NumericTag> \
                      , BOOST_PP_CAT(prefix, x) \
                    > \
                  , BOOST_PP_CAT(prefix, 0) \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct silver_ratio_dispatch_impl
    {
        /*
         * Compile-time continued fraction series.
         */
        typedef typename two_dispatch<NumericTag>::type
        BOOST_PP_REPEAT(
            BOOST_MPL_LIMIT_MATH_SILVER_RATIO_SERIES
          , BOOST_MPL_MATH_SILVER_RATIO_MACRO
          , term_
        )
                type;
    };

    template <typename NumericTag>
    struct silver_ratio_dispatch
      : silver_ratio_dispatch_impl<NumericTag>::type
    {
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_MATH_SILVER_RATIO_MACRO
#undef BOOST_MPL_LIMIT_MATH_SILVER_RATIO_SERIES

#endif  // BOOST_MPL_MATH_SILVER_RATIO_HPP_INCLUDED

