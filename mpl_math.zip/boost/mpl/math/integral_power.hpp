// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_INTEGRAL_POWER_HPP_INCLUDED
#define BOOST_MPL_MATH_INTEGRAL_POWER_HPP_INCLUDED

#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/shift_right.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/reciprocal.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/math/abs.hpp>
#include <boost/mpl/math/is_odd.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct integral_power_impl
    {
        template <
            typename NumericConstantBase
          , typename IntegralConstantPower
        >
        struct binary_split
        {
         private:
            typedef typename eval_if<
                        is_zero<IntegralConstantPower>
                      , next<IntegralConstantPower>
                      , binary_split<
                            NumericConstantBase
                          , shift_right<IntegralConstantPower,int_<1> >
                        >
                    >::type
                    next_step;

         public:
            typedef typename eval_if<
                        is_zero<IntegralConstantPower>
                      , next_step
                      , eval_if<
                            is_odd<IntegralConstantPower>
                          , times<next_step,next_step,NumericConstantBase>
                          , times<next_step,next_step>
                        >
                    >::type
                    type;
        };

        template <
            typename NumericConstantBase
          , typename IntegralConstantPower
        >
        struct apply
        {
         private:
            typedef typename binary_split<
                        NumericConstantBase
                      , typename abs<IntegralConstantPower>::type
                    >::type
                    result;

         public:
            typedef typename eval_if<
                        is_negative<IntegralConstantPower>
                      , reciprocal<result>
                      , result
                    >::type
                    type;
        };
    };

    template <
        typename NumericConstantBase
      , typename IntegralConstantPower
    >
    struct integral_power
      : apply_wrap2<
            integral_power_impl<typename NumericConstantBase::tag>
          , NumericConstantBase
          , IntegralConstantPower
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , integral_power
          , (NumericConstantBase,IntegralConstantPower)
        )
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_INTEGRAL_POWER_HPP_INCLUDED

