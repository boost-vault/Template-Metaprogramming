// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COSINE_HPP_INCLUDED
#define BOOST_MPL_MATH_COSINE_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_COSINE_SERIES
#define BOOST_MPL_LIMIT_MATH_COSINE_SERIES 8
#endif

#include <boost/cstdint.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/less.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/pi_fwd.hpp>

#define BOOST_MPL_MATH_COSINE_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        BOOST_STATIC_CONSTANT( \
            boost::intmax_t \
          , BOOST_PP_CAT(constant_, x) = \
                (((BOOST_MPL_LIMIT_MATH_COSINE_SERIES - x) << 1) - 1) \
              * ((BOOST_MPL_LIMIT_MATH_COSINE_SERIES - x) << 1) \
        ); \
        typedef typename minus< \
                    one_type \
                  , times< \
                        divides< \
                            angle_squared \
                          , integral_c< \
                                boost::intmax_t \
                              , BOOST_PP_CAT(constant_, x) \
                            > \
                        > \
                      , BOOST_PP_CAT(prefix, x) \
                    > \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {
  namespace aux {
  }  // namespace aux

    template <typename NumericTag>
    struct cosine_impl
    {
        /*
         * The cosine function has a period of pi*2.
         * The series is most accurate in the range (-pi/2,pi/2).
         */
     private:
        typedef typename one_dispatch<NumericTag>::type
                one_type;
        typedef typename two_dispatch<NumericTag>::type
                two_type;
        typedef times<pi_dispatch<NumericTag>,two_type>
                pi_times_2;

        template <typename Angle>
        struct series
        {
            /*
             * Compile-time Maclaurin series.
             */
            typedef typename times<Angle,Angle>::type
                    angle_squared;
            typedef one_type
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_COSINE_SERIES
              , BOOST_MPL_MATH_COSINE_MACRO
              , term_
            )
                    type;
        };

     public:
        template <typename Angle>
        struct apply
        {
            typedef typename eval_if<
                        less<pi_dispatch<NumericTag>,Angle>
                      , apply<minus<Angle,pi_times_2> >
                      , eval_if<
                            less<Angle,negate<pi_dispatch<NumericTag> > >
                          , apply<plus<Angle,pi_times_2> >
                          , series<Angle>
                        >
                    >::type
                    type;
        };
    };

    template <typename Angle>
    struct cosine : apply_wrap1<cosine_impl<typename Angle::tag>,Angle>::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, cosine, (Angle))
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_LIMIT_MATH_COSINE_SERIES
#undef BOOST_MPL_MATH_COSINE_MACRO

#endif  // BOOST_MPL_MATH_COSINE_HPP_INCLUDED

