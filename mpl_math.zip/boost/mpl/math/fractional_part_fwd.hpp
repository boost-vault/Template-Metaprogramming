// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_FRACTIONAL_PART_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_FRACTIONAL_PART_FWD_HPP_INCLUDED

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct fractional_part_impl;

    template <typename NumericConstant>
    struct fractional_part;
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_FRACTIONAL_PART_FWD_HPP_INCLUDED

