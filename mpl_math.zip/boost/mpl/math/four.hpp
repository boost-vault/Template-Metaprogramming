// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_FOUR_HPP_INCLUDED
#define BOOST_MPL_MATH_FOUR_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/void.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/numeric_tag.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct four_dispatch;

    template <>
    struct four_dispatch<integral_c_tag> : integral_c<boost::intmax_t,4>
    {
    };

    /*
     * In case BOOST_MPL_CFG_NO_HAS_XXX is set.
     */
    template <>
    struct four_dispatch<void_> : integral_c<boost::intmax_t,4>
    {
    };

    template <typename NumericType>
    struct four : four_dispatch<typename numeric_tag<NumericType>::type>
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, four, (NumericType))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_FOUR_HPP_INCLUDED

