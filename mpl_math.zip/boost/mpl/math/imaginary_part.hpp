// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_IMAGINARY_PART_HPP_INCLUDED
#define BOOST_MPL_MATH_IMAGINARY_PART_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/math/zero.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * By default, assume that the numeric constant is real.
     */
    template <typename NumericTag>
    struct imaginary_part_impl
    {
        template <typename NumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : zero_dispatch<NumericTag>
        {
#else
        {
            typedef typename zero_dispatch<NumericTag>::type type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename NumericConstant>
    struct imaginary_part
      : apply_wrap1<
            imaginary_part_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, imaginary_part, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_IMAGINARY_PART_HPP_INCLUDED

