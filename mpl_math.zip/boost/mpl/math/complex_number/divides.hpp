// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_DIVIDES_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_DIVIDES_HPP_INCLUDED

#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/math/complex_number_fwd.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>

namespace boost { namespace mpl {

    template <>
    struct divides_impl<math::complex_number_tag,math::complex_number_tag>
    {
        template <
            typename ComplexNumericConstant1
          , typename ComplexNumericConstant2
        >
        struct apply
        {
            typedef math::complex_number<
                      typename divides<
                        plus<
                          times<
                            typename ComplexNumericConstant1::real_part
                          , typename ComplexNumericConstant2::real_part
                          >
                        , times<
                            typename ComplexNumericConstant1::imaginary_part
                          , typename ComplexNumericConstant2::imaginary_part
                          >
                        >
                      , plus<
                          times<
                            typename ComplexNumericConstant2::real_part
                          , typename ComplexNumericConstant2::real_part
                          >
                        , times<
                            typename ComplexNumericConstant2::imaginary_part
                          , typename ComplexNumericConstant2::imaginary_part
                          >
                        >
                      >::type
                    , typename divides<
                        minus<
                          times<
                            typename ComplexNumericConstant1::imaginary_part
                          , typename ComplexNumericConstant2::real_part
                          >
                        , times<
                            typename ComplexNumericConstant1::real_part
                          , typename ComplexNumericConstant2::imaginary_part
                          >
                        >
                      , plus<
                          times<
                            typename ComplexNumericConstant2::real_part
                          , typename ComplexNumericConstant2::real_part
                          >
                        , times<
                            typename ComplexNumericConstant2::imaginary_part
                          , typename ComplexNumericConstant2::imaginary_part
                          >
                        >
                      >::type
                    >
                    type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_DIVIDES_HPP_INCLUDED

