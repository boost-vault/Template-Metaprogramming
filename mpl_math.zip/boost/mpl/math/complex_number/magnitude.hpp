// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_MAGNITUDE_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_MAGNITUDE_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/magnitude.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/square_root.hpp>

namespace boost {
  namespace mpl {

    template <>
    struct magnitude_impl<math::complex_number_tag>
    {
        template <typename ComplexNumericConstant>
        struct apply
#ifndef BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::square_root<
                plus<
                    times<
                        typename ComplexNumericConstant::real_part
                      , typename ComplexNumericConstant::real_part
                    >
                  , times<
                        typename ComplexNumericConstant::imaginary_part
                      , typename ComplexNumericConstant::imaginary_part
                    >
                >
            >
        {
#else
        {
            typedef typename math::square_root<
                        plus<
                            times<
                                typename ComplexNumericConstant::real_part
                              , typename ComplexNumericConstant::real_part
                            >
                          , times<
                                typename ComplexNumericConstant::imaginary_part
                              , typename ComplexNumericConstant::imaginary_part
                            >
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
  }  // namespace mpl
}  // namespace boost

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_MAGNITUDE_HPP_INCLUDED

