// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_IMAGINARY_PART_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_IMAGINARY_PART_HPP_INCLUDED

#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/math/imaginary_part.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct imaginary_part_impl<complex_number_tag>
    {
        template <typename ComplexNumericConstant>
        struct apply
        {
            typedef typename ComplexNumericConstant::imaginary_part type;
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_IMAGINARY_PART_HPP_INCLUDED

