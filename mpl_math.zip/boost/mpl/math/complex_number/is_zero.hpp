// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_IS_ZERO_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_IS_ZERO_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/real_part.hpp>
#include <boost/mpl/math/imaginary_part.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct is_zero_impl<complex_number_tag>
    {
        template <typename ComplexNumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_zero<real_part<ComplexNumericConstant> >
              , is_zero<imaginary_part<ComplexNumericConstant> >
              , false_
            >
        {
#else
        {
            typedef typename eval_if<
                        is_zero<real_part<ComplexNumericConstant> >
                      , is_zero<imaginary_part<ComplexNumericConstant> >
                      , false_
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_IS_ZERO_HPP_INCLUDED

