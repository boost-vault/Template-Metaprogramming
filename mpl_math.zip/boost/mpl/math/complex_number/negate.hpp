// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_NEGATE_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_NEGATE_HPP_INCLUDED

#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/math/complex_number_fwd.hpp>
#include <boost/mpl/negate.hpp>

namespace boost { namespace mpl {

    template <>
    struct negate_impl<math::complex_number_tag>
    {
        template <typename ComplexNumericConstant>
        struct apply
        {
            typedef math::complex_number<
                        typename negate<
                            typename ComplexNumericConstant::real_part
                        >::type
                      , typename negate<
                            typename ComplexNumericConstant::imaginary_part
                        >::type
                    >
                    type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_NEGATE_HPP_INCLUDED

