// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_NUMERIC_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_NUMERIC_HPP_INCLUDED

#include <boost/mpl/math/complex_number/is_zero.hpp>
#include <boost/mpl/math/complex_number/real_part.hpp>
#include <boost/mpl/math/complex_number/imaginary_part.hpp>

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_NUMERIC_HPP_INCLUDED

