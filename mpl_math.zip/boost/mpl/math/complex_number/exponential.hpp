// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_EXPONENTIAL_HPP
#define BOOST_MPL_MATH_COMPLEX_NUMBER_EXPONENTIAL_HPP

#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/math/complex_number_fwd.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/math/sine.hpp>
#include <boost/mpl/math/cosine.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct exponential_impl<complex_number_tag>
    {
        template <typename ComplexNumericConstant>
        struct apply
        {
            typedef complex_number<
                        typename times<
                            exponential<
                                typename ComplexNumericConstant::real_part
                            >
                          , cosine<
                                typename ComplexNumericConstant::imaginary_part
                            >
                        >::type
                      , typename times<
                            exponential<
                                typename ComplexNumericConstant::real_part
                            >
                          , sine<
                                typename ComplexNumericConstant::imaginary_part
                            >
                        >::type
                    >
                    type;
        };
    };
}}}  //namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_EXPONENTIAL_HPP

