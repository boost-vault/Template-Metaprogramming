// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_NOT_EQUAL_TO_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_NOT_EQUAL_TO_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/mpl/math/real_part.hpp>
#include <boost/mpl/math/imaginary_part.hpp>

namespace boost { namespace mpl {

    template <>
    struct not_equal_to_impl<math::complex_number_tag,math::complex_number_tag>
    {
        template <
            typename ComplexNumericConstant1
          , typename ComplexNumericConstant2
        >
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                not_equal_to<
                    math::real_part<ComplexNumericConstant1>
                  , math::real_part<ComplexNumericConstant2>
                >
              , true_
              , not_equal_to<
                    math::imaginary_part<ComplexNumericConstant1>
                  , math::imaginary_part<ComplexNumericConstant2>
                >
            >
        {
#else
        {
            typedef typename eval_if<
                        not_equal_to<
                            math::real_part<ComplexNumericConstant1>
                          , math::real_part<ComplexNumericConstant2>
                        >
                      , true_
                      , not_equal_to<
                            math::imaginary_part<ComplexNumericConstant1>
                          , math::imaginary_part<ComplexNumericConstant2>
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_NOT_EQUAL_TO_HPP_INCLUDED

