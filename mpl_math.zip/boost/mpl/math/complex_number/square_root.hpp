// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_SQUARE_ROOT_HPP
#define BOOST_MPL_MATH_COMPLEX_NUMBER_SQUARE_ROOT_HPP

#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/math/complex_number_fwd.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/square_root.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct square_root_impl<complex_number_tag>
    {
        template <typename ComplexNumericConstant>
        struct apply
        {
         private:
            typedef typename math::square_root<
                        plus<
                            times<
                                typename ComplexNumericConstant::real_part
                              , typename ComplexNumericConstant::real_part
                            >
                          , times<
                                typename ComplexNumericConstant::imaginary_part
                              , typename ComplexNumericConstant::imaginary_part
                            >
                        >
                    >::type
                    complex_magnitude;
            typedef typename math::square_root<
                        divides<
                            minus<
                                complex_magnitude
                              , typename ComplexNumericConstant::real_part
                            >
                          , long_<2>
                        >
                    >
                    imaginary_result;

         public:
            typedef complex_number<
                        typename math::square_root<
                            divides<
                                plus<
                                    complex_magnitude
                                  , typename ComplexNumericConstant::real_part
                                >
                              , long_<2>
                            >
                        >::type
                      , typename eval_if<
                            is_negative<
                                typename ComplexNumericConstant::imaginary_part
                            >
                          , negate<imaginary_result>
                          , imaginary_result
                        >::type
                    >
                    type;
        };
    };
}}}  //namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_SQUARE_ROOT_HPP

