// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_SIMPLIFIED_RATIONAL_C_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_SIMPLIFIED_RATIONAL_C_FWD_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * Use this only when you're really sure
     * the arguments are relatively prime.
     */
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename ValueType, boost::intmax_t N, boost::intmax_t D>
#else
    template <typename ValueType, ValueType N, ValueType D>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct simplified_rational_c;
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_SIMPLIFIED_RATIONAL_C_FWD_HPP_INCLUDED

