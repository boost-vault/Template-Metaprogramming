// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_INTEGRAL_GCD_HPP_INCLUDED
#define BOOST_MPL_MATH_INTEGRAL_GCD_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/type_traits/is_signed.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/config/eti.hpp>
#include <boost/mpl/aux_/msvc_eti_base.hpp>
#include <boost/mpl/limits/unrolling.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/modulus_c.hpp>

#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
#define BOOST_MPL_MATH_EUCLID_GCD_HELPER_CONSTANTS(z, x, unused) \
          , BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, x) \
             || (0 == BOOST_PP_CAT(arg2_step_, x)) \
            ) \
          , BOOST_PP_CAT(arg1_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
              ? BOOST_PP_CAT(arg1_step_, x) \
              : BOOST_PP_CAT(arg2_step_, x) \
            ) \
          , BOOST_PP_CAT(arg2_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
              ? 0 \
              : boost::mpl::aux::modulus_c_::dispatch< \
                    ValueType \
                >::BOOST_NESTED_TEMPLATE apply< \
                    BOOST_PP_CAT(arg1_step_, x) \
                  , BOOST_PP_CAT(arg2_step_, x) \
                >::value \
            ) \
        /**/
#else
#define BOOST_MPL_MATH_EUCLID_GCD_HELPER_CONSTANTS(z, x, unused) \
        static const bool \
            BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, x) \
             || (0 == BOOST_PP_CAT(arg2_step_, x)) \
            ); \
        static const ValueType \
            BOOST_PP_CAT(arg1_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
              ? BOOST_PP_CAT(arg1_step_, x) \
              : BOOST_PP_CAT(arg2_step_, x) \
            ); \
        static const ValueType \
            BOOST_PP_CAT(arg2_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
              ? 0 \
              : boost::mpl::aux::modulus_c_::dispatch< \
                    ValueType \
                >::BOOST_NESTED_TEMPLATE apply< \
                    BOOST_PP_CAT(arg1_step_, x) \
                  , BOOST_PP_CAT(arg2_step_, x) \
                >::value \
            ); \
        /**/
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

namespace boost { namespace mpl { namespace math {
  namespace aux {

    template <typename ValueType>
    struct integral_gcd_impl
    {
        template <ValueType N1, ValueType N2>
        struct helper
        {
         private:
#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
            enum
            {
                stop_recurse_pred_0 = (0 == N2)
              , arg1_step_0 = (stop_recurse_pred_0 ? N1 : N2)
              , arg2_step_0 = (
                    stop_recurse_pred_0
                  ? 0
                  : boost::mpl::aux::modulus_c_::dispatch<
                        ValueType
                    >::BOOST_NESTED_TEMPLATE apply<N1,N2>::value
                )
#else
            static const bool
                stop_recurse_pred_0 = (0 == N2);
            static const ValueType
                arg1_step_0 = (stop_recurse_pred_0 ? N1 : N2);
            static const ValueType
                arg2_step_0 = (
                    stop_recurse_pred_0
                  ? 0
                  : boost::mpl::aux::modulus_c_::dispatch<
                        ValueType
                    >::BOOST_NESTED_TEMPLATE apply<N1,N2>::value
                );
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_UNROLLING
              , BOOST_MPL_MATH_EUCLID_GCD_HELPER_CONSTANTS
              , unused
            )
#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
            };
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

         public:
            typedef typename eval_if_c<
                        BOOST_PP_CAT(
                            stop_recurse_pred_
                          , BOOST_MPL_LIMIT_UNROLLING
                        )
                      , integral_c<
                            ValueType
                          , BOOST_PP_CAT(
                                arg1_step_
                              , BOOST_MPL_LIMIT_UNROLLING
                            )
                        >
                      , helper<
                            BOOST_PP_CAT(
                                arg1_step_
                              , BOOST_MPL_LIMIT_UNROLLING
                            )
                          , BOOST_PP_CAT(
                                arg2_step_
                              , BOOST_MPL_LIMIT_UNROLLING
                            )
                        >
                    >::type
                    type;
        };

        template <ValueType N1, ValueType N2>
        struct apply_signed
        {
         private:
#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
            enum
            {
                is_n1_zero = (0 == N1)
              , is_n2_zero = (0 == N2)
              , abs_n1 = (N1 < 0 ? -N1 : N1)
              , abs_n2 = (N2 < 0 ? -N2 : N2)
            };
#else
            static const bool is_n1_zero = (0 == N1);
            static const bool is_n2_zero = (0 == N2);
            static const ValueType abs_n1 = (N1 < 0 ? -N1 : N1);
            static const ValueType abs_n2 = (N2 < 0 ? -N2 : N2);
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

         public:
            typedef typename eval_if_c<
                        is_n1_zero
                      , integral_c<ValueType,N2>
                      , eval_if_c<
                            is_n2_zero
                          , integral_c<ValueType,N1>
                          , helper<abs_n1,abs_n2>
                        >
                    >::type
                    type;
        };

        template <ValueType N1, ValueType N2>
        struct apply_unsigned
        {
         private:
#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
            enum
            {
                is_n1_zero = (0 == N1)
              , is_n2_zero = (0 == N2)
            };
#else
            static const bool is_n1_zero = (N1 == 0);
            static const bool is_n2_zero = (N2 == 0);
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

         public:
            typedef typename eval_if_c<
                        is_n1_zero
                      , integral_c<ValueType,N2>
                      , eval_if_c<
                            is_n2_zero
                          , integral_c<ValueType,N1>
                          , helper<N1,N2>
                        >
                    >::type
                    type;
        };

        template <ValueType N1, ValueType N2>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_signed<ValueType>
              , apply_signed<N1,N2>
              , apply_unsigned<N1,N2>
            >
        {
#else
        {
            typedef typename eval_if<
                        is_signed<ValueType>
                      , apply_signed<N1,N2>
                      , apply_unsigned<N1,N2>
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
  }  // namespace aux

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename ValueType, boost::intmax_t N1, boost::intmax_t N2>
#else
    template <typename ValueType, ValueType N1, ValueType N2>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct integral_gcd
#if !defined(BOOST_MPL_CFG_MSVC_ETI_BUG)
      : aux::integral_gcd_impl<
            ValueType
        >::BOOST_NESTED_TEMPLATE apply<N1,N2>::type
#else
      : boost::mpl::aux::msvc_eti_base<
            typename aux::integral_gcd_impl<
                ValueType
            >::BOOST_NESTED_TEMPLATE apply<N1,N2>::type
        >::type
#endif  // BOOST_MPL_CFG_MSVC_ETI_BUG
    {
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_MATH_EUCLID_GCD_HELPER_CONSTANTS

#endif  // BOOST_MPL_MATH_INTEGRAL_GCD_HPP_INCLUDED

