// Copyright (C) 2005-2011 Peder Holt
// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_LOGARITHM_HPP_INCLUDED
#define BOOST_MPL_MATH_LOGARITHM_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES
#define BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES 8
#endif

#include <boost/cstdint.hpp>
#include <boost/preprocessor/arithmetic/sub.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/error/input_out_of_domain.hpp>

#define BOOST_MPL_MATH_LOGARITHM_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        BOOST_STATIC_CONSTANT( \
            boost::uint32_t \
          , BOOST_PP_CAT(constant_, x) = \
                ((BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES - x + 1) >> 1) \
              * ((BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES - x + 1) >> 1) \
        ); \
        typedef typename plus< \
                    divides< \
                        times< \
                            argument \
                          , integral_c< \
                                boost::uint32_t \
                              , BOOST_PP_CAT(constant_, x) \
                            > \
                        > \
                      , BOOST_PP_CAT(prefix, x) \
                    > \
                  , integral_c< \
                        boost::uint32_t \
                      , BOOST_PP_SUB( \
                            BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES \
                          , x \
                        ) \
                    > \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct logarithm_impl
    {
        template <typename NumericConstant>
        struct apply
        {
         private:
            /*
             * Continued fraction representation
             * <http://functions.wolfram.com/ElementaryFunctions/Tan/10>
             */
            typedef typename eval_if<
                        is_negative<NumericConstant>
                      , boost::mpl::error::input_out_of_domain
                      , minus<NumericConstant,integral_c<boost::uint32_t,1> >
                    >::type
                    argument;
            typedef integral_c<
                        boost::uint32_t
                      , BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES
                    >
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES
              , BOOST_MPL_MATH_LOGARITHM_MACRO
              , term_
            )
                    last_term;

         public:
            typedef typename divides<argument,last_term>::type
                    type;
        };
    };

    template <typename NumericConstant>
    struct logarithm
      : apply_wrap1<
            logarithm_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, logarithm, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_LIMIT_MATH_LOGARITHM_SERIES
#undef BOOST_MPL_MATH_LOGARITHM_MACRO

#endif  // BOOST_MPL_MATH_TANGENT_HPP_INCLUDED

