// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_ABS_HPP_INCLUDED
#define BOOST_MPL_MATH_ABS_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/math/is_negative.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct abs_impl
    {
        template <typename NumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_negative<NumericConstant>
              , negate<NumericConstant>
              , NumericConstant
            >
        {
#else
        {
            typedef typename eval_if<
                        is_negative<NumericConstant>
                      , negate<NumericConstant>
                      , NumericConstant
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename NumericConstant>
    struct abs
      : apply_wrap1<
            abs_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, abs, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_ABS_HPP_INCLUDED

