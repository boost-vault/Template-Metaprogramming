// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_POWER_HPP_INCLUDED
#define BOOST_MPL_MATH_POWER_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/is_integral_constant.hpp>
#include <boost/mpl/math/integral_part.hpp>
#include <boost/mpl/math/fractional_part.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/integral_power.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/math/logarithm.hpp>
#include <boost/type_traits/is_same.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename BaseTag, typename ExponentTag>
    struct power_impl
    {
        template <
            typename NumericConstantBase
          , typename NumericConstantExponent
        >
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_integral_constant<NumericConstantExponent>
              , integral_power<
                    NumericConstantBase
                  , NumericConstantExponent
                >
              , times<
                    integral_power<
                        NumericConstantBase
                      , integral_part<NumericConstantExponent>
                    >
                  , exponential<
                        times<
                            logarithm<NumericConstantBase>
                          , fractional_part<NumericConstantExponent>
                        >
                    >
                >
            >
        {
#else
        {
            typedef typename eval_if<
                        is_integral_constant<NumericConstantExponent>
                      , integral_power<
                            NumericConstantBase
                          , NumericConstantExponent
                        >
                      , times<
                            integral_power<
                                NumericConstantBase
                              , integral_part<NumericConstantExponent>
                            >
                          , exponential<
                                times<
                                    logarithm<NumericConstantBase>
                                  , fractional_part<NumericConstantExponent>
                                >
                            >
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <
        typename NumericConstantBase
      , typename NumericConstantExponent
    >
    struct power
      : apply_wrap2<
            power_impl<
                typename NumericConstantBase::tag
              , typename NumericConstantExponent::tag
            >
          , NumericConstantBase
          , NumericConstantExponent
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , power
          , (NumericConstantBase,NumericConstantExponent)
        )
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_POWER_HPP_INCLUDED

