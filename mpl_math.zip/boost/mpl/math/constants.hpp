// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_CONSTANTS_HPP_INCLUDED
#define BOOST_MPL_MATH_CONSTANTS_HPP_INCLUDED

#include <boost/mpl/math/zero.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/three.hpp>
#include <boost/mpl/math/four.hpp>
#include <boost/mpl/math/golden_ratio.hpp>
#include <boost/mpl/math/silver_ratio.hpp>
#include <boost/mpl/math/e.hpp>
#include <boost/mpl/math/pi.hpp>

#endif  // BOOST_MPL_MATH_CONSTANTS_HPP_INCLUDED

