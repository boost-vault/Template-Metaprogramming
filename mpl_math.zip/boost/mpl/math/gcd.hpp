// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_GCD_HPP_INCLUDED
#define BOOST_MPL_MATH_GCD_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/config/eti.hpp>
#include <boost/mpl/aux_/msvc_eti_base.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/limits/unrolling.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/aux_/largest_int.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/modulus.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/abs.hpp>

#define BOOST_MPL_MATH_EUCLID_GCD_HELPER_TYPEDEFS(z, x, unused) \
        typedef typename eval_if< \
                    BOOST_PP_CAT(stop_recurse_pred_, x) \
                  , true_ \
                  , is_zero<BOOST_PP_CAT(arg2_step_, x)> \
                >::type \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)); \
        typedef typename if_< \
                    BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
                  , BOOST_PP_CAT(arg1_step_, x) \
                  , BOOST_PP_CAT(arg2_step_, x) \
                >::type \
                BOOST_PP_CAT(arg1_step_, BOOST_PP_INC(x)); \
        typedef typename eval_if< \
                    BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
                  , BOOST_PP_CAT(arg1_step_, BOOST_PP_INC(x)) \
                  , modulus< \
                        BOOST_PP_CAT(arg1_step_, x) \
                      , BOOST_PP_CAT(arg2_step_, x) \
                    > \
                >::type \
                BOOST_PP_CAT(arg2_step_, BOOST_PP_INC(x)); \
        /**/

namespace boost { namespace mpl { namespace math {

    /*
     * TODO: Change primary implementation to behave like other metafunctions,
     * i.e. use numeric_cast as necessary, then defer to the appropriate
     * specialization.
     */
    template <typename NumericTag1, typename NumericTag2>
    struct gcd_impl
    {
        template <typename NumericConstant1, typename NumericConstant2>
        struct helper
        {
         private:
            typedef typename is_zero<NumericConstant2>::type
                    stop_recurse_pred_0;
            typedef typename if_<
                        stop_recurse_pred_0
                      , NumericConstant1
                      , NumericConstant2
                    >::type
                    arg1_step_0;
            typedef typename eval_if<
                        stop_recurse_pred_0
                      , arg1_step_0
                      , modulus<NumericConstant1,NumericConstant2>
                    >::type
                    arg2_step_0;
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_UNROLLING
              , BOOST_MPL_MATH_EUCLID_GCD_HELPER_TYPEDEFS
              , unused
            )

         public:
            typedef typename eval_if<
                        BOOST_PP_CAT(
                            stop_recurse_pred_
                          , BOOST_MPL_LIMIT_UNROLLING
                        )
                      , BOOST_PP_CAT(
                            arg1_step_
                          , BOOST_MPL_LIMIT_UNROLLING
                        )
                      , helper<
                            BOOST_PP_CAT(
                                arg1_step_
                              , BOOST_MPL_LIMIT_UNROLLING
                            )
                          , BOOST_PP_CAT(
                                arg2_step_
                              , BOOST_MPL_LIMIT_UNROLLING
                            )
                        >
                    >::type
                    type;
        };

        template <typename NumericConstant1, typename NumericConstant2>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_zero<NumericConstant1>
              , NumericConstant2
              , eval_if<
                    is_zero<NumericConstant2>
                  , NumericConstant1
                  , helper<abs<NumericConstant1>,abs<NumericConstant2> >
                >
            >
        {
#else
        {
            typedef typename eval_if<
                        is_zero<NumericConstant1>
                      , NumericConstant2
                      , eval_if<
                            is_zero<NumericConstant2>
                          , NumericConstant1
                          , helper<abs<NumericConstant1>,abs<NumericConstant2> >
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

  namespace aux { namespace gcd_ {

    template <typename ValueType>
    struct dispatch;

/*
 * MPL-ized version of boost::math::static_gcd
 */
#if !defined BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
#define BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(value_type, name) \
        template <value_type N1, value_type N2> \
        struct BOOST_PP_CAT(name, _helper) \
        { \
         private: \
            BOOST_STATIC_CONSTANT(value_type, n1 = N2); \
            BOOST_STATIC_CONSTANT(value_type, n2 = N1 % N2); \
         public: \
            typedef typename BOOST_PP_CAT(name, _helper)<n1,n2>::type type; \
        }; \
        template <value_type N1> \
        struct BOOST_PP_CAT(name, _helper)<N1,0> \
        { \
            typedef integral_c<value_type,N1> type; \
        }; \
        template <value_type N2> \
        struct BOOST_PP_CAT(name, _helper)<0,N2> \
        { \
            typedef integral_c<value_type,N2> type; \
        }; \
        template <> \
        struct BOOST_PP_CAT(name, _helper)<0,0> \
        { \
            typedef integral_c<value_type,0> type; \
        }; \
        template <> \
        struct dispatch<value_type> \
        { \
            template <value_type N1, value_type N2> \
            struct apply \
            { \
                typedef typename BOOST_PP_CAT(name, _helper)< \
                            N1 \
                          , N2 \
                        >::type \
                        type; \
            }; \
        }; \
        /**/
#else
#define BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(value_type, name) \
        template <value_type N1> \
        struct BOOST_PP_CAT(name, _helper2) \
        { \
            template <value_type N2> \
            struct apply \
            { \
             private: \
                BOOST_STATIC_CONSTANT(value_type, n2 = N1 % n2); \
             public: \
                typedef typename BOOST_PP_CAT(name, _helper2)<N2> \
                            ::BOOST_NESTED_TEMPLATE apply<n2> \
                            ::type \
                        type; \
            }; \
            template <> \
            struct apply<0> \
            { \
                typedef integral_c<value_type,N1> type; \
            }; \
        }; \
        template <> \
        struct BOOST_PP_CAT(name, _helper2)<0> \
        { \
            template <value_type N2> \
            struct apply \
            { \
                typedef integral_c<value_type,N2> type; \
            }; \
        }; \
        template <> \
        struct dispatch<value_type> \
        { \
            template <value_type N1, value_type N2> \
            struct apply \
            { \
                typedef typename BOOST_PP_CAT(name, _helper2)<N1> \
                            ::BOOST_NESTED_TEMPLATE apply<N2> \
                            ::type \
                        type; \
            }; \
        }; \
        /**/
#endif  // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#define BOOST_MPL_MATH_GCD_HELPER_DISPATCH(value_type) \
        BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(value_type, value_type) \
        /**/

BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(signed char, schar)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(char)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(unsigned char, uchar)
#if !defined(BOOST_NO_INTRINSIC_WCHAR_T)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(wchar_t)
#endif  // BOOST_NO_INTRINSIC_WCHAR_T
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(short)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(unsigned short, ushort)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(int)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(unsigned int, uint)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(long)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2(unsigned long, ulong)
#if defined(BOOST_HAS_LONG_LONG)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(long_long_type)
BOOST_MPL_MATH_GCD_HELPER_DISPATCH(ulong_long_type)
#endif  // BOOST_HAS_LONG_LONG

#undef BOOST_MPL_MATH_GCD_HELPER_DISPATCH
#undef BOOST_MPL_MATH_GCD_HELPER_DISPATCH_2
  }}  // namespace aux::gcd_

    template <>
    struct gcd_impl<integral_c_tag,integral_c_tag>
    {
        template <typename NumericConstant1, typename NumericConstant2>
        struct apply
        {
         private:
            typedef typename boost::mpl::aux::largest_int<
                        typename NumericConstant1::value_type
                      , typename NumericConstant2::value_type
                    >::type
                    value_type;
            BOOST_STATIC_CONSTANT(
                value_type
              , n1 = abs<NumericConstant1>::value
            );
            BOOST_STATIC_CONSTANT(
                value_type
              , n2 = abs<NumericConstant2>::value
            );

         public:
            typedef typename aux::gcd_::dispatch<value_type>
                        ::BOOST_NESTED_TEMPLATE apply<n1,n2>
                        ::type
                    type;
        };
    };

    template <typename NumericConstant1, typename NumericConstant2>
    struct gcd
#if !defined(BOOST_MPL_CFG_MSVC_ETI_BUG)
      : gcd_impl<
            typename NumericConstant1::tag
          , typename NumericConstant2::tag
        >::BOOST_NESTED_TEMPLATE apply<NumericConstant1,NumericConstant2>::type
#else
      : boost::mpl::aux::msvc_eti_base<
            typename apply_wrap2<
                gcd_impl<
                    typename NumericConstant1::tag
                  , typename NumericConstant2::tag
                >
              , NumericConstant1
              , NumericConstant2
            >::type
        >::type
#endif  // BOOST_MPL_CFG_MSVC_ETI_BUG
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            2
          , gcd
          , (NumericConstant1, NumericConstant2)
        )
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_MATH_EUCLID_GCD_HELPER_TYPEDEFS

#endif  // BOOST_MPL_MATH_GCD_HPP_INCLUDED

