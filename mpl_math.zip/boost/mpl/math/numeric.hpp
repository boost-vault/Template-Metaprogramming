// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_NUMERIC_HPP_INCLUDED
#define BOOST_MPL_MATH_NUMERIC_HPP_INCLUDED

#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/math/abs.hpp>
#include <boost/mpl/math/is_odd.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>
#include <boost/mpl/math/integral_part.hpp>
#include <boost/mpl/math/fractional_part.hpp>
#include <boost/mpl/math/real_part.hpp>
#include <boost/mpl/math/imaginary_part.hpp>

#endif  // BOOST_MPL_MATH_NUMERIC_HPP_INCLUDED

