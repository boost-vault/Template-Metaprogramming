// Copyright (C) 2005-2011 Peder Holt
// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_ARCUS_TANGENT_HPP_INCLUDED
#define BOOST_MPL_MATH_ARCUS_TANGENT_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_ARCUS_TANGENT_SERIES
#define BOOST_MPL_LIMIT_MATH_ARCUS_TANGENT_SERIES 8
#endif

#include <boost/cstdint.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/less.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/error/input_out_of_domain.hpp>
#include <boost/mpl/math/one.hpp>

#define BOOST_MPL_MATH_ARCUS_TANGENT_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        BOOST_STATIC_CONSTANT( \
            boost::intmax_t \
          , BOOST_PP_CAT(constant_, BOOST_PP_INC(x)) = \
                ((BOOST_MPL_LIMIT_MATH_ARCUS_TANGENT_SERIES - x) << 1) + 1 \
        ); \
        typedef typename minus< \
                    divides< \
                        NumericConstant \
                      , integral_c< \
                            boost::intmax_t \
                          , BOOST_PP_CAT(constant_, BOOST_PP_INC(x)) \
                        > \
                    > \
                  , times<n_squared,BOOST_PP_CAT(prefix, x)> \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {
  namespace aux {

    template <typename NumericConstant>
    struct arcus_tangent_series
    {
     private:
        /*
         * Compile-time Maclaurin series
         */
        typedef typename times<NumericConstant,NumericConstant>::type
                n_squared;
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , constant_0 =
                ((BOOST_MPL_LIMIT_MATH_ARCUS_TANGENT_SERIES + 1) << 1) + 1
        );
        typedef typename divides<
                    NumericConstant
                  , integral_c<boost::intmax_t,constant_0>
                >::type
        BOOST_PP_REPEAT(
            BOOST_MPL_LIMIT_MATH_ARCUS_TANGENT_SERIES
          , BOOST_MPL_MATH_ARCUS_TANGENT_MACRO
          , term_
        )
                last_term;

     public:
        typedef typename minus<
                    NumericConstant
                  , times<n_squared,last_term>
                >::type
                type;
    };
  }  // namespace aux

    template <typename NumericTag>
    struct arcus_tangent_impl
    {
     private:
        typedef typename one_dispatch<NumericTag>::type
                one_type;
        typedef typename negate<one_type>::type
                negative_one_type;

     public:
        template <typename NumericConstant>
        struct apply
        {
            typedef typename eval_if<
                        less<NumericConstant,negative_one_type>
                      , boost::mpl::error::input_out_of_domain
                      , eval_if<
                            less<one_type,NumericConstant>
                          , boost::mpl::error::input_out_of_domain
                          , aux::arcus_tangent_series<NumericConstant>
                        >
                    >::type
                    type;
        };
    };

    template <typename NumericConstant>
    struct arcus_tangent
      : apply_wrap1<
            arcus_tangent_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, arcus_tangent, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_LIMIT_MATH_ARCUS_TANGENT_SERIES
#undef BOOST_MPL_MATH_ARCUS_TANGENT_MACRO

#endif  // BOOST_MPL_MATH_ARCUS_TANGENT_HPP_INCLUDED

