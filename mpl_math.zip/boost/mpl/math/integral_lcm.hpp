// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_INTEGRAL_LCM_HPP_INCLUDED
#define BOOST_MPL_MATH_INTEGRAL_LCM_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/config/eti.hpp>
#include <boost/mpl/aux_/msvc_eti_base.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/integral_gcd.hpp>

namespace boost { namespace mpl { namespace math {
  namespace aux {

    template <typename ValueType>
    struct integral_lcm_impl
    {
        template <ValueType N1, ValueType N2>
        struct helper
        {
         private:
            typedef typename integral_gcd_impl<
                        ValueType
                    >::BOOST_NESTED_TEMPLATE apply<N1,N2>::type
                    gcd_type;
            BOOST_STATIC_CONSTANT(
                ValueType
              , value = N1 / gcd_type::value * N2
            );

         public:
            typedef integral_c<ValueType,value> type;
        };

        template <ValueType N1, ValueType N2>
        struct apply
        {
#if defined(BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC)
         private:
            BOOST_STATIC_CONSTANT(bool, is_n1_zero = (N1 == 0));
            BOOST_STATIC_CONSTANT(bool, is_n2_zero = (N2 == 0));

         public:
            typedef typename eval_if_c<
                        is_n1_zero
                      , integral_c<ValueType,N1>
                      , eval_if_c<
                            is_n2_zero
                          , integral_c<ValueType,N2>
                          , helper<N1,N2>
                        >
                    >::type
                    type;
#else
            typedef typename eval_if_c<
                        0 == N1
                      , integral_c<ValueType,N1>
                      , eval_if_c<
                            0 == N2
                          , integral_c<ValueType,N2>
                          , helper<N1,N2>
                        >
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
        };
    };
  }  // namespace aux

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename ValueType, boost::intmax_t N1, boost::intmax_t N2>
#else
    template <typename ValueType, ValueType N1, ValueType N2>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct integral_lcm
#if !defined(BOOST_MPL_CFG_MSVC_ETI_BUG)
      : aux::integral_lcm_impl<
            ValueType
        >::BOOST_NESTED_TEMPLATE apply<N1,N2>::type
#else
      : boost::mpl::aux::msvc_eti_base<
            typename aux::integral_lcm_impl<
                ValueType
            >::BOOST_NESTED_TEMPLATE apply<N1,N2>::type
        >::type
#endif  // BOOST_MPL_CFG_MSVC_ETI_BUG
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_INTEGRAL_LCM_HPP_INCLUDED

