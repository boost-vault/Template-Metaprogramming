// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_FWD_HPP_INCLUDED

#include <boost/cstdint.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename IntegralConstant>
    struct integral_to_mixed_number_c;

    template <boost::intmax_t Value>
    struct integral_c_to_mixed_number_c;

    template <typename RationalConstant>
    struct rational_to_mixed_number_c;

    template <boost::intmax_t N, boost::intmax_t D>
    struct rational_c_to_mixed_number_c;

    template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
    struct mixed_number_c;
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_FWD_HPP_INCLUDED

