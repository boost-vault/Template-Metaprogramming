// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_SHIFT_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_SHIFT_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <boost::int16_t Amount>
    struct shift_sign
    {
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , value = ((0 < Amount) ? 1 : (Amount < 0) ? -1 : 0)
        );
    };

    template <boost::int16_t sign>
    struct shift_integral_impl
    {
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        template <typename IntType, long Value, boost::int16_t Amount>
#else
        template <typename IntType, IntType Value, boost::int16_t Amount>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        struct apply
        {
            BOOST_STATIC_CONSTANT(IntType, value = Value);
        };
    };

    template <>
    struct shift_integral_impl<32>
    {
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        template <typename IntType, long Value, boost::int16_t Amount>
#else
        template <typename IntType, IntType Value, boost::int16_t Amount>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        struct apply
        {
            BOOST_STATIC_CONSTANT(IntType, value = 0);
        };
    };

    template <>
    struct shift_integral_impl<1>
    {
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        template <typename IntType, long Value, boost::int16_t Amount>
#else
        template <typename IntType, IntType Value, boost::int16_t Amount>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        struct apply
        {
            BOOST_STATIC_CONSTANT(IntType, value = Value << Amount);
        };
    };

    template <>
    struct shift_integral_impl<-1>
    {
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        template <typename IntType, long Value, boost::int16_t Amount>
#else
        template <typename IntType, IntType Value, boost::int16_t Amount>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        struct apply
        {
            BOOST_STATIC_CONSTANT(IntType, value = Value >> -Amount);
        };
    };

    template <>
    struct shift_integral_impl<-32>
    {
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        template <typename IntType, long Value, boost::int16_t Amount>
#else
        template <typename IntType, IntType Value, boost::int16_t Amount>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
        struct apply
        {
            BOOST_STATIC_CONSTANT(IntType, value = 0);
        };
    };

    template <boost::int16_t Amount>
    struct shift_sign_overflow
    {
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , value =
            (
                (0 < Amount)
              ? ((Amount < 32) ? 1 : 32)
              : (Amount < 0)
              ? ((-32 < Amount) ? -1 : -32)
              : 0
            )
        );
    };

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, long Value, boost::int16_t Amount>
#else
    template <typename IntType, IntType Value, boost::int16_t Amount>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct shift_integral
      : shift_integral_impl<
            shift_sign_overflow<Amount>::value
        >::BOOST_NESTED_TEMPLATE apply<IntType,Value,Amount>
    {
    };

    template <int16_t sign>
    struct shift_mantissa_impl
    {
        template <typename Mantissa, boost::int16_t Amount>
        struct apply
        {
            BOOST_STATIC_CONSTANT(boost::uint32_t, part1 = Mantissa::part1);
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part2 = Mantissa::part2 & 0x7fffffff
            );
        };
    };

    template <>//left shift
    struct shift_mantissa_impl<1>
    {
        template <typename Mantissa, boost::int16_t Amount>
        struct apply
        {
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part1 =
                (
                    shift_integral<
                        boost::uint32_t
                      , Mantissa::part1
                      , Amount
                    >::value
                  | shift_integral<
                        boost::uint32_t
                      , Mantissa::part2
                      , Amount - 31
                    >::value
                )
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part2 =
                (
                    shift_integral<
                        boost::uint32_t
                      , Mantissa::part2
                      , Amount
                    >::value
                  & 0x7fffffff
                )
            );
        };
    };

    template <>//right shift
    struct shift_mantissa_impl<-1>
    {
        template <typename Mantissa, boost::int16_t Amount>
        struct apply
        {
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part1 =
                (
                    shift_integral<
                        boost::uint32_t
                      , Mantissa::part1
                      , Amount
                    >::value
                )
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part2 =
                (
                    (
                        shift_integral<
                            boost::uint32_t
                          , Mantissa::part2
                          , Amount
                        >::value
                      | shift_integral<
                            boost::uint32_t
                          , Mantissa::part1
                          , Amount + 31
                        >::value
                    )
                  & 0x7fffffff
                )
            );
        };
    };

    template <typename Mantissa, boost::int16_t Amount>
    struct shift_mantissa
      : shift_mantissa_impl<
            shift_sign<Amount>::value
        >::BOOST_NESTED_TEMPLATE apply<Mantissa,Amount>
    {
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_SHIFT_HPP_INCLUDED

