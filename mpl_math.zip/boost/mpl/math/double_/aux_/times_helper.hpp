// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_TIMES_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_TIMES_HELPER_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/math/double_/limits.hpp>
#include <boost/mpl/math/double_/aux_/times_filter.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>
#include <boost/mpl/math/double_/aux_/normalize.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename Interval1, typename Interval2>
    struct times_helper_impl
    {
        template <typename N1, typename N2>
        struct apply
        {
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , lhs1 = N1::mantissa::part1 >> 15
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , lhs2 = N1::mantissa::part1 & 0x7fff
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , lhs3 = N1::mantissa::part2 >> 16
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , lhs4 = (N1::mantissa::part2 >> 1) & 0x7fff
            );

            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , rhs1 = N2::mantissa::part1 >> 15
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , rhs2 = N2::mantissa::part1 & 0x7fff
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , rhs3 = N2::mantissa::part2 >> 16
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , rhs4 = (N2::mantissa::part2 >> 1) & 0x7fff
            );

            BOOST_STATIC_CONSTANT(boost::uint32_t, result0 = lhs1 * rhs1);
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , result15 = lhs1 * rhs2 + lhs2 * rhs1
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , result30 = lhs1 * rhs3 + lhs3 * rhs1 + lhs2 * rhs2
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , result45 = lhs1 * rhs4 + lhs3 * rhs2 + lhs2 * rhs3 + lhs4 * rhs1
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , result60 = lhs2 * rhs4 + lhs3 * rhs3 + lhs4 * rhs2
            );

            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part1_pre = result0 + (result15 >> 15) + (result30 >> 30)
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part2_pre = (
                    (
                      + ((result15 << 15) & 0x3fffffff)
                      + (result30 & 0x3fffffff)
                      + (result45 >> 15)
                      + (result60 >> 30)
                    )
                 << 1
                )
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part1 = part1_pre + ((part2_pre & 0x80000000) ? 1 : 0)
            );
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part2 = part2_pre & 0x7fffffff
            );
            BOOST_STATIC_CONSTANT(
                boost::int16_t
              , exponent = N1::exponent + N2::exponent
            );
            BOOST_STATIC_CONSTANT(bool, sign = N1::sign != N2::sign);

            typedef typename normalize<
                        mantissa<part1,part2>
                      , exponent
                      , sign
                    >::type
                    type;
        };
    };

    template <>
    struct times_helper_impl<NaN,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct times_helper_impl<NaN,infinity>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };
        
    template <>
    struct times_helper_impl<NaN,zero>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct times_helper_impl<NaN,double>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct times_helper_impl<infinity,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct times_helper_impl<zero,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct times_helper_impl<double,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };       
        
    template <>
    struct times_helper_impl<infinity,infinity>
    {
        template <typename N1, typename N2>
        struct apply
        {
            BOOST_STATIC_CONSTANT(bool, same_sign = (N1::sign == N2::sign));
            typedef typename if_c<
                        same_sign
                      , infinity
                      , negative_infinity
                    >::type
                    type;
        };
    };

    template <>
    struct times_helper_impl<infinity,zero>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct times_helper_impl<zero,infinity>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <typename N1, typename N2>
    struct times_helper
      : apply_wrap2<
            times_helper_impl<
                typename times_filter<N1>::type
              , typename times_filter<N2>::type
            >
          , N1
          , N2
        >::type
    {
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_TIMES_HELPER_HPP_INCLUDED

