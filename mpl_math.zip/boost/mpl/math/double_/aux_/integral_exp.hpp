// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_INTEGRAL_EXP_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_INTEGRAL_EXP_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t Number>
#else
    template <typename IntType, IntType Number>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct integral_exp
    {
        BOOST_STATIC_CONSTANT(boost::int32_t, sign = ((Number < 0) ? -1 : 1));
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , number = sign * Number
        );
	    BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp16 = (number < 65536) ? 0 : 16
        );
	    BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp8 = (number < (1 << (exp16 + 8))) ? 0 : 8
        );
	    BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp4 = (number < (1 << (exp16 + exp8 + 4))) ? 0 : 4
        );
	    BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp2 = (number < (1 << (exp16 + exp8 + exp4 + 2))) ? 0 : 2
        );
	    BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp1 = (number < (1 << (exp16 + exp8 + exp4 + exp2 + 1))) ? 0 : 1
        );
	    BOOST_STATIC_CONSTANT(
            boost::int16_t
          , value = exp16 + exp8 + exp4 + exp2 + exp1
        );
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_INTEGRAL_EXP_HPP_INCLUDED

