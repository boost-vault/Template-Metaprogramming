// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_INTEGRAL_PART_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_INTEGRAL_PART_HELPER_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/integral_c.hpp>

#ifndef BOOST_HAS_LONG_LONG
#error Your compiler cannot convert doubles to rationals at compile time.
#include <boost/mpl/math/big_integral/impl_fwd.hpp>
#include <boost/mpl/shift_left.hpp>
#include <boost/mpl/math/double_/aux_/make_big_integral_mantissa.hpp>
#endif  // BOOST_HAS_LONG_LONG

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

#ifdef BOOST_HAS_LONG_LONG
    template <boost::uint16_t sixty_two>
    struct integral_part_helper_impl
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            typedef typename DoubleConstant::mantissa DoubleMantissa;
            BOOST_STATIC_CONSTANT(
                ulong_long_type
              , abs_value = (
                    (
                        static_cast<ulong_long_type>(DoubleMantissa::part1)
                     << 31
                    )
                  | (DoubleMantissa::part2 & 0x7fffffff)
                )
            );
            BOOST_STATIC_CONSTANT(
                long_long_type
              , value = (
                    (
                        DoubleConstant::sign
                      ? -static_cast<long_long_type>(abs_value)
                      : abs_value
                    )
                 << (DoubleConstant::exponent - 61)
                )
            );

         public:
            typedef integral_c<long_long_type,value> type;
        };
    };

    template <>
    struct integral_part_helper_impl<61>
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            typedef typename DoubleConstant::mantissa DoubleMantissa;
            BOOST_STATIC_CONSTANT(
                ulong_long_type
              , abs_value = (
                    (
                        static_cast<ulong_long_type>(DoubleMantissa::part1)
                     << 31
                    )
                  | (DoubleMantissa::part2 & 0x7fffffff)
                )
            );
            BOOST_STATIC_CONSTANT(
                long_long_type
              , value = (
                    (
                        DoubleConstant::sign
                      ? -static_cast<long_long_type>(abs_value)
                      : abs_value
                    )
                 >> (61 - DoubleConstant::exponent)
                )
            );

         public:
            typedef integral_c<long_long_type,value> type;
        };
    };
#else  // ifndef BOOST_HAS_LONG_LONG
    template <boost::uint16_t sixty_one>
    struct integral_part_helper_impl
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            BOOST_STATIC_CONSTANT(
                boost::int16_t
              , left_shift = DoubleConstant::exponent - 61
            );

         public:
            typedef shift_left<
                        big_integral_impl<
                            bool_<DoubleConstant::sign>
                          , make_big_integral_mantissa<
                                typename DoubleConstant::mantissa
                            >
                        >
                      , integral_c<boost::int16_t,left_shift>
                    >
                    type;
        };
    };
#endif  // BOOST_HAS_LONG_LONG

    template <>
    struct integral_part_helper_impl<30>
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            typedef typename DoubleConstant::mantissa DoubleMantissa;
            BOOST_STATIC_CONSTANT(
                boost::int32_t
              , value = (
                    DoubleConstant::sign
                  ? -static_cast<boost::int32_t>(
                        DoubleMantissa::part1
                     >> (30 - DoubleConstant::exponent)
                    )
                  : (DoubleMantissa::part1 >> (30 - DoubleConstant::exponent))
                )
            );

         public:
            typedef integral_c<boost::int32_t,value> type;
        };
    };

    template <>
    struct integral_part_helper_impl<0>
    {
        template <typename DoubleConstant>
        struct apply
        {
            typedef integral_c<boost::int32_t,0> type;
        };
    };

    template <boost::int16_t exponent>
    struct integral_part_selector
    {
#ifdef BOOST_HAS_LONG_LONG
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , value = (
                (exponent < 0)
              ? 0
              : (exponent < 30)
              ? 30
              : (exponent < 61)
              ? 61
              : 62
            )
        );
#else  // ifndef BOOST_HAS_LONG_LONG
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , value = (exponent < 0) ? 0 : (exponent < 30) ? 30 : 61
        );
#endif  // BOOST_HAS_LONG_LONG
    };

    template <typename DoubleConstant>
    struct integral_part_helper
      : integral_part_helper_impl<
            integral_part_selector<DoubleConstant::exponent>::value
        >::BOOST_NESTED_TEMPLATE apply<DoubleConstant>
    {
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_INTEGRAL_PART_HELPER_HPP_INCLUDED

