// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_PLUS_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_PLUS_HELPER_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/math/double_/limits.hpp>
#include <boost/mpl/math/double_/aux_/additive.hpp>
#include <boost/mpl/math/double_/aux_/shift.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename Interval1, typename Interval2>
    struct plus_helper_impl
    {
        template <typename N1, typename N2>
        struct apply
        {
            BOOST_STATIC_CONSTANT(
                boost::int16_t
              , exp_diff = N1::exponent - N2::exponent
            );
            BOOST_STATIC_CONSTANT(
                boost::int16_t
              , exponent = (exp_diff < 0) ? N2::exponent : N1::exponent
            );
            typedef shift_mantissa<
                        typename N1::mantissa
                      , (exp_diff < 0 ? exp_diff : 0)
                    >
                    mantissa1;
            typedef shift_mantissa<
                        typename N2::mantissa
                      , (exp_diff < 0 ? 0 : -exp_diff)
                    >
                    mantissa2;
            BOOST_STATIC_CONSTANT(
                bool
              , sign = (
                    if_<
                        typename less_mantissa<mantissa1,mantissa2>::type
                      , bool_<N2::sign>
                      , bool_<N1::sign>
                    >::type::value
                )
            );
            typedef typename if_<
                        typename less_mantissa<mantissa1,mantissa2>::type
                      , mantissa1
                      , mantissa2
                    >::type
                    least_mantissa;

            typedef typename if_<
                        typename less_mantissa<mantissa1,mantissa2>::type
                      , mantissa2
                      , mantissa1
                    >::type
                    greatest_mantissa;

            BOOST_STATIC_CONSTANT(bool, equal_sign = (N1::sign == N2::sign));

            typedef typename eval_if_c<
                        equal_sign
                      , add_double<
                            greatest_mantissa
                          , least_mantissa
                          , exponent
                          , sign
                        >
                      , sub_double<
                            greatest_mantissa
                          , least_mantissa
                          , exponent
                          , sign
                        >
                    >::type
                    type;
        };
    };

    template <>
    struct plus_helper_impl<NaN,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct plus_helper_impl<NaN,infinity>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };
        
    template <>
    struct plus_helper_impl<NaN,double>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct plus_helper_impl<infinity,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };

    template <>
    struct plus_helper_impl<double,NaN>
    {
        template <typename N1, typename N2>
        struct apply
          : NaN
        {
        };
    };       
        
    template<>
    struct plus_helper_impl<infinity,infinity>
    {
        template <typename N1, typename N2>
        struct apply
        {
            BOOST_STATIC_CONSTANT(bool, same_sign = (N1::sign == N2::sign));
            typedef typename if_c<same_sign,N1,NaN>::type
                    type;
        };
    };

    template <typename N>
    struct plus_filter
    {
        typedef typename eval_if<
                    is_NaN<N>
                  , NaN
                  , if_<is_finite<N>,double,infinity>
                >::type
                type;
    };

    template <typename N1, typename N2>
    struct plus_helper
      : apply_wrap2<
            plus_helper_impl<
                typename plus_filter<N1>::type
              , typename plus_filter<N2>::type
            >
          , N1
          , N2
        >::type
    {
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_PLUS_HELPER_HPP_INCLUDED

