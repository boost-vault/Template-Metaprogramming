// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_NEGATE_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_NEGATE_HELPER_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/double_/double_c.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename N>
    struct negate_helper
    {
        BOOST_STATIC_CONSTANT(bool, sign = !N::sign);
        typedef double_c<typename N::mantissa,N::exponent,sign> type;
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_NEGATE_HELPER_HPP_INCLUDED

