// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_FRACTIONAL_PART_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_FRACTIONAL_PART_HELPER_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/fractional_part.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>
#include <boost/mpl/math/double_/double_c.hpp>
#include <boost/mpl/math/double_/limits.hpp>
#include <boost/mpl/math/double_/aux_/minus_helper.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <boost::uint16_t sixty_two>
    struct fractional_part_helper_impl
    {
        template <typename DoubleConstant>
        struct apply
        {
            typedef boost::mpl::math::double_::zero type;
        };
    };

    template <>
    struct fractional_part_helper_impl<61>
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            typedef typename DoubleConstant::mantissa
                    DoubleMantissa;
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part2 = (
                    DoubleMantissa::part2
                  & (
                        ((1 << (DoubleConstant::exponent - 30)) - 1)
                     << (61 - DoubleConstant::exponent)
                    )
                )
            );

         public:
            typedef typename minus_helper<
                        DoubleConstant
                      , double_c<
                            mantissa<DoubleMantissa::part1,part2>
                          , DoubleConstant::exponent
                          , DoubleConstant::sign
                        >
                    >::type
                    type;
        };
    };

    template <>
    struct fractional_part_helper_impl<30>
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            typedef typename DoubleConstant::mantissa
                    DoubleMantissa;
            BOOST_STATIC_CONSTANT(
                boost::uint32_t
              , part1 = (
                    DoubleMantissa::part1
                  & (
                        ((1 << (DoubleConstant::exponent + 1)) - 1)
                     << (30 - DoubleConstant::exponent)
                    )
                )
            );

         public:
            typedef typename minus_helper<
                        DoubleConstant
                      , double_c<
                            mantissa<part1,0>
                          , DoubleConstant::exponent
                          , DoubleConstant::sign
                        >
                    >::type
                    type;
        };
    };

    template <>
    struct fractional_part_helper_impl<0>
    {
        template <typename DoubleConstant>
        struct apply
        {
            typedef DoubleConstant type;
        };
    };

    template <boost::int16_t exponent>
    struct fractional_part_selector
    {
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , value = (
                (exponent < 0)
              ? 0
              : (exponent < 30)
              ? 30
              : (exponent < 61)
              ? 61
              : 62
            )
        );
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_FRACTIONAL_PART_HELPER_HPP_INCLUDED

