// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_GET_VALUE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_GET_VALUE_HPP_INCLUDED

#include <boost/mpl/aux_/config/endian.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    struct encoding
    {
#if defined(BOOST_MPL_CFG_IS_BIG_ENDIAN)
        unsigned long sign:1;
        unsigned long exp:11;
        unsigned long mantissa1:20;
        unsigned long mantissa2;
#else
        unsigned long mantissa2;
        unsigned long mantissa1:20;
        unsigned long exp:11;
        unsigned long sign:1;
#endif  // BOOST_MPL_CFG_IS_BIG_ENDIAN
    };

    union converter_
    {
        double value;
        encoding encode;
    };

    template <typename DoubleConstant>
    double get_value(DoubleConstant const& arg)
    {
        typedef typename DoubleConstant::mantissa t_mantissa;

        converter_ converter;
        converter.encode.sign = DoubleConstant::sign;
        converter.encode.exp = DoubleConstant::exponent + 1023;
        converter.encode.mantissa1 = t_mantissa::part1 >> 10;
        converter.encode.mantissa2 = (
            (t_mantissa::part1 << 22)
          | (t_mantissa::part2 >> 9)
        );
        return converter.value;
    }
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_GET_VALUE_HPP_INCLUDED

