// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_TO_SIMPLIFIED_RATIONAL_C_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_TO_SIMPLIFIED_RATIONAL_C_HPP_INCLUDED

#ifndef BOOST_HAS_LONG_LONG
#error Your compiler cannot convert doubles to rationals at compile time.
#endif  // BOOST_HAS_LONG_LONG

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/simplified_rational_c.hpp>
#include <boost/mpl/math/double_/limits.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename DoubleConstant>
    struct to_simplified_rational_dispatch
    {
     private:
        typedef typename DoubleConstant::mantissa
                DoubleMantissa;
        BOOST_STATIC_CONSTANT(
            ulong_long_type
          , new_mantissa = (
                (
                    static_cast<ulong_long_type>(DoubleMantissa::part1)
                 << 31
                )
              | (DoubleMantissa::part2 & 0x7fffffff)
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , min_1_bit = (
                DoubleMantissa::part2
              ? (
                    (DoubleMantissa::part2 & 0x0000ffff)
                  ? (
                        (DoubleMantissa::part2 & 0x000000ff)
                      ? (
                            (DoubleMantissa::part2 & 0x0000000f)
                          ? (
                                (DoubleMantissa::part2 & 0x00000003)
                              ? ((DoubleMantissa::part2 & 0x00000001) ? 0 : 1)
                              : ((DoubleMantissa::part2 & 0x00000004) ? 2 : 3)
                            )
                          : (
                                (DoubleMantissa::part2 & 0x00000030)
                              ? ((DoubleMantissa::part2 & 0x00000010) ? 4 : 5)
                              : ((DoubleMantissa::part2 & 0x00000040) ? 6 : 7)
                            )
                        )
                      : (
                            (DoubleMantissa::part2 & 0x00000f00)
                          ? (
                                (DoubleMantissa::part2 & 0x00000300)
                              ? ((DoubleMantissa::part2 & 0x00000100) ? 8 : 9)
                              : ((DoubleMantissa::part2 & 0x00000400) ? 10 : 11)
                            )
                          : (
                                (DoubleMantissa::part2 & 0x00003000)
                              ? ((DoubleMantissa::part2 & 0x00001000) ? 12 : 13)
                              : ((DoubleMantissa::part2 & 0x00004000) ? 14 : 15)
                            )
                        )
                    )
                  : (
                        (DoubleMantissa::part2 & 0x00ff0000)
                      ? (
                            (DoubleMantissa::part2 & 0x000f0000)
                          ? (
                                (DoubleMantissa::part2 & 0x00030000)
                              ? ((DoubleMantissa::part2 & 0x00010000) ? 16 : 17)
                              : ((DoubleMantissa::part2 & 0x00040000) ? 18 : 19)
                            )
                          : (
                                (DoubleMantissa::part2 & 0x00300000)
                              ? ((DoubleMantissa::part2 & 0x00100000) ? 20 : 21)
                              : ((DoubleMantissa::part2 & 0x00400000) ? 22 : 23)
                            )
                        )
                      : (
                            (DoubleMantissa::part2 & 0x0f000000)
                          ? (
                                (DoubleMantissa::part2 & 0x03000000)
                              ? ((DoubleMantissa::part2 & 0x01000000) ? 24 : 25)
                              : ((DoubleMantissa::part2 & 0x04000000) ? 26 : 27)
                            )
                          : (
                                (DoubleMantissa::part2 & 0x30000000)
                              ? ((DoubleMantissa::part2 & 0x10000000) ? 28 : 29)
                              : 30
                            )
                        )
                    )
                )
              : (
                    (DoubleMantissa::part1 & 0x0000ffff)
                  ? (
                        (DoubleMantissa::part1 & 0x000000ff)
                      ? (
                            (DoubleMantissa::part1 & 0x0000000f)
                          ? (
                                (DoubleMantissa::part1 & 0x00000003)
                              ? ((DoubleMantissa::part1 & 0x00000001) ? 31 : 32)
                              : ((DoubleMantissa::part1 & 0x00000004) ? 33 : 34)
                            )
                          : (
                                (DoubleMantissa::part1 & 0x00000030)
                              ? ((DoubleMantissa::part1 & 0x00000010) ? 35 : 36)
                              : ((DoubleMantissa::part1 & 0x00000040) ? 37 : 38)
                            )
                        )
                      : (
                            (DoubleMantissa::part1 & 0x00000f00)
                          ? (
                                (DoubleMantissa::part1 & 0x00000300)
                              ? ((DoubleMantissa::part1 & 0x00000100) ? 39 : 40)
                              : ((DoubleMantissa::part1 & 0x00000400) ? 41 : 42)
                            )
                          : (
                                (DoubleMantissa::part1 & 0x00003000)
                              ? ((DoubleMantissa::part1 & 0x00001000) ? 43 : 44)
                              : ((DoubleMantissa::part1 & 0x00004000) ? 45 : 46)
                            )
                        )
                    )
                  : (
                        (DoubleMantissa::part1 & 0x00ff0000)
                      ? (
                            (DoubleMantissa::part1 & 0x000f0000)
                          ? (
                                (DoubleMantissa::part1 & 0x00030000)
                              ? ((DoubleMantissa::part1 & 0x00010000) ? 47 : 48)
                              : ((DoubleMantissa::part1 & 0x00040000) ? 49 : 50)
                            )
                          : (
                                (DoubleMantissa::part1 & 0x00300000)
                              ? ((DoubleMantissa::part1 & 0x00100000) ? 51 : 52)
                              : ((DoubleMantissa::part1 & 0x00400000) ? 53 : 54)
                            )
                        )
                      : (
                            (DoubleMantissa::part1 & 0x0f000000)
                          ? (
                                (DoubleMantissa::part1 & 0x03000000)
                              ? ((DoubleMantissa::part1 & 0x01000000) ? 55 : 56)
                              : ((DoubleMantissa::part1 & 0x04000000) ? 57 : 58)
                            )
                          : (
                                (DoubleMantissa::part1 & 0x30000000)
                              ? ((DoubleMantissa::part1 & 0x10000000) ? 59 : 60)
                              : 61
                            )
                        )
                    )
                )
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , numerator_length = 61 - min_1_bit
        );
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , numerator_shift = (
                (numerator_length < DoubleConstant::exponent)
              ? (61 - DoubleConstant::exponent)
              : min_1_bit
            )
        );
        BOOST_STATIC_CONSTANT(
            long_long_type
          , numerator_value = (
                DoubleConstant::sign
              ? -static_cast<long_long_type>(new_mantissa >> numerator_shift)
              : (new_mantissa >> numerator_shift)
            )
        );
        BOOST_STATIC_CONSTANT(
            long_long_type
          , denominator_value = (
                1ll
             << (
                    (numerator_length < DoubleConstant::exponent)
                  ? 0
                  : (numerator_length - DoubleConstant::exponent)
                )
            )
        );

     public:
        typedef simplified_rational_c<
                    long_long_type
                  , numerator_value
                  , denominator_value
                >
                type;
    };

    template <typename DoubleConstant>
    struct to_simplified_rational_c
      : eval_if<
            boost::mpl::math::double_::is_zero<DoubleConstant>
          , simplified_rational_c<boost::intmax_t,0,1>
          , to_simplified_rational_dispatch<DoubleConstant>
        >
    {
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_TO_SIMPLIFIED_RATIONAL_C_HPP_INCLUDED

