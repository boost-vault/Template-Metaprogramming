// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_MANTISSA_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_MANTISSA_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/bool.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <boost::uint32_t Part1, boost::uint32_t Part2>
    struct mantissa
    {
        BOOST_STATIC_CONSTANT(boost::uint32_t, part1 = Part1);
        BOOST_STATIC_CONSTANT(boost::uint32_t, part2 = Part2);        
    };

    template <typename Mantissa1, typename Mantissa2>
    struct less_mantissa 
    {
     private:
        BOOST_STATIC_CONSTANT(
            bool
          , value = (
                (Mantissa1::part1 == Mantissa2::part1)
              ? (Mantissa1::part2 < Mantissa2::part2)
              : (Mantissa1::part1 < Mantissa2::part1)
            )
        );

     public:
        typedef bool_<value> type;
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_MANTISSA_HPP_INCLUDED

