// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_ADDITIVE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_ADDITIVE_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/double_/aux_/normalize.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <
        typename Mantissa1
      , typename Mantissa2
      , boost::int16_t Exponent
      , bool Sign
    >
    struct add_double
    {
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part1 =
                (Mantissa1::part1 + Mantissa2::part1)
              + (((Mantissa1::part2 + Mantissa2::part2) & 0x80000000) ? 1 : 0)
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part2 = (Mantissa1::part2 + Mantissa2::part2) & 0x7fffffff
        );
        typedef typename normalize<mantissa<part1,part2>,Exponent,Sign>::type
                type;
    };

    template <
        typename Mantissa1
      , typename Mantissa2
      , boost::int16_t Exponent
      , bool Sign
    >
    struct sub_double
    {
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part1 =
                (Mantissa1::part1 - Mantissa2::part1)
              - (Mantissa1::part2 < Mantissa2::part2 ? 1 : 0)
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part2 =
                (
                    Mantissa1::part2
                  | (Mantissa1::part2 < Mantissa2::part2 ? 0x80000000 : 0)
                )
              - Mantissa2::part2
        );
        typedef typename normalize<mantissa<part1,part2>,Exponent,Sign>::type
                type;
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_ADDITIVE_HPP_INCLUDED

