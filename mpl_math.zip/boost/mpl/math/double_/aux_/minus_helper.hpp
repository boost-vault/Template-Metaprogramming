// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_MINUS_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_MINUS_HELPER_HPP_INCLUDED

#include <boost/mpl/math/double_/aux_/negate_helper.hpp>
#include <boost/mpl/math/double_/aux_/plus_helper.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename N1, typename N2>
    struct minus_helper
      : plus_helper<N1,typename negate_helper<N2>::type>::type
    {
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_MINUS_HELPER_HPP_INCLUDED

