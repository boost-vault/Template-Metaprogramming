// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_AUX_NORMALIZE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_AUX_NORMALIZE_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/double_/double_c.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>
#include <boost/mpl/math/double_/aux_/shift.hpp>
#include <boost/mpl/math/double_/aux_/integral_exp.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename Mantissa, int16_t Exponent, bool Sign>
    struct normalize
    {
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp1 = (integral_exp<uint32_t,Mantissa::part1>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp2 = (integral_exp<uint32_t,Mantissa::part2>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp_shift = (
                ((exp1 == 0) && (exp2 == 0))
              ? ((Exponent == 1024) ? 0 : -Exponent - 1023)
              : (exp1 > 0)
              ? (exp1 - 30)
              : (exp2 - 61)
            )
        );
        typedef shift_mantissa<Mantissa,-exp_shift>
                shifted_mantissa;
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exponent = (
                (Exponent + exp_shift < 1024)
              ? (Exponent + exp_shift)
              : 1024
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part1 = (exponent == 1024) ? 0 : shifted_mantissa::part1
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part2 = (exponent == 1024) ? 0 : shifted_mantissa::part2
        );
        typedef double_c<mantissa<part1,part2>,exponent,Sign>
                type;
    };

    template <typename Double>
    struct round
    {
        typedef typename Double::mantissa
                unnormalized_mantissa;
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part2 = (
                (unnormalized_mantissa::part2 & 0xfffffffd)
              + (
                    ((unnormalized_mantissa::part2 & 0x00000002) == 0x00000002)
                  ? 0x00000004
                  : 0
                )
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part1 = (
                unnormalized_mantissa::part1
              + ((part2 & 0x80000000) ? 1 : 0)
            )
        );
        typedef typename normalize<
                    mantissa<part1,part2>
                  , Double::exponent
                  , Double::sign
                >::type
                type;
    };

    template <typename Double>
    struct cutoff
    {
        typedef typename Double::mantissa
                unnormalized_mantissa;
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part2 = unnormalized_mantissa::part2 & 0x7ffffffd
        );
        typedef double_c<
                    mantissa<unnormalized_mantissa::part1,part2>
                  , Double::exponent
                  , Double::sign
                >
                type;
    };
  }}  // namespace double_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_AUX_NORMALIZE_HPP_INCLUDED

