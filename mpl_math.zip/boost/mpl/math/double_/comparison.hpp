// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_COMPARISON_HPP
#define BOOST_MPL_MATH_DOUBLE_COMPARISON_HPP

#include <boost/mpl/math/double_/equal_to.hpp>
#include <boost/mpl/math/double_/not_equal_to.hpp>
#include <boost/mpl/math/double_/less.hpp>
#include <boost/mpl/math/double_/greater.hpp>
#include <boost/mpl/math/double_/less_equal.hpp>
#include <boost/mpl/math/double_/greater_equal.hpp>

#endif  // BOOST_MPL_MATH_DOUBLE_COMPARISON_HPP

