// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_TIMES_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_TIMES_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/aux_/times_helper.hpp>
#include <boost/mpl/math/double_/aux_/normalize.hpp>

namespace boost { namespace mpl {

    template <>
    struct times_impl<math::double_tag,math::double_tag>
    {
        template <typename N1, typename N2>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::double_::aux::round<math::double_::aux::times_helper<N1,N2> >
        {
#else
        {
            typedef typename math::double_::aux::round<
                        math::double_::aux::times_helper<N1,N2>
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_DOUBLE_TIMES_HPP_INCLUDED

