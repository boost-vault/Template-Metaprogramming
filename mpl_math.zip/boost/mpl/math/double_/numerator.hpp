// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_NUMERATOR_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_NUMERATOR_HPP_INCLUDED

#ifndef BOOST_HAS_LONG_LONG
#error Your compiler cannot convert doubles to rationals at compile time.
#endif  // BOOST_HAS_LONG_LONG

#include <boost/config.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/double_/aux_/to_simplified_rational_c.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <typename RationalTag>
    struct numerator_helper;

    template <>
    struct numerator_helper<rational_c_tag>
    {
        template <typename RationalConstant>
        struct apply
        {
            typedef integral_c<
                        typename RationalConstant::int_type
                      , RationalConstant::num
                    >
                    type;
        };
    };
  }}  // namespace double_::aux

    template <>
    struct numerator_impl<double_tag>
    {
        template <typename DoubleConstant>
        struct apply
        {
         private:
            typedef typename double_::aux::to_simplified_rational_c<
                        DoubleConstant
                    >::type
                    rational_type;

         public:
            typedef typename double_::aux::numerator_helper<
                        typename rational_type::tag
                    >::BOOST_NESTED_TEMPLATE apply<rational_type>::type
                    type;
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_NUMERATOR_HPP_INCLUDED

