// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_DOUBLE_C_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_DOUBLE_C_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_fwd.hpp>
#include <boost/mpl/math/double_/aux_/get_value.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename Mantissa, boost::int16_t Exponent, bool Sign>
    struct double_c
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(double_c)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef double_tag tag;

        /*
         * The relevant parts of a compile-time double.
         */
        typedef double value_type;
        typedef Mantissa mantissa;
        BOOST_STATIC_CONSTANT(bool, sign = Sign);
        BOOST_STATIC_CONSTANT(boost::int16_t, exponent = Exponent);

        operator value_type() const
        {
            return double_::aux::get_value(*this);
        }
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_DOUBLE_C_HPP_INCLUDED

