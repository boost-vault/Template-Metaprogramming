// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_NEGATE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_NEGATE_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/aux_/negate_helper.hpp>

namespace boost { namespace mpl {

    template<>
    struct negate_impl<math::double_tag>
    {
        template <typename DoubleConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::double_::aux::negate_helper<DoubleConstant>
        {
#else
        {
            typedef typename math::double_::aux::negate_helper<
                        DoubleConstant
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_DOUBLE_NEGATE_HPP_INCLUDED

