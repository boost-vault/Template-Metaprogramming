// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_LESS_EQUAL_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_LESS_EQUAL_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/less_equal.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/limits.hpp>

namespace boost { namespace mpl {

    template <>
    struct less_equal_impl<math::double_tag,math::double_tag>
    {
        template <typename N1, typename N2>
        struct apply
        {
            BOOST_STATIC_CONSTANT(
                bool
              , is_zero1 = math::double_::is_zero<N1>::value
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_zero2 = math::double_::is_zero<N2>::value
            );
            BOOST_STATIC_CONSTANT(
                bool
              , value = (
                    (is_zero1 && is_zero2)
                  ? true
                  : N1::sign
                  ? (
                        N2::sign
                      ? (
                            (N1::exponent < N2::exponent)
                          ? false
                          : (N1::mantissa::part1 < N2::mantissa::part1)
                          ? false
                          : !(N1::mantissa::part2 < N2::mantissa::part2)
                        )
                      : true
                    )
                  : N2::sign
                  ? false
                  : (N2::exponent < N1::exponent)
                  ? false
                  : (N2::mantissa::part1 < N1::mantissa::part1)
                  ? false
                  : !(N2::mantissa::part2 < N1::mantissa::part2)
                )
            );
            typedef bool_<value> type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_DOUBLE_LESS_EQUAL_HPP_INCLUDED

