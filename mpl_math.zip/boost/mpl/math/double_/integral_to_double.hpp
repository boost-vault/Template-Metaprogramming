// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_INTEGRAL_TO_DOUBLE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_INTEGRAL_TO_DOUBLE_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/double_fwd.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>
#include <boost/mpl/math/double_/double_c.hpp>
#include <boost/mpl/math/double_/aux_/shift.hpp>
#include <boost/mpl/math/double_/aux_/integral_exp.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ {

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t Value>
#else
    template <typename IntType, IntType Value>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct convert_integral_c
    {
     private:
        BOOST_STATIC_CONSTANT(
            bool
          , sign = Value < 0
        );
        BOOST_STATIC_CONSTANT(
            IntType
          , unsigned_number = sign ? -static_cast<IntType>(Value) : Value
        );
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exponent = (aux::integral_exp<IntType,unsigned_number>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part1 = (
                aux::shift_integral<
                    uint32_t
                  , unsigned_number
                  , 30 - exponent
                >::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , part2 = (
                aux::shift_integral<
                    uint32_t
                  , unsigned_number
                  , 61 - exponent
                >::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exponent_adjusted = (
                ((exponent == 0) && (part1 == 0) && (part2 == 0))
              ? -1023
              : exponent
            )
        );

     public:
        typedef double_c<aux::mantissa<part1,part2>,exponent_adjusted,sign>
                type;
    };
  }  // namespace double_

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename IntType, boost::intmax_t Value>
#else
    template <typename IntType, IntType Value>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct integral_c_to_double
      : double_::convert_integral_c<IntType,Value>::type
    {
    };

    template <long Value>
    struct long_to_double
      : double_::convert_integral_c<long,Value>::type
    {
    };

    template <typename IntegralConstant>
    struct integral_to_double
      : double_::convert_integral_c<
            typename IntegralConstant::value_type
          , IntegralConstant::value
        >::type
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_INTEGRAL_TO_DOUBLE_HPP_INCLUDED

