// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_EULER_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_EULER_HPP_INCLUDED

#include <boost/mpl/math/double_/integral_to_double.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ {

    template <int N>
    struct euler;

    template <>
    struct euler<1> 
      : long_to_double<1L>
    {
    };

    template <>
    struct euler<2> 
      : long_to_double<5L>
    {
    };

    template <>
    struct euler<3> 
      : long_to_double<61L>
    {
    };

    template <>
    struct euler<4> 
      : long_to_double<1385L>
    {
    };

    template <>
    struct euler<5> 
      : long_to_double<50521L>
    {
    };

    template <>
    struct euler<6> 
      : long_to_double<2702765L>
    {
    };
  }  // namespace double_
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_EULER_HPP_INCLUDED

