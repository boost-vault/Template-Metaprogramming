// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_BERNOULLI_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_BERNOULLI_HPP_INCLUDED

#include <boost/mpl/math/double_/integral_to_double.hpp>
#include <boost/mpl/math/double_/aux_/divides_helper.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ {

    template <int N>
    struct bernoulli;

    template <>
    struct bernoulli<1> 
      : aux::divides_helper<long_to_double<1L>,long_to_double<6L> >::type
    {
    };

    template <>
    struct bernoulli<2> 
      : aux::divides_helper<long_to_double<1L>,long_to_double<30L> >::type
    {
    };

    template <>
    struct bernoulli<3> 
      : aux::divides_helper<long_to_double<1L>,long_to_double<42L> >::type
    {
    };

    template <>
    struct bernoulli<4> 
      : aux::divides_helper<long_to_double<1L>,long_to_double<30L> >::type
    {
    };

    template <>
    struct bernoulli<5> 
      : aux::divides_helper<long_to_double<5L>,long_to_double<66L> >::type
    {
    };

    template <>
    struct bernoulli<6> 
      : aux::divides_helper<long_to_double<691L>,long_to_double<2730L> >::type
    {
    };

    template <>
    struct bernoulli<7> 
      : aux::divides_helper<long_to_double<7L>,long_to_double<6L> >::type
    {
    };

    template <>
    struct bernoulli<8> 
      : aux::divides_helper<long_to_double<3617L>,long_to_double<510L> >::type
    {
    };

    template <>
    struct bernoulli<9> 
      : aux::divides_helper<long_to_double<43867L>,long_to_double<798L> >::type
    {
    };

    template <>
    struct bernoulli<10> 
      : aux::divides_helper<long_to_double<174611L>,long_to_double<330L> >::type
    {
    };
  }  // namespace double_
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_BERNOULLI_HPP_INCLUDED

