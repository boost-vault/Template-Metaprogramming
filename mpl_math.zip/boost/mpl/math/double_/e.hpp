// Copyright (C) 2005-2011 Peder Holt
// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_E_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_E_HPP_INCLUDED

#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/string_to_double.hpp>
#include <boost/mpl/math/e_fwd.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct e_dispatch<double_tag>
      : string_c_to_double<
            2,'.',7,1,8,2,8,1,8,2,8,4,5,9,0,4,5,2,3,5,3,6,0,2,8,7,5
        >
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_E_HPP_INCLUDED

