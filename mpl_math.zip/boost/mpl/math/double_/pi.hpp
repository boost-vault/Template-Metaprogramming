// Copyright (C) 2005-2011 Peder Holt
// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_PI_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_PI_HPP_INCLUDED

#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/string_to_double.hpp>
#include <boost/mpl/math/pi_fwd.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct pi_dispatch<double_tag>
      : string_c_to_double<
            3,'.',1,4,1,5,9,2,6,5,3,5,8,9,7,9,3,2,3,8,4,6,2,6,4,3,3,8,3,2,7,9,5
        >
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_PI_HPP_INCLUDED

