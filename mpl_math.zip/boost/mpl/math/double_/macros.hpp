// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_MACROS_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_MACROS_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/workaround.hpp>
#include <boost/mpl/aux_/static_cast.hpp>
#include <boost/mpl/math/double_/aux_/mantissa.hpp>
#include <boost/mpl/math/double_/double_c.hpp>

#define BOOST_MPL_MATH_DOUBLE_EXP512 1.3407807929942597099574024998206e+154
#define BOOST_MPL_MATH_DOUBLE_EXP256 1.1579208923731619542357098500869e+77
#define BOOST_MPL_MATH_DOUBLE_EXP128 3.4028236692093846346337460743177e+38
#define BOOST_MPL_MATH_DOUBLE_EXP64 18446744073709551616.0
#define BOOST_MPL_MATH_DOUBLE_EXP32 4294967296.0
#define BOOST_MPL_MATH_DOUBLE_EXP31 2147483648.0
#define BOOST_MPL_MATH_DOUBLE_EXP30 1073741824.0
#define BOOST_MPL_MATH_DOUBLE_EXP16 65536.0
#define BOOST_MPL_MATH_DOUBLE_EXP8 256.0
#define BOOST_MPL_MATH_DOUBLE_EXP4 16.0
#define BOOST_MPL_MATH_DOUBLE_EXP2 4.0
#define BOOST_MPL_MATH_DOUBLE_EXP1 2.0
#define BOOST_MPL_MATH_DOUBLE_EXP0 1.0
#define BOOST_MPL_MATH_DOUBLE_EXP_1 0.5
#define BOOST_MPL_MATH_DOUBLE_EXP_2 0.25
#define BOOST_MPL_MATH_DOUBLE_EXP_4 0.0625
#define BOOST_MPL_MATH_DOUBLE_EXP_8 0.00390625
#define BOOST_MPL_MATH_DOUBLE_EXP_16 0.0000152587890625
#define BOOST_MPL_MATH_DOUBLE_EXP_32 0.00000000023283064365386962890625
#define BOOST_MPL_MATH_DOUBLE_EXP_64 5.4210108624275221700372640043497e-20
#define BOOST_MPL_MATH_DOUBLE_EXP_128 2.9387358770557187699218413430556e-39
#define BOOST_MPL_MATH_DOUBLE_EXP_256 8.6361685550944446253863518628004e-78
#define BOOST_MPL_MATH_DOUBLE_EXP_512 7.4583407312002067432909653154629e-155

//Normalise double (remove exponent)
#define BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
        (value) * (value < 0 ? -1.0 : 1.0)
//Positive exponents
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP512(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP512 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_512 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP256(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP512(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP512(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP256 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_256 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP128(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP256(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP256(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP128 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_128 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP64(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP128(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP128(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP64 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_64 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP32(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP64(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP64(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP32 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_32 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP16(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP32(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP32(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP16 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_16 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP8(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP16(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP16(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP8 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_8 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP4(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP8(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP8(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP4 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_4 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP2(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP4(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP4(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP2 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_2 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP1(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP2(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP2(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP1 \
              ? BOOST_MPL_MATH_DOUBLE_EXP_1 \
              : 1.0 \
            )
//Negative exponents
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP512(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_512 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP512 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP256(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP512(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP512(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_256 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP256 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP128(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP256(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP256(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_128 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP128 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP64(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP128(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP128(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_64 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP64 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP32(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP64(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP64(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_32 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP32 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP16(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP32(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP32(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_16 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP16 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP8(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP16(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP16(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_8 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP8 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP4(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP8(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP8(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_4 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP4 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP2(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP4(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP4(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_2 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP2 \
              : 1.0 \
            )
#define BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP1(value) \
            BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP2(value) \
          * ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP2(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_1 * 2.0 \
              ? BOOST_MPL_MATH_DOUBLE_EXP1 \
              : 1.0 \
            )

#define BOOST_MPL_MATH_DOUBLE_HAS_NEGATIVE_EXP(value) \
        (value < 1.0 && value > -1.0)
#define BOOST_MPL_MATH_DOUBLE_NORMALISE(value) \
        ( \
            BOOST_MPL_MATH_DOUBLE_HAS_NEGATIVE_EXP(value) \
          ? BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP1(value) \
          : BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP1(value) \
        )

//Convert exponent to int
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT512(value) \
        ( \
            BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
         >= BOOST_MPL_MATH_DOUBLE_EXP512 \
          ? 512 \
          : 0 \
        )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT256(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT512(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP512(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP256 \
              ? 256 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT128(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT256(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP256(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP128 \
              ? 128 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT64(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT128(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP128(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP64 \
              ? 64 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT32(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT64(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP64(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP32 \
              ? 32 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT16(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT32(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP32(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP16 \
              ? 16 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT8(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT16(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP16(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP8 \
              ? 8 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT4(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT8(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP8(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP4 \
              ? 4 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT2(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT4(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP4(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP2 \
              ? 2 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT1(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT2(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_POSITIVE_EXP2(value) \
             >= BOOST_MPL_MATH_DOUBLE_EXP1 \
              ? 1 \
              : 0 \
            )

#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT512(value) \
        ( \
            BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) \
          < BOOST_MPL_MATH_DOUBLE_EXP_512 * 2.0 \
          ? -512 \
          : 0 \
        )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT256(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT512(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP512(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_256 * 2.0 \
              ? -256 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT128(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT256(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP256(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_128 * 2.0 \
              ? -128 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT64(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT128(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP128(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_64 * 2.0 \
              ? -64 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT32(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT64(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP64(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_32 * 2.0 \
              ? -32 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT16(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT32(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP32(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_16 * 2.0 \
              ? -16 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT8(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT16(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP16(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_8 * 2.0 \
              ? -8 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT4(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT8(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP8(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_4 * 2.0 \
              ? -4 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT2(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT4(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP4(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_2 * 2.0 \
              ? -2 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT1(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT2(value) \
          + ( \
                BOOST_MPL_MATH_DOUBLE_REMOVE_NEGATIVE_EXP2(value) \
              < BOOST_MPL_MATH_DOUBLE_EXP_1 * 2.0 \
              ? -1 \
              : 0 \
            )
#define BOOST_MPL_MATH_DOUBLE_EXP_TO_INT(value) \
        ( \
            (BOOST_MPL_MATH_DOUBLE_REMOVE_SIGN(value) < 1.0) \
          ? BOOST_MPL_MATH_DOUBLE_NEGATIVE_EXP_TO_INT1(value) \
          : BOOST_MPL_MATH_DOUBLE_POSITIVE_EXP_TO_INT1(value) \
        )

//Convert int to exponent
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP512(value) \
        (((value) & 512) ? BOOST_MPL_MATH_DOUBLE_EXP512 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP256(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP512(value) \
          * (((value) & 256) ? BOOST_MPL_MATH_DOUBLE_EXP256 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP128(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP256(value) \
          * (((value) & 128) ? BOOST_MPL_MATH_DOUBLE_EXP128 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP64(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP128(value) \
          * (((value) & 64) ? BOOST_MPL_MATH_DOUBLE_EXP64 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP32(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP64(value) \
          * (((value) & 32) ? BOOST_MPL_MATH_DOUBLE_EXP32 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP16(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP32(value) \
          * (((value) & 16) ? BOOST_MPL_MATH_DOUBLE_EXP16 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP8(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP16(value) \
          * (((value) & 8) ? BOOST_MPL_MATH_DOUBLE_EXP8 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP4(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP8(value) \
          * (((value) & 4) ? BOOST_MPL_MATH_DOUBLE_EXP4 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP2(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP4(value) \
          * (((value) & 2) ? BOOST_MPL_MATH_DOUBLE_EXP2 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP1(value) \
            BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP2(value) \
          * (((value) & 1) ? BOOST_MPL_MATH_DOUBLE_EXP1 : 1.0)

#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP512(value) \
        (((-(value)) & 512) ? BOOST_MPL_MATH_DOUBLE_EXP_512 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP256(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP512(value) \
          * (((-(value)) & 256) ? BOOST_MPL_MATH_DOUBLE_EXP_256 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP128(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP256(value) \
          * (((-(value)) & 128) ? BOOST_MPL_MATH_DOUBLE_EXP_128 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP64(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP128(value) \
          * (((-(value)) & 64) ? BOOST_MPL_MATH_DOUBLE_EXP_64 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP32(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP64(value) \
          * (((-(value)) & 32) ? BOOST_MPL_MATH_DOUBLE_EXP_32 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP16(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP32(value) \
          * (((-(value)) & 16) ? BOOST_MPL_MATH_DOUBLE_EXP_16 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP8(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP16(value) \
          * (((-(value)) & 8) ? BOOST_MPL_MATH_DOUBLE_EXP_8 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP4(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP8(value) \
          * (((-(value)) & 4) ? BOOST_MPL_MATH_DOUBLE_EXP_4 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP2(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP4(value) \
          * (((-(value)) & 2) ? BOOST_MPL_MATH_DOUBLE_EXP_2 : 1.0)
#define BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP1(value) \
            BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP2(value) \
          * (((-(value)) & 1) ? BOOST_MPL_MATH_DOUBLE_EXP_1 : 1.0)

#define BOOST_MPL_MATH_DOUBLE_INT_TO_EXP(value) \
        ( \
            (value < 0.0) \
          ? BOOST_MPL_MATH_DOUBLE_NEGATIVE_INT_TO_EXP1(value) \
          : BOOST_MPL_MATH_DOUBLE_POSITIVE_INT_TO_EXP1(value) \
        )

//Convert normalised double to int
#define BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTA(value) \
        (value * BOOST_MPL_MATH_DOUBLE_EXP30)
#if BOOST_WORKAROUND(BOOST_MSVC, <= 1310)
#define BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTB(value) \
        ( \
            ( \
                (value) \
              * BOOST_MPL_MATH_DOUBLE_EXP30 \
              - boost::uint32_t((value) * BOOST_MPL_MATH_DOUBLE_EXP30) \
            ) \
          * BOOST_MPL_MATH_DOUBLE_EXP31 \
        )
#else
#define BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTB(value) \
        ( \
            ( \
                (value) \
              * BOOST_MPL_MATH_DOUBLE_EXP30 \
              - BOOST_MPL_AUX_STATIC_CAST( \
                    boost::uint32_t \
                  , (value) * BOOST_MPL_MATH_DOUBLE_EXP30 \
                ) \
            ) \
          * BOOST_MPL_MATH_DOUBLE_EXP31 \
        )
#endif

#if BOOST_WORKAROUND(BOOST_MSVC, <= 1310)
#define BOOST_MPL_MATH_DOUBLE_DOUBLE_TO_INTA(value) \
        BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTA( \
            BOOST_MPL_MATH_DOUBLE_NORMALISE(value) \
        )
#define BOOST_MPL_MATH_DOUBLE_DOUBLE_TO_INTB(value) \
        BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTB( \
            BOOST_MPL_MATH_DOUBLE_NORMALISE(value) \
        )
#else
#define BOOST_MPL_MATH_DOUBLE_DOUBLE_TO_INTA(value) \
        BOOST_MPL_AUX_STATIC_CAST( \
            boost::uint32_t \
          , BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTA( \
                BOOST_MPL_MATH_DOUBLE_NORMALISE(value) \
            ) \
        )
#define BOOST_MPL_MATH_DOUBLE_DOUBLE_TO_INTB(value) \
        BOOST_MPL_AUX_STATIC_CAST( \
            boost::uint32_t \
          , BOOST_MPL_MATH_DOUBLE_NORMALISED_DOUBLE_TO_INTB( \
                BOOST_MPL_MATH_DOUBLE_NORMALISE(value) \
            ) \
        )
#endif

#define BOOST_MPL_MATH_DOUBLE(value) \
        boost::mpl::math::double_c< \
            boost::mpl::math::double_::aux::mantissa< \
                BOOST_MPL_MATH_DOUBLE_DOUBLE_TO_INTA((value)) \
              , BOOST_MPL_MATH_DOUBLE_DOUBLE_TO_INTB((value)) \
            > \
          , BOOST_MPL_MATH_DOUBLE_EXP_TO_INT((value)) \
          , (value < 0) \
        >

#endif  // BOOST_MPL_MATH_DOUBLE_MACROS_HPP_INCLUDED

