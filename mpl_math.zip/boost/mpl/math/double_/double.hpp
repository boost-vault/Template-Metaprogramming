// Copyright (C) 2005-2011 Peder Holt
// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_DOUBLE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_DOUBLE_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/config/math_double.hpp>
#include <boost/mpl/integral_c_tag.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/double_c.hpp>
#include <boost/mpl/math/double_/macros.hpp>
#include <boost/mpl/math/double_/integral_to_double.hpp>
#include <boost/mpl/math/double_/string_to_double.hpp>
#include <boost/mpl/numeric_cast.hpp>

namespace boost {
  namespace mpl {

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<integral_c_tag,math::double_tag>
    {
        template <typename IntegralConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::integral_to_double<IntegralConstant>
        {
#else
        {
            typedef typename math::integral_to_double<IntegralConstant>::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
  }  // namespace mpl
}  // namespace boost

#endif  // BOOST_MPL_MATH_DOUBLE_DOUBLE_HPP_INCLUDED

