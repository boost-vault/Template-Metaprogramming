// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_ZERO_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_ZERO_HPP_INCLUDED

#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/zero.hpp>
#include <boost/mpl/math/double_/limits.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct zero_dispatch<double_tag>
      : double_::zero
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_ZERO_HPP_INCLUDED

