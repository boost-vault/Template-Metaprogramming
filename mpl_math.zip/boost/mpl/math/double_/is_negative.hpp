// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_IS_NEGATIVE_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_IS_NEGATIVE_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/math/double_/limits.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct is_negative_impl<double_tag>
    {
        template <typename DoubleConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : double_::is_negative<DoubleConstant>
        {
#else
        {
            typedef typename double_::is_negative<DoubleConstant>::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_IS_NEGATIVE_HPP_INCLUDED

