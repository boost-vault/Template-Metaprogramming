// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_NUMERIC_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_NUMERIC_HPP_INCLUDED

#include <boost/mpl/math/double_/is_zero.hpp>
#include <boost/mpl/math/double_/is_negative.hpp>
#include <boost/mpl/math/double_/numerator.hpp>
#include <boost/mpl/math/double_/denominator.hpp>
#include <boost/mpl/math/double_/integral_part.hpp>
#include <boost/mpl/math/double_/fractional_part.hpp>

#endif  // BOOST_MPL_MATH_DOUBLE_NUMERIC_HPP_INCLUDED

