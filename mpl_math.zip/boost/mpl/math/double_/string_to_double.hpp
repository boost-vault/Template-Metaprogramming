// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !BOOST_PP_IS_ITERATING

    #ifndef BOOST_MPL_MATH_DOUBLE_STRING_TO_DOUBLE_HPP_INCLUDED
    #define BOOST_MPL_MATH_DOUBLE_STRING_TO_DOUBLE_HPP_INCLUDED

    #include <boost/config.hpp>
    #include <boost/mpl/aux_/config/forwarding.hpp>
    #include <boost/mpl/aux_/config/static_constant.hpp>
    #include <boost/mpl/apply_wrap.hpp>
    #include <boost/mpl/math/double_fwd.hpp>
    #include <boost/mpl/math/double_/double_c.hpp>
    #include <boost/mpl/math/double_/integral_to_double.hpp>
    #include <boost/mpl/math/double_/aux_/shift.hpp>
    #include <boost/mpl/math/double_/aux_/integral_exp.hpp>
    #include <boost/mpl/math/double_/times.hpp>
    #include <boost/mpl/math/double_/divides.hpp>
    #include <boost/preprocessor/iteration/iterate.hpp>
    #include <boost/preprocessor/repetition/enum_params.hpp>

#define BOOST_MPL_MATH_DOUBLE_IS_DIGIT(value) \
        ((value <= 9) || ((value >= '0') && (value <= '9')))
#define BOOST_MPL_MATH_DOUBLE_IS_SIGN(value) \
        ((value == '+') || (value == '-'))
#define BOOST_MPL_MATH_DOUBLE_IS_EXPONENT(value) \
        ((value == 'e') || (value == 'E'))
#define BOOST_MPL_MATH_DOUBLE_IS_DECIMAL_MARK(value) (value == '.')
#define BOOST_MPL_MATH_DOUBLE_IS_END(value) (value == 255)
#define BOOST_MPL_MATH_DOUBLE_GET_DIGIT(value) \
        ((value <= 9) ? value : \
        ((value >= '0') && (value <= '9')) ? (value - '0') : 0)

namespace boost { namespace mpl { namespace math {
  namespace double_ { namespace aux {

    template <boost::uint16_t Exponent>
    struct pow_impl
    {
        template <typename T>
        struct apply
        {
#if defined BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
         private:
            BOOST_STATIC_CONSTANT(
                bool
              , exponent_is_odd = ((Exponent & 1) == 1)
            );
            BOOST_STATIC_CONSTANT(
                boost::uint16_t
              , exponent_div_2 = Exponent >> 1
            );
	        typedef typename if_c<
		                exponent_is_odd
                      , T
                      , integral_c_to_double<int,1>
	                >::type
                    type0;

         public:
	        typedef typename double_::aux::times_helper<
		                type0
                      , typename apply_wrap1<
                            pow_impl<exponent_div_2>
                          , typename double_::aux::times_helper<T,T>::type
		                >::type 
	                >::type
                    type;
#else
         private:
	        typedef typename if_c<
		                Exponent & 1
                      , T
                      , integral_c_to_double<int,1>
	                >::type
                    type0;

         public:
	        typedef typename double_::aux::times_helper<
		                type0
                      , typename apply_wrap1<
                            pow_impl<(Exponent >> 1)>
                          , typename double_::aux::times_helper<T,T>::type
		                >::type 
	                >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
        };            
    };

    template <>
    struct pow_impl<0>
    {
        template <typename T>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : integral_c_to_double<int,1>
        {
#else
        {
            typedef typename integral_c_to_double<int,1>::type type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename T, boost::int16_t Exponent>
    struct pow
    {
     private:
        BOOST_STATIC_CONSTANT(bool, sign = Exponent < 0);
        BOOST_STATIC_CONSTANT(
            boost::uint16_t
          , unsigned_exponent = sign ? -Exponent : Exponent
        );
        typedef typename pow_impl<
                    unsigned_exponent
                >::BOOST_NESTED_TEMPLATE apply<T>::type
                positive_pow;

     public:
        typedef typename eval_if_c<
                    sign
                  , double_::aux::divides_helper<
                        integral_c_to_double<int,1>
                      , positive_pow
                    >
                  , double_::aux::times_helper<
                        integral_c_to_double<int,1>
                      , positive_pow
                    >
                >::type
                type;
    };

    template <boost::int16_t Exponent>
    struct exponent10
      : pow<typename integral_c_to_double<int,10>::type,Exponent>::type 
    {
    };
  }  // namespace aux

    template <BOOST_PP_ENUM_PARAMS(40, unsigned char a)>
    struct string_c_impl
    {
     private:
        BOOST_STATIC_CONSTANT(bool, sign = (a0 == '-') ? true : false);
        enum
        {
            NumberSign = 0x1
          , DecimalMark = 0x2
          , ExponentSign = 0x4
          , Exponent = 0x8
          , ExponentNumber = 0x10
          , IntegralNumber = 0x20
          , FractionNumber = 0x40
          , Overflow = 0x80
          , CompleteNumber = 0x100
          , NaN = 0x200
        };
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , status_0 = (
                BOOST_MPL_MATH_DOUBLE_IS_SIGN(a0)
              ? NumberSign
              : BOOST_MPL_MATH_DOUBLE_IS_DECIMAL_MARK(a0)
              ? DecimalMark
              : BOOST_MPL_MATH_DOUBLE_IS_DIGIT(a0)
              ? IntegralNumber
              : NaN
            )
        );
        BOOST_STATIC_CONSTANT(boost::uint32_t, result_a_0 = 0);
        BOOST_STATIC_CONSTANT(
            boost::uint32_t
          , result_b_0 = (
                ((status_0 == NumberSign) || (status_0 == DecimalMark))
              ? 0
              : (status_0 == IntegralNumber)
              ? BOOST_MPL_MATH_DOUBLE_GET_DIGIT(a0)
              : 0 //NaN value
            )
        );
        BOOST_STATIC_CONSTANT(boost::int16_t, exp10_overflow_0 = 0);
        BOOST_STATIC_CONSTANT(boost::int16_t, exp10_0 = 0);

        #define BOOST_PP_ITERATION_PARAMS_1 ( \
                    3 \
                  , (1, 39, <boost/mpl/math/double_/string_to_double.hpp>) \
                )
        #include BOOST_PP_ITERATE()

        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp1 = (
                double_::aux::integral_exp<boost::int32_t,result_a_39>::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp2 = (
                double_::aux::integral_exp<
                    boost::int32_t
                  , result_b_39 & 0x7fffffff
                >::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::int16_t
          , exp_shift = (
                ((exp1 == 0) && (exp2 == 0))
              ? -1023
              : (exp1 > 0)
              ? (exp1 - 30)
              : (exp2 - 61)
            )
        );
        typedef double_::aux::shift_mantissa<
                    double_::aux::mantissa<result_a_39,result_b_39&0x7fffffff>
                  , -exp_shift
                >
                normalized_mantissa;
        typedef double_c<normalized_mantissa,61+exp_shift,sign>
                result_no_exponent;

     public:
        typedef typename double_::aux::round<
                    double_::aux::times_helper<
                        result_no_exponent
                      , double_::aux::exponent10<exp10_overflow_39+exp10_39>
                    >
                >::type
                type;
    };
  }  // namespace double_

    template <BOOST_PP_ENUM_PARAMS(40, unsigned char a)>
    struct string_c_to_double
      : double_::string_c_impl<BOOST_PP_ENUM_PARAMS(40,a)>::type
    {
    };
}}}  // namespace boost::mpl::math
#undef BOOST_MPL_MATH_DOUBLE_IS_DIGIT
#undef BOOST_MPL_MATH_DOUBLE_IS_SIGN
#undef BOOST_MPL_MATH_DOUBLE_IS_EXPONENT
#undef BOOST_MPL_MATH_DOUBLE_IS_DECIMAL_MARK
#undef BOOST_MPL_MATH_DOUBLE_IS_END
#undef BOOST_MPL_MATH_DOUBLE_GET_DIGIT

    #endif  // BOOST_MPL_MATH_DOUBLE_STRING_TO_DOUBLE_HPP_INCLUDED
#else

#define N BOOST_PP_ITERATION()
#define N_1 BOOST_PP_DEC(N)

    BOOST_STATIC_CONSTANT(
        boost::int16_t
      , BOOST_PP_CAT(status_, N) = (
            (
                BOOST_MPL_MATH_DOUBLE_IS_DECIMAL_MARK(BOOST_PP_CAT(a, N))
             && (
                    (BOOST_PP_CAT(status_, N_1) & NumberSign)
                 || (BOOST_PP_CAT(status_, N_1) & IntegralNumber)
                )
            )
          ? DecimalMark
          : BOOST_MPL_MATH_DOUBLE_IS_DIGIT(BOOST_PP_CAT(a, N))
          ? (
                (
                    (BOOST_PP_CAT(status_, N_1) & FractionNumber)
                 || (BOOST_PP_CAT(status_, N_1) & IntegralNumber)
                )
              ? (
                    BOOST_PP_CAT(status_, N_1)
                  | ((BOOST_PP_CAT(result_a_, N_1) >= 100000000) ? Overflow : 0)
                )
              : (BOOST_PP_CAT(status_, N_1) & ExponentNumber)
              ? BOOST_PP_CAT(status_, N_1)
              : (BOOST_PP_CAT(status_, N_1) & NumberSign)
              ? IntegralNumber
              : (
                    (BOOST_PP_CAT(status_, N_1) & ExponentSign)
                 || (BOOST_PP_CAT(status_, N_1) & Exponent)
                )
              ? ExponentNumber
              : (BOOST_PP_CAT(status_, N_1) & DecimalMark)
              ? (
                    (
                        (BOOST_PP_CAT(result_a_, N_1) == 0)
                     && (BOOST_PP_CAT(result_b_, N_1) == 0)
                    )
                  ? FractionNumber
                  : (FractionNumber | IntegralNumber)
                )
              : NaN
            )
          : (BOOST_MPL_MATH_DOUBLE_IS_EXPONENT(BOOST_PP_CAT(a, N)))
          ? Exponent
          : (
                BOOST_MPL_MATH_DOUBLE_IS_SIGN(BOOST_PP_CAT(a, N))
             && (BOOST_PP_CAT(status_, N_1) == Exponent)
            )
          ? ExponentSign
          : BOOST_MPL_MATH_DOUBLE_IS_END(BOOST_PP_CAT(a, N))
          ? CompleteNumber
          : NaN
        )
    );
    BOOST_STATIC_CONSTANT(
        boost::uint32_t
      , BOOST_PP_CAT(result_b_, N) = (
            (
                (
                    (BOOST_PP_CAT(status_, N) & IntegralNumber)
                 || (BOOST_PP_CAT(status_, N) & FractionNumber)
                )
             && !(BOOST_PP_CAT(status_, N) & Overflow)
            )
          ? (
                ((BOOST_PP_CAT(result_b_, N_1) << 3) & 0x7fffffff)
              + ((BOOST_PP_CAT(result_b_, N_1) << 1) & 0x7fffffff)
              + BOOST_MPL_MATH_DOUBLE_GET_DIGIT(BOOST_PP_CAT(a, N))
            )
          : (BOOST_PP_CAT(status_, N) & NaN)
          ? 0
          : BOOST_PP_CAT(result_b_, N_1)
        )
    );
    BOOST_STATIC_CONSTANT(
        boost::uint32_t
      , BOOST_PP_CAT(result_a_, N) = (
            (
                (
                    (BOOST_PP_CAT(status_, N) & IntegralNumber)
                 || (BOOST_PP_CAT(status_, N) & FractionNumber)
                )
             && !(BOOST_PP_CAT(status_, N) & Overflow)
            )
          ? (
                (BOOST_PP_CAT(result_a_, N_1) << 3)
              + (BOOST_PP_CAT(result_a_, N_1) << 1)
              + ((BOOST_PP_CAT(result_b_, N_1) & 0x7fffffff) >> 28)
              + ((BOOST_PP_CAT(result_b_, N_1) & 0x7fffffff) >> 30)
              + (BOOST_PP_CAT(result_b_, N) >> 31)
            )
          : (BOOST_PP_CAT(status_,N) & NaN)
          ? 0
          : BOOST_PP_CAT(result_a_, N_1)
        )
    );
    BOOST_STATIC_CONSTANT(
        boost::int16_t
      , BOOST_PP_CAT(exp10_overflow_, N) = (
           (BOOST_PP_CAT(status_, N) == (IntegralNumber | Overflow))
         ? (BOOST_PP_CAT(exp10_overflow_, N_1) + 1)
         : (
               (BOOST_PP_CAT(status_, N) & FractionNumber)
            && !(BOOST_PP_CAT(status_, N) & Overflow)
           )
         ? (BOOST_PP_CAT(exp10_overflow_, N_1) - 1)
         : BOOST_PP_CAT(exp10_overflow_, N_1)
        )
    );
    BOOST_STATIC_CONSTANT(
        boost::int16_t
      , BOOST_PP_CAT(exp10_, N) = (
            (BOOST_PP_CAT(status_, N) == ExponentSign)
          ? ((BOOST_PP_CAT(a, N) == '-') ? -1 : 1)
          : (BOOST_PP_CAT(status_, N) == ExponentNumber)
          ? (
                (BOOST_PP_CAT(status_, N_1) == ExponentSign)
              ? (
                    BOOST_PP_CAT(exp10_, N_1)
                  * BOOST_MPL_MATH_DOUBLE_GET_DIGIT(BOOST_PP_CAT(a, N))
                )
              : (BOOST_PP_CAT(exp10_, N_1) < 0)
              ? -(
                    ((-BOOST_PP_CAT(exp10_, N_1)) << 3)
                  + ((-BOOST_PP_CAT(exp10_, N_1)) << 1)
                  + BOOST_MPL_MATH_DOUBLE_GET_DIGIT(BOOST_PP_CAT(a, N))
                )
              : (
                    (BOOST_PP_CAT(exp10_, N_1) << 3)
                  + (BOOST_PP_CAT(exp10_, N_1) << 1)
                  + BOOST_MPL_MATH_DOUBLE_GET_DIGIT(BOOST_PP_CAT(a, N))
                )
            )
          : BOOST_PP_CAT(exp10_, N_1)
        )
    );

#undef N
#undef N_1

#endif  // BOOST_PP_IS_ITERATING

