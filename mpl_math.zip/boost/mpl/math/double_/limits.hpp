// Copyright (C) 2005-2011 Peder Holt
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_LIMITS_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_LIMITS_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/math/double_/double_c.hpp>

namespace boost { namespace mpl { namespace math {
  namespace double_ {

    typedef double_c<aux::mantissa<0x20000000,0>,0x0400,true>
            NaN;
    typedef double_c<aux::mantissa<0,0>,0x0400,false>
            infinity;
    typedef double_c<aux::mantissa<0,0>,0x0400,true>
            negative_infinity;
    typedef double_c<aux::mantissa<0x7fffffff,0x7ffffe00>,0x03ff,false>
            float_max;
    typedef double_c<aux::mantissa<0x40000000,0>,-0x03fe,false>
            float_min;
    typedef double_c<aux::mantissa<0,0>,-0x03ff,false>
            zero;

    template <typename N>
    struct is_NaN
    {
        BOOST_STATIC_CONSTANT(
            bool
          , value =
                (N::exponent == 0x400)
             && (
                    (N::mantissa::part1 != 0)
                 || (N::mantissa::part2 != 0)
                )
        );
        typedef bool_<value> type;
    };

    template <typename N>
    struct is_finite
    {
        BOOST_STATIC_CONSTANT(bool, value = (N::exponent < 0x400));
        typedef bool_<value> type;
    };

    template <typename N>
    struct is_positive_infinity
    {
        BOOST_STATIC_CONSTANT(
            bool
          , value =
                (N::exponent == 0x400)
             && (N::mantissa::part1 == 0)
             && (N::mantissa::part2 == 0)
             && !N::sign
        );
        typedef bool_<value> type;
    };

    template <typename N>
    struct is_negative_infinity
    {
        BOOST_STATIC_CONSTANT(
            bool
          , value =
                (N::exponent == 0x400)
             && (N::mantissa::part1 == 0)
             && (N::mantissa::part2 == 0)
             && N::sign
        );
        typedef bool_<value> type;
    };

    template <typename N>
    struct is_zero
    {
        BOOST_STATIC_CONSTANT(
            bool
          , value =
                (N::exponent == -0x3ff)
             && (N::mantissa::part1 == 0)
             && (N::mantissa::part2 == 0)
        );
        typedef bool_<value> type;
    };

    template <typename N>
    struct is_negative
    {
        BOOST_STATIC_CONSTANT(bool, value = (N::sign == true));
        typedef bool_<value> type;
    };
  }  // namespace double_
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_LIMITS_HPP_INCLUDED

