// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_DOUBLE_GOLDEN_RATIO_HPP_INCLUDED
#define BOOST_MPL_MATH_DOUBLE_GOLDEN_RATIO_HPP_INCLUDED

#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/double_/string_to_double.hpp>
#include <boost/mpl/math/golden_ratio_fwd.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct golden_ratio_dispatch<double_tag>
      : string_c_to_double<
            1,'.',6,1,8,0,3,3,9,8,8,7,4,9,8,9,4,8,4,8,2,0,4,5,8,6,8,3,4,3,6,5,6
        >
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_DOUBLE_GOLDEN_RATIO_HPP_INCLUDED

