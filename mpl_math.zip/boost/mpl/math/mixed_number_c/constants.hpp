// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_CONSTANTS_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_CONSTANTS_HPP_INCLUDED

#include <boost/mpl/math/mixed_number_c/zero.hpp>
#include <boost/mpl/math/mixed_number_c/one.hpp>
#include <boost/mpl/math/mixed_number_c/two.hpp>
#include <boost/mpl/math/mixed_number_c/three.hpp>
#include <boost/mpl/math/mixed_number_c/four.hpp>
#include <boost/mpl/math/mixed_number_c/golden_ratio.hpp>
#include <boost/mpl/math/mixed_number_c/silver_ratio.hpp>
#include <boost/mpl/math/mixed_number_c/e.hpp>
#include <boost/mpl/math/mixed_number_c/pi.hpp>

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_CONSTANTS_HPP_INCLUDED

