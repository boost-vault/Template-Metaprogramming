// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_SILVER_RATIO_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_SILVER_RATIO_HPP_INCLUDED

#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/silver_ratio_fwd.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/rational_c/silver_ratio.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/convert_rational.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct silver_ratio_dispatch<mixed_number_c_tag>
      : rational_to_mixed_number_c<silver_ratio_dispatch<rational_c_tag> >
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_SILVER_RATIO_HPP_INCLUDED

