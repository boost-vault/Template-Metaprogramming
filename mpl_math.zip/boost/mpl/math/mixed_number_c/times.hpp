// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_TIMES_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_TIMES_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/times_helper.hpp>

namespace boost { namespace mpl {

    template <>
    struct times_impl<math::mixed_number_c_tag,math::mixed_number_c_tag>
    {
        template <
            typename MixedNumericConstant1
          , typename MixedNumericConstant2
        >
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::mixed_number_c_::aux::times_helper<
                MixedNumericConstant1
              , MixedNumericConstant2
            >
        {
#else
        {
            typedef typename math::mixed_number_c_::aux::times_helper<
                        MixedNumericConstant1
                      , MixedNumericConstant2
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  /* BOOST_MPL_MATH_MIXED_NUMBER_TIMES_HPP_INCLUDED */

