// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_MINUS_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_MINUS_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/plus_helper.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/minus_helper.hpp>

namespace boost { namespace mpl {

    template <>
    struct minus_impl<math::mixed_number_c_tag,math::mixed_number_c_tag>
    {
        template <
            typename MixedNumericConstant1
          , typename MixedNumericConstant2
        >
        struct apply
        {
         private:
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , whole_1 = MixedNumericConstant1::whole
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , frac_num_1 = MixedNumericConstant1::frac_num
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_neg_whole_1 = whole_1 < 0
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_neg_frac_num_1 = (whole_1 == 0) && (frac_num_1 < 0)
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , abs_whole_1 = is_neg_whole_1 ? -whole_1 : whole_1
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , abs_frac_num_1 = is_neg_frac_num_1 ? -frac_num_1 : frac_num_1
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , frac_den_1 = MixedNumericConstant1::frac_den
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , whole_2 = MixedNumericConstant2::whole
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , frac_num_2 = MixedNumericConstant2::frac_num
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_neg_whole_2 = whole_2 < 0
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_neg_frac_num_2 = (whole_2 == 0) && (frac_num_2 < 0)
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , abs_whole_2 = is_neg_whole_2 ? -whole_2 : whole_2
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , abs_frac_num_2 = is_neg_frac_num_2 ? -frac_num_2 : frac_num_2
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , frac_den_2 = MixedNumericConstant2::frac_den
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_negative_1 = is_neg_whole_1 || is_neg_frac_num_1
            );
            BOOST_STATIC_CONSTANT(
                bool
              , is_positive_2 = !(is_neg_whole_2 || is_neg_frac_num_2)
            );
            BOOST_STATIC_CONSTANT(
                bool
              , should_add = is_negative_1 == is_positive_2
            );

         public:
            typedef typename eval_if_c<
                        should_add
                      , math::mixed_number_c_::aux::plus_helper<
                            is_negative_1
                          , abs_whole_1
                          , abs_frac_num_1
                          , frac_den_1
                          , abs_whole_2
                          , abs_frac_num_2
                          , frac_den_2
                        >
                      , math::mixed_number_c_::aux::minus_helper<
                            is_negative_1
                          , abs_whole_1
                          , abs_frac_num_1
                          , frac_den_1
                          , is_positive_2
                          , abs_whole_2
                          , abs_frac_num_2
                          , frac_den_2
                        >
                    >::type
                    type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_MINUS_HPP_INCLUDED

