// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_IMPL_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_IMPL_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/aux_/numeric_constant_2_stream.hpp>
#include <boost/mpl/error/mixed_number.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/rational_c/macros.hpp>
// TODO: Find or make a more suitable value_type.
#include <boost/rational.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * Do not use directly!
     */
    template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
    struct mixed_number_c_impl
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(mixed_number_c_impl)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef mixed_number_c_tag tag;

        /*
         * The relevant parts of a Mixed Numeric Constant.
         */
        typedef boost::rational<boost::intmax_t> value_type;
        typedef boost::intmax_t int_type;

#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
        enum
        {
            whole = W
          , frac_num = N
          , frac_den = D
        };
#else
        static const boost::intmax_t whole = W;
        static const boost::intmax_t frac_num = N;
        static const boost::intmax_t frac_den = D;
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

        operator value_type() const
        {
            return value_type(whole * frac_den + frac_num, frac_den);
        }

        /*
         * Sends a text representation of this Mixed Numeric Constant to the
         * specified output stream.
         */
        template <typename OutputStream>
        static void extract(OutputStream& out)
        {
            out << whole;

            if (frac_num)
            {
                out << '&' << frac_num << ':' << frac_den;
            }
        }
    };

  namespace mixed_number_c_ {

    template <
        bool HasProperNumerator
      , bool HasProperFractionalPart
      , bool hasPositiveDenominator
    >
    struct check_mixed_number_c
    {
        template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
        struct apply
        {
            BOOST_MPL_AUX_SELF_TYPEDEF(apply)

            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , num = BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(
                    boost::intmax_t
                  , N
                  , D
                )
            );
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , den = BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(
                    boost::intmax_t
                  , N
                  , D
                )
            );
        };
    };

    template <>
    struct check_mixed_number_c<false,true,true>
    {
        template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
        struct apply
          : boost::mpl::error::nonzero_integral_part_negative_fractional_part
        {
        };
    };

    template <>
    struct check_mixed_number_c<false,false,true>
      : check_mixed_number_c<false,true,true>
    {
    };

    template <>
    struct check_mixed_number_c<false,true,false>
      : check_mixed_number_c<false,true,true>
    {
    };

    template <>
    struct check_mixed_number_c<false,false,false>
      : check_mixed_number_c<false,true,true>
    {
    };

    template <>
    struct check_mixed_number_c<true,false,true>
    {
        template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
        struct apply : boost::mpl::error::improper_fractional_part
        {
        };
    };

    template <>
    struct check_mixed_number_c<true,false,false>
      : check_mixed_number_c<true,false,true>
    {
    };

    template <>
    struct check_mixed_number_c<true,true,false>
    {
        template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
        struct apply : boost::mpl::error::negative_denominator
        {
        };
    };

    /*
     * Error-check Mixed Numeric Constants here.
     */
    template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
    struct impl
    {
     private:
        BOOST_STATIC_CONSTANT(
            bool
          , has_proper_numerator = ((0 == W) || (0 <= N))
        );
        BOOST_STATIC_CONSTANT(
            bool
          , has_proper_fractional_part = ((N < 0) ? (-N < D) : (N < D))
        );
        BOOST_STATIC_CONSTANT(
            bool
          , has_positive_denominator = 0 < D
        );
        typedef typename check_mixed_number_c<
                    has_proper_numerator
                  , has_proper_fractional_part
                  , has_positive_denominator
                >::BOOST_NESTED_TEMPLATE apply<W,N,D>::type
                fractional_part;

     public:
        typedef mixed_number_c_impl<
                    W
                  , fractional_part::num
                  , fractional_part::den
                >
                type;
    };
  }  // namespace mixed_number_c_
}}}  // namespace boost::mpl::math

/*
 * Operator overload for outputting mixed_number_c_impl instances using an
 * output stream.  NOT FOR BITSHIFTING!
 */
template <
    typename OutputStream
  , boost::intmax_t W
  , boost::intmax_t N
  , boost::intmax_t D
>
inline OutputStream& operator<<(
    OutputStream& out
  , boost::mpl::math::mixed_number_c_impl<W,N,D> const& n
)
{
    boost::mpl::math::mixed_number_c_impl<W,N,D>::extract(out);

    return out;
}

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_IMPL_HPP_INCLUDED

