// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_ZERO_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_ZERO_HPP_INCLUDED

#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/zero.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct zero_dispatch<mixed_number_c_tag> : mixed_number_c_impl<0,0,1>
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_ZERO_HPP_INCLUDED

