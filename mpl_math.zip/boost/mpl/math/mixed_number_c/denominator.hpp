// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_DENOMINATOR_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_DENOMINATOR_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/denominator.hpp>
#include <boost/mpl/integral_c.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct denominator_impl<mixed_number_c_tag>
    {
        template <typename MixedNumericConstant>
        struct apply
        {
            typedef integral_c<
                        boost::intmax_t
                      , MixedNumericConstant::frac_den
                    >
                    type;
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_DENOMINATOR_HPP_INCLUDED

