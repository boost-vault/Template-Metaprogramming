// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_COMPARISON_HPP
#define BOOST_MPL_MATH_MIXED_NUMBER_COMPARISON_HPP

#include <boost/mpl/math/mixed_number_c/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/mpl/math/mixed_number_c/less.hpp>
#include <boost/mpl/greater.hpp>
#include <boost/mpl/less_equal.hpp>
#include <boost/mpl/greater_equal.hpp>
#include <boost/mpl/aux_/comparison_op_impl_defaults.hpp>

BOOST_MPL_AUX_COMPARISON_OP_IMPL_DEFAULTS(math::mixed_number_c)

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_COMPARISON_HPP

