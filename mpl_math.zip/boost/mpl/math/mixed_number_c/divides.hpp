// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_DIVIDES_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_DIVIDES_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/times_helper.hpp>
#include <boost/mpl/math/mixed_number_c/reciprocal.hpp>

namespace boost { namespace mpl {

    template <>
    struct divides_impl<math::mixed_number_c_tag,math::mixed_number_c_tag>
    {
        template <
            typename MixedNumericConstant1
          , typename MixedNumericConstant2
        >
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : math::mixed_number_c_::aux::times_helper<
                MixedNumericConstant1
              , typename math::mixed_number_c_::reciprocal<
                    MixedNumericConstant2
                >::type
            >
        {
#else
        {
            typedef typename math::mixed_number_c_::aux::times_helper<
                        MixedNumericConstant1
                      , typename math::mixed_number_c_::reciprocal<
                            MixedNumericConstant2
                        >::type
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_DIVIDES_HPP_INCLUDED

