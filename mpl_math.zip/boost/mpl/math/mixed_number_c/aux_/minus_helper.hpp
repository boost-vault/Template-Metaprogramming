// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_AUX_MINUS_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_AUX_MINUS_HELPER_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>
#include <boost/mpl/math/integral_lcm.hpp>
#include <boost/mpl/math/rational_c/macros.hpp>

namespace boost { namespace mpl { namespace math {
  namespace mixed_number_c_ { namespace aux {

    template <
        bool IsNegative1
      , boost::intmax_t AbsWhole1
      , boost::intmax_t AbsFracNum1
      , boost::intmax_t FracDen1
      , bool IsNegative2
      , boost::intmax_t AbsWhole2
      , boost::intmax_t AbsFracNum2
      , boost::intmax_t FracDen2
    >
    struct minus_helper
    {
     private:
        /*
         * Step 1: Find out which mixed number is larger.
         */
        BOOST_STATIC_CONSTANT(
            bool
          , less_r1_r2 = (
                (FracDen1 == FracDen2)
              ? (AbsFracNum1 < AbsFracNum2)
              : (AbsFracNum1 * FracDen2 < AbsFracNum2 * FracDen1)
            )
        );
        BOOST_STATIC_CONSTANT(
            bool
          , less_m1_m2 = (
                (AbsWhole1 < AbsWhole2)
             || (AbsWhole1 == AbsWhole2)
             && less_r1_r2
            )
        );
        BOOST_STATIC_CONSTANT(
            bool
          , less_r2_r1 = (
                (FracDen2 == FracDen1)
              ? (AbsFracNum2 < AbsFracNum1)
              : (AbsFracNum2 * FracDen1 < AbsFracNum1 * FracDen2)
            )
        );
        BOOST_STATIC_CONSTANT(
            bool
          , less_m2_m1 = (
                (AbsWhole2 < AbsWhole1)
             || (AbsWhole2 == AbsWhole1)
             && less_r2_r1
            )
        );

        /*
         * Step 2: Check if the larger mixed number is negative.
         */
        BOOST_STATIC_CONSTANT(
            bool
          , is_negative = (
                IsNegative2
             && less_m1_m2
             || IsNegative1
             && less_m2_m1
            )
        );

        /*
         * Step 3: Check if the larger mixed number's fractional part
         * is smaller than the smaller mixed number's fractional part.
         * If so, we need to borrow.
         */
        BOOST_STATIC_CONSTANT(
            bool
          , must_borrow = (
                less_m1_m2
             && less_r2_r1
             || less_m2_m1
             && less_r1_r2
            )
        );

        /*
         * Step 4: Subtract the smaller mixed number's integral part
         * from the larger mixed number's integral part.
         * If we need to borrow, also subtract 1.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_whole_sum = (
                must_borrow
              ? (
                    less_m1_m2
                  ? (AbsWhole2 - AbsWhole1 - 1)
                  : (AbsWhole1 - AbsWhole2 - 1)
                )
              : (
                    less_m1_m2
                  ? (AbsWhole2 - AbsWhole1)
                  : (AbsWhole1 - AbsWhole2)
                )
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , whole_sum = is_negative ? -abs_whole_sum : abs_whole_sum
        );

        /*
         * Step 5: Subtract the smaller fractional part from the larger one.
         * If we need to borrow, subtract the new fractional part from 1.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d1 = (integral_lcm<boost::intmax_t,FracDen1,FracDen2>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n1 = (
                must_borrow
              ? (
                    less_r1_r2
                  ? (
                        d1
                      - d1 / FracDen2 * AbsFracNum2
                      + d1 / FracDen1 * AbsFracNum1
                    )
                  : (
                        d1
                      - d1 / FracDen1 * AbsFracNum1
                      + d1 / FracDen2 * AbsFracNum2
                    )
                )
              : (
                    less_r1_r2
                  ? (
                        d1 / FracDen2 * AbsFracNum2
                      - d1 / FracDen1 * AbsFracNum1
                    )
                  : (
                        d1 / FracDen1 * AbsFracNum1
                      - d1 / FracDen2 * AbsFracNum2
                    )
                )
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n2 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(
                boost::intmax_t
              , n1
              , d1
            ) * ((is_negative && (0 == abs_whole_sum)) ? -1 : 1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d2 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(
                boost::intmax_t
              , n1
              , d1
            )
        );

     public:
        typedef mixed_number_c_impl<whole_sum,n2,d2> type;
    };
  }}  // namespace mixed_number_c_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_AUX_MINUS_HELPER_HPP_INCLUDED

