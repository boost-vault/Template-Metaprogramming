// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_CONVERT_RATIONAL_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_CONVERT_RATIONAL_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/math/mixed_number_c_fwd.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/convert_rational_c.hpp>
#include <boost/mpl/math/rational_c/aux_/simplify.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename RationalConstant>
    struct rational_to_mixed_number_c
      : mixed_number_c_::aux::convert_rational_c<
            RationalConstant::num
          , RationalConstant::den
        >::type
    {
    };

    template <boost::intmax_t N, boost::intmax_t D>
    struct rational_c_to_mixed_number_c
      : rational_to_mixed_number_c<
            typename aux::simplify_rational_c<boost::intmax_t,N,D>::type
        >
    {
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_CONVERT_RATIONAL_HPP_INCLUDED

