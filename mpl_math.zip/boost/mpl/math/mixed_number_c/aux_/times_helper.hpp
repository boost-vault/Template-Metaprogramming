// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_TIMES_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_TIMES_HELPER_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>
#include <boost/mpl/math/integral_gcd.hpp>
#include <boost/mpl/math/integral_lcm.hpp>
#include <boost/mpl/math/rational_c/macros.hpp>

namespace boost { namespace mpl { namespace math {
  namespace mixed_number_c_ { namespace aux {

    template <typename MixedNumericConstant1, typename MixedNumericConstant2>
    struct times_helper
    {
     private:
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , whole_1 = MixedNumericConstant1::whole
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_num_1 = MixedNumericConstant1::frac_num
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_neg_whole_1 = whole_1 < 0
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_neg_frac_num_1 = (whole_1 == 0) && (frac_num_1 < 0)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_whole_1 = is_neg_whole_1 ? -whole_1 : whole_1
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_frac_num_1 = is_neg_frac_num_1 ? -frac_num_1 : frac_num_1
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_den_1 = MixedNumericConstant1::frac_den
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , whole_2 = MixedNumericConstant2::whole
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_num_2 = MixedNumericConstant2::frac_num
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_neg_whole_2 = whole_2 < 0
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_neg_frac_num_2 = (whole_2 == 0) && (frac_num_2 < 0)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_whole_2 = is_neg_whole_2 ? -whole_2 : whole_2
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_frac_num_2 = is_neg_frac_num_2 ? -frac_num_2 : frac_num_2
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_den_2 = MixedNumericConstant2::frac_den
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_negative_1 = is_neg_whole_1 || is_neg_frac_num_1
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_negative_2 = is_neg_whole_2 || is_neg_frac_num_2
        );

        /*
         * Step 1: Add the product of the whole parts to the product of the
         * fractional parts, forming a temporary mixed number.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_whole_3 = abs_whole_1 * abs_whole_2
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , gcd_3_1 = (
                integral_gcd<boost::intmax_t,abs_frac_num_1,frac_den_2>::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , gcd_3_2 = (
                integral_gcd<boost::intmax_t,abs_frac_num_2,frac_den_1>::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_frac_num_3 = (
                (abs_frac_num_1 / gcd_3_1) * (abs_frac_num_2 / gcd_3_2)
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_den_3 = (frac_den_1 / gcd_3_2) * (frac_den_2 / gcd_3_1)
        );

        /*
         * Step 2: Multiply the first whole part by the second fractional
         * part.  Convert the product to a temporary mixed number.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_whole_4 = abs_whole_1 * abs_frac_num_2 / frac_den_2
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_den_4 = frac_den_2 / (
                integral_gcd<boost::intmax_t,abs_whole_1,frac_den_2>::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_frac_num_4 = (
                abs_whole_1 * abs_frac_num_2 % frac_den_2
            ) * frac_den_4 / frac_den_2
        );

        /*
         * Step 3: Multiply the second whole part by the first fractional
         * part.  Convert the product to a temporary mixed number.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_whole_5 = abs_whole_2 * abs_frac_num_1 / frac_den_1
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , frac_den_5 = frac_den_1 / (
                integral_gcd<boost::intmax_t,abs_whole_2,frac_den_1>::value
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_frac_num_5 = (
                abs_whole_2 * abs_frac_num_1 % frac_den_1
            ) * frac_den_5 / frac_den_1
        );

        /*
         * Step 4: Add the temporary mixed numbers together.
         * Apply the proper sign to the sum.  Return the result.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d1 = (integral_lcm<boost::intmax_t,frac_den_3,frac_den_4>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n1 = (
                d1 / frac_den_3 * abs_frac_num_3
              + d1 / frac_den_4 * abs_frac_num_4
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , w2 = (
                (n1 < d1)
              ? (abs_whole_3 + abs_whole_4)
              : (abs_whole_3 + abs_whole_4 + 1)
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , diff1 = (n1 < d1) ? n1 : (n1 - d1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n2 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(
                boost::intmax_t
              , diff1
              , d1
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d2 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(
                boost::intmax_t
              , diff1
              , d1
            )
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d3 = (integral_lcm<boost::intmax_t,d2,frac_den_5>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n3 = d3 / d2 * n2 + d3 / frac_den_5 * abs_frac_num_5
        );
        BOOST_STATIC_CONSTANT(
            bool
          , is_positive = is_negative_1 == is_negative_2
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , w4 = (
                (n3 < d3) ? (w2 + abs_whole_5) : (w2 + abs_whole_5 + 1)
            ) * (is_positive ? 1 : -1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , diff3 = (n3 < d3) ? n3 : (n3 - d3)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n4 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(
                boost::intmax_t
              , diff3
              , d3
            ) * ((is_positive || w4) ? 1 : -1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d4 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(
                boost::intmax_t
              , diff3
              , d3
            )
        );

     public:
        typedef mixed_number_c_impl<w4,n4,d4> type;
    };
  }}  // namespace mixed_number_c_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_TIMES_HELPER_HPP_INCLUDED

