// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_CONVERT_RATIONAL_C_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_CONVERT_RATIONAL_C_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>

namespace boost { namespace mpl { namespace math {
  namespace mixed_number_c_ { namespace aux {

    template <boost::intmax_t N, boost::intmax_t D>
    struct convert_rational_c
    {
     private:
#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
        enum
        {
            whole = N / D
          , frac_num = (whole ? ((N < 0) ? -N : N) % D : N)
        };
#else
        static const boost::intmax_t whole = N / D;
        static const boost::intmax_t frac_num = (
            whole ? ((N < 0) ? -N : N) % D : N
        );
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

     public:
        typedef mixed_number_c_impl<whole,frac_num,D> type;
    };
  }}  // namespace mixed_number_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_CONVERT_RATIONAL_C_HPP_INCLUDED

