// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_PLUS_HELPER_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_PLUS_HELPER_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>
#include <boost/mpl/math/integral_lcm.hpp>
#include <boost/mpl/math/rational_c/macros.hpp>

namespace boost { namespace mpl { namespace math {
  namespace mixed_number_c_ { namespace aux {

    template <
        bool IsNegative
      , boost::intmax_t AbsWhole1
      , boost::intmax_t AbsFracNum1
      , boost::intmax_t FracDen1
      , boost::intmax_t AbsWhole2
      , boost::intmax_t AbsFracNum2
      , boost::intmax_t FracDen2
    >
    struct plus_helper
    {
     private:
        /*
         * Step 1: Take the sum of the fractional parts.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d1 = (integral_lcm<boost::intmax_t,FracDen1,FracDen2>::value)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n1 = d1 / FracDen1 * AbsFracNum1 + d1 / FracDen2 * AbsFracNum2
        );

        /*
         * Step 2: Add the whole parts together.
         * If the fractional sum is not proper,
         * carry 1 over to the whole-part sum.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , whole_sum = (
                (n1 < d1)
              ? (AbsWhole1 + AbsWhole2)
              : (AbsWhole1 + AbsWhole2 + 1)
            ) * (IsNegative ? -1 : 1)
        );

        /*
         * Step 3: Reduce the fractional sum.
         * If it is not proper, subtract 1 to make it proper.
         */
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , diff = (n1 < d1) ? n1 : (n1 - d1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , n2 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_NUMERATOR(
                boost::intmax_t
              , diff
              , d1
            ) * ((IsNegative && (0 == whole_sum)) ? -1 : 1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , d2 = BOOST_MPL_MATH_RATIONAL_C_SIGNED_DENOMINATOR(
                boost::intmax_t
              , diff
              , d1
            )
        );

     public:
        typedef mixed_number_c_impl<whole_sum,n2,d2> type;
    };
  }}  // namespace mixed_number_c_::aux
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_AUX_PLUS_HELPER_HPP_INCLUDED

