// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_MIXED_NUMBER_C_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_MIXED_NUMBER_C_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/mixed_number_c_fwd.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>
#include <boost/mpl/math/mixed_number_c/numeric.hpp>
#include <boost/mpl/math/mixed_number_c/comparison.hpp>
#include <boost/mpl/math/mixed_number_c/arithmetic.hpp>
#include <boost/mpl/math/mixed_number_c/constants.hpp>
#include <boost/mpl/math/mixed_number_c/runtime_cast.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/convert_rational_c.hpp>
#include <boost/mpl/math/mixed_number_c/aux_/convert_rational.hpp>
#include <boost/mpl/math/rational_c/aux_/simplify.hpp>
#include <boost/mpl/numeric_cast.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * Each template instance encapsulates a Mixed Numeric Constant.
     * D must be positive.  If W is nonzero, then N cannot be negative.
     */
    template <boost::intmax_t W, boost::intmax_t N, boost::intmax_t D>
    struct mixed_number_c : mixed_number_c_::impl<W,N,D>::type
    {
    };

    template <typename IntegralConstant>
    struct integral_to_mixed_number_c
      : mixed_number_c_impl<IntegralConstant::value,0,1>::type
    {
    };

    template <boost::intmax_t Value>
    struct integral_c_to_mixed_number_c : mixed_number_c_impl<Value,0,1>::type
    {
    };
  }  // namespace math

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<
        integral_c_tag
      , math::mixed_number_c_tag
    >
    {
        template <typename IntegralConstant>
        struct apply
        {
            typedef math::mixed_number_c_impl<IntegralConstant::value,0,1>
                    type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_MIXED_NUMBER_C_HPP_INCLUDED

