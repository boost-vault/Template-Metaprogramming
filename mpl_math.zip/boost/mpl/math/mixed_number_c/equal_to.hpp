// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_EQUAL_TO_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_EQUAL_TO_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/integral_c.hpp>

namespace boost { namespace mpl {

    template <>
    struct equal_to_impl<math::mixed_number_c_tag,math::mixed_number_c_tag>
    {
        template <
            typename MixedNumericConstant1
          , typename MixedNumericConstant2
        >
        struct apply
        {
         private:
            BOOST_STATIC_CONSTANT(
                bool
              , value = (
                    (
                        MixedNumericConstant1::whole
                     == MixedNumericConstant2::whole
                    )
                 && (
                        MixedNumericConstant1::frac_num
                     == MixedNumericConstant2::frac_num
                    )
                 && (
                        (0 == MixedNumericConstant1::frac_num)
                     || (
                            MixedNumericConstant1::frac_den
                         == MixedNumericConstant2::frac_den
                        )
                    )
                )
            );

         public:
            typedef integral_c<bool,value> type;
        };
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_EQUAL_TO_HPP_INCLUDED

