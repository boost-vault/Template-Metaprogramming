// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_RECIPROCAL_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_RECIPROCAL_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/reciprocal.hpp>
#include <boost/mpl/math/mixed_number_c/impl.hpp>

namespace boost { namespace mpl { namespace math {
  namespace mixed_number_c_ {

    template <boost::intmax_t N, boost::intmax_t D>
    struct reciprocal_of_small_number
    {
     private:
#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
        enum
        {
            new_whole = D / N
          , new_frac_den = (N < 0) ? -N : N
          , new_frac_num = D % new_frac_den
        };
#else
        static const boost::intmax_t new_whole = D / N;
        static const boost::intmax_t new_frac_den = (N < 0) ? -N : N;
        static const boost::intmax_t new_frac_num = D % new_frac_den;
#endif  // BOOST_NO_INCLASS_MEMBER_INITIALIZATION

     public:
        typedef mixed_number_c_impl<new_whole,new_frac_num,new_frac_den> type;
    };

    template <typename MixedNumericConstant>
    struct reciprocal
    {
     private:
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , old_whole = MixedNumericConstant::whole
        );
        BOOST_STATIC_CONSTANT(
            bool
          , has_zero_whole = (old_whole == 0)
        );
        BOOST_STATIC_CONSTANT(
            bool
          , has_abs_one_whole = ((old_whole == 1) || (old_whole == -1))
        );
        BOOST_STATIC_CONSTANT(
            bool
          , has_negative_whole = (old_whole < 0)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , sign_one = (has_negative_whole ? -1 : 1)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , abs_old_whole = (has_negative_whole ? -old_whole : old_whole)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , old_frac_num = MixedNumericConstant::frac_num
        );
        BOOST_STATIC_CONSTANT(
            bool
          , has_zero_frac_num = (old_frac_num == 0)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , old_frac_den = MixedNumericConstant::frac_den
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , new_frac_num = (has_negative_whole ? -old_frac_den : old_frac_den)
        );
        BOOST_STATIC_CONSTANT(
            boost::intmax_t
          , new_frac_den = abs_old_whole * old_frac_den + old_frac_num
        );

     public:
        typedef typename eval_if_c<
                    has_zero_frac_num
                  , eval_if_c<
                        has_zero_whole
                      , boost::mpl::error::zero_divisor
                      , eval_if_c<
                            has_abs_one_whole
                          , mixed_number_c_impl<old_whole,0,1>
                          , mixed_number_c_impl<0,sign_one,abs_old_whole>
                        >
                    >
                  , eval_if_c<
                        has_zero_whole
                      , reciprocal_of_small_number<old_frac_num,old_frac_den>
                      , mixed_number_c_impl<0,new_frac_num,new_frac_den>
                    >
                >::type
                type;
    };
  }  // namespace mixed_number_c_

    template <>
    struct reciprocal_impl<mixed_number_c_tag>
    {
        template <typename MixedNumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : mixed_number_c_::reciprocal<MixedNumericConstant>
        {
#else
        {
            typedef typename mixed_number_c_::reciprocal<
                        MixedNumericConstant
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_RECIPROCAL_HPP_INCLUDED

