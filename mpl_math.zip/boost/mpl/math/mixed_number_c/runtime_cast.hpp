// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_RUNTIME_CAST_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_RUNTIME_CAST_HPP_INCLUDED

#include <boost/cstdint.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/runtime_cast.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>

namespace boost {
  namespace mpl {

    template <>
    struct runtime_value_impl<math::mixed_number_c_tag>
    {
        template <typename ResultType>
        struct apply
        {
            BOOST_MPL_AUX_SELF_TYPEDEF(apply)

            template <typename MixedNumericConstant>
            static ResultType eval(MixedNumericConstant const& n)
            {
                boost::intmax_t whole = MixedNumericConstant::whole;
                ResultType frac_num = MixedNumericConstant::frac_num;

                return (
                    ((whole < 0) ? -1 : 1)
                  * (frac_num / MixedNumericConstant::frac_den + whole)
                );
            }
        };
    };
  }  // namespace mpl
}  // namespace boost

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_RUNTIME_CAST_HPP_INCLUDED

