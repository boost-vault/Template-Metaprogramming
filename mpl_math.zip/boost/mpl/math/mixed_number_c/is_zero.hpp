// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_IS_ZERO_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_IS_ZERO_HPP_INCLUDED

#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/integral_c.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct is_zero_impl<mixed_number_c_tag>
    {
        template <typename MixedNumericConstant>
        struct apply
        {
         private:
            BOOST_STATIC_CONSTANT(
                bool
              , value = (
                    (0 == MixedNumericConstant::whole)
                 && (0 == MixedNumericConstant::frac_num)
                )
            );

         public:
            typedef integral_c<bool,value> type;
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_IS_ZERO_HPP_INCLUDED

