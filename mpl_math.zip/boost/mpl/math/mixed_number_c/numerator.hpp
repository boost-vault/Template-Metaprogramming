// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_MIXED_NUMBER_C_NUMERATOR_HPP_INCLUDED
#define BOOST_MPL_MATH_MIXED_NUMBER_C_NUMERATOR_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/integral_c.hpp>

namespace boost { namespace mpl { namespace math {

    template <>
    struct numerator_impl<mixed_number_c_tag>
    {
        template <typename MixedNumericConstant>
        struct apply
        {
#if defined(BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC)
         private:
            BOOST_STATIC_CONSTANT(
                boost::intmax_t
              , value = (
                    MixedNumericConstant::whole
                  * MixedNumericConstant::frac_den
                  + MixedNumericConstant::frac_num
                )
            );

         public:
            typedef integral_c<boost::intmax_t,value> type;
#else
            typedef integral_c<
                        boost::intmax_t
                      , MixedNumericConstant::whole
                      * MixedNumericConstant::frac_den
                      + MixedNumericConstant::frac_num
                    >
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC
        };
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_MIXED_NUMBER_C_NUMERATOR_HPP_INCLUDED

