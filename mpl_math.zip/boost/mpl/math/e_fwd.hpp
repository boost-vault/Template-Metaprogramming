// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_E_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_E_FWD_HPP_INCLUDED

#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/numeric_tag.hpp>

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct e_dispatch;

    template <typename NumericType>
    struct e : e_dispatch<typename numeric_tag<NumericType>::type>
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, e, (NumericType))
    };
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_E_FWD_HPP_INCLUDED

