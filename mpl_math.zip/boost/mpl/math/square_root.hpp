// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_SQUARE_ROOT_HPP_INCLUDED
#define BOOST_MPL_MATH_SQUARE_ROOT_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
#define BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES 8
#endif

#include <boost/config.hpp>
#include <boost/preprocessor/facilities/identity.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/zero.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/three.hpp>
#include <boost/mpl/math/four.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/math/integral_part.hpp>
#include <boost/mpl/less.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/bitand.hpp>
#include <boost/mpl/error/input_out_of_domain.hpp>

#define BOOST_MPL_MATH_INTEGRAL_SQUARE_ROOT_MACRO(z, x, unused) \
        BOOST_STATIC_CONSTANT( \
            bool \
          , BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, x) \
             || (0 == BOOST_PP_CAT(one_step_, x)) \
            ) \
        ); \
        BOOST_STATIC_CONSTANT( \
            bool \
          , BOOST_PP_CAT(do_not_update_operand_pred_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(operand_step_, x) \
              < BOOST_PP_CAT(one_step_, x) + BOOST_PP_CAT(result_step_, x) \
            ) \
        ); \
        BOOST_STATIC_CONSTANT( \
            ValueType \
          , BOOST_PP_CAT(operand_step_, BOOST_PP_INC(x)) = ( \
                ( \
                    BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
                 || BOOST_PP_CAT( \
                        do_not_update_operand_pred_ \
                      , BOOST_PP_INC(x) \
                    ) \
                ) \
              ? BOOST_PP_CAT(operand_step_, x) \
              : ( \
                    BOOST_PP_CAT(operand_step_, x) \
                  - ( \
                        BOOST_PP_CAT(one_step_, x) \
                      + BOOST_PP_CAT(result_step_, x) \
                    ) \
                ) \
            ) \
        ); \
        BOOST_STATIC_CONSTANT( \
            ValueType \
          , BOOST_PP_CAT(one_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
              ? 0 \
              : (BOOST_PP_CAT(one_step_, x) >> 2) \
            ) \
        ); \
        BOOST_STATIC_CONSTANT( \
            ValueType \
          , BOOST_PP_CAT(result_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(stop_recurse_pred_, BOOST_PP_INC(x)) \
              ? BOOST_PP_CAT(result_step_, x) \
              : BOOST_PP_CAT(do_not_update_operand_pred_, BOOST_PP_INC(x)) \
              ? (BOOST_PP_CAT(result_step_, x) >> 1) \
              : ( \
                    ( \
                        BOOST_PP_CAT(result_step_, x) \
                      + (BOOST_PP_CAT(one_step_, x) << 1) \
                    ) \
                 >> 1 \
                ) \
            ) \
        ); \
        /**/

#define BOOST_MPL_MATH_POWER_OF_FOUR_MACRO(z, x, unused) \
        BOOST_STATIC_CONSTANT( \
            bool \
          , BOOST_PP_CAT(recurse_pred_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(recurse_pred_, x) \
             && (Operand < BOOST_PP_CAT(result_step_, x)) \
            ) \
        ); \
        BOOST_STATIC_CONSTANT( \
            ValueType \
          , BOOST_PP_CAT(result_step_, BOOST_PP_INC(x)) = ( \
                BOOST_PP_CAT(recurse_pred_, BOOST_PP_INC(x)) \
              ? (BOOST_PP_CAT(result_step_, x) >> 2) \
              : BOOST_PP_CAT(result_step_, x) \
            ) \
        ); \
        /**/

#define BOOST_MPL_MATH_SQUARE_ROOT_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        typedef typename divides< \
                    plus< \
                        divides<NumericConstant,BOOST_PP_CAT(prefix, x)> \
                      , BOOST_PP_CAT(prefix, x) \
                    > \
                  , two_type \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {
  namespace aux {

    template <typename ValueType>
    struct integral_square_root_impl
    {
        template <ValueType Operand, ValueType One, ValueType Result>
        struct helper
        {
            /*
             * Compile-time binary method.
             */
         private:
            BOOST_STATIC_CONSTANT(
                bool
              , stop_recurse_pred_0 = (0 == One)
            );
            BOOST_STATIC_CONSTANT(
                bool
              , do_not_update_operand_pred_0 = (Operand < One + Result)
            );
            BOOST_STATIC_CONSTANT(
                ValueType
              , operand_step_0 = (
                    (stop_recurse_pred_0 || do_not_update_operand_pred_0)
                  ? Operand
                  : (Operand - (One + Result))
                )
            );
            BOOST_STATIC_CONSTANT(
                ValueType
              , one_step_0 = (stop_recurse_pred_0 ? 0 : (One >> 2))
            );
            BOOST_STATIC_CONSTANT(
                ValueType
              , result_step_0 = (
                    stop_recurse_pred_0
                  ? Result
                  : do_not_update_operand_pred_0
                  ? (Result >> 1)
                  : ((Result + (One << 1)) >> 1)
                )
            );
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
              , BOOST_MPL_MATH_INTEGRAL_SQUARE_ROOT_MACRO
              , unused
            )

         public:
            typedef typename eval_if_c<
                        BOOST_PP_CAT(
                            stop_recurse_pred_
                          , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                        )
                      , integral_c<
                            ValueType
                          , BOOST_PP_CAT(
                                result_step_
                              , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                            )
                        >
                      , helper<
                            BOOST_PP_CAT(
                                operand_step_
                              , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                            )
                          , BOOST_PP_CAT(
                                one_step_
                              , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                            )
                          , BOOST_PP_CAT(
                                result_step_
                              , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                            )
                        >
                    >::type
                    type;
        };

        template <ValueType Operand, ValueType N>
        struct power_of_four
        {
            BOOST_STATIC_CONSTANT(
                bool
              , recurse_pred_0 = (Operand < N)
            );
            BOOST_STATIC_CONSTANT(
                ValueType
              , result_step_0 = (recurse_pred_0 ? (N >> 2) : N)
            );
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
              , BOOST_MPL_MATH_POWER_OF_FOUR_MACRO
              , unused
            )
            typedef typename eval_if_c<
                        BOOST_PP_CAT(
                            recurse_pred_
                          , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                        )
                      , power_of_four<
                            Operand
                          , BOOST_PP_CAT(
                                result_step_
                              , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                            )
                        >
                      , integral_c<
                            ValueType
                          , BOOST_PP_CAT(
                                result_step_
                              , BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
                            )
                        >
                    >::type
                    type;
        };
    };

    template <typename IntegralConstant>
    struct integral_square_root
    {
     private:
#if defined(BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC)
        BOOST_STATIC_CONSTANT(
            typename IntegralConstant::value_type
          , n_start = (
                1
             << ((sizeof(typename IntegralConstant::value_type) << 3) - 2)
            )
        );
        typedef typename integral_square_root_impl<
                    typename IntegralConstant::value_type
                >::BOOST_NESTED_TEMPLATE power_of_four<
                    IntegralConstant::value
                  , n_start
                >::type
                power_of_four_type;
#else
        typedef typename integral_square_root_impl<
                    typename IntegralConstant::value_type
                >::BOOST_NESTED_TEMPLATE power_of_four<
                    IntegralConstant::value
                  , (
                        1
                     << (
                            (
                                sizeof(typename IntegralConstant::value_type)
                             << 3
                            )
                          - 2
                        )
                    )
                >::type
                power_of_four_type;
#endif  // BOOST_MPL_CFG_NO_NESTED_VALUE_ARITHMETIC

     public:
        typedef typename integral_square_root_impl<
                    typename IntegralConstant::value_type
                >::BOOST_NESTED_TEMPLATE helper<
                    IntegralConstant::value
                  , power_of_four_type::value
                  , 0
                >::type
                type;
    };
  }  // namespace aux

    template <typename NumericTag>
    struct square_root_impl
    {
     private:
        typedef typename two_dispatch<NumericTag>::type  two_type;
        typedef typename four_dispatch<NumericTag>::type four_type;

     public:
        template <typename NumericConstant>
        struct apply
        {
            /*
             * Compile-time Babylonian series.
             */
            typedef typename eval_if<
                        is_negative<NumericConstant>
                      , boost::mpl::error::input_out_of_domain
                      , eval_if<
                            less<NumericConstant,four_type>
                          , divides<NumericConstant,two_type>
                          , aux::integral_square_root<
                                integral_part<NumericConstant>
                            >
                        >
                    >::type
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES
              , BOOST_MPL_MATH_SQUARE_ROOT_MACRO
              , term_
            )
                    type;
        };
    };

    template <>
    struct square_root_impl<integral_c_tag>
    {
        template <typename NumericConstant>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : eval_if<
                is_negative<NumericConstant>
              , boost::mpl::error::input_out_of_domain
              , aux::integral_square_root<NumericConstant>
            >
        {
#else
        {
            typedef typename eval_if<
                        is_negative<NumericConstant>
                      , boost::mpl::error::input_out_of_domain
                      , aux::integral_square_root<NumericConstant>
                    >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename NumericConstant>
    struct square_root
      : apply_wrap1<
            square_root_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, square_root, (NumericConstant))
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_MATH_SQUARE_ROOT_MACRO
#undef BOOST_MPL_MATH_POWER_OF_FOUR_MACRO
#undef BOOST_MPL_MATH_INTEGRAL_SQUARE_ROOT_MACRO
#undef BOOST_MPL_LIMIT_MATH_SQUARE_ROOT_SERIES

#endif  // BOOST_MPL_MATH_SQUARE_ROOT_HPP_INCLUDED

