// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_HYPERBOLIC_SINE_HPP_INCLUDED
#define BOOST_MPL_MATH_HYPERBOLIC_SINE_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_HYPERBOLIC_SINE_SERIES
#define BOOST_MPL_LIMIT_MATH_HYPERBOLIC_SINE_SERIES 16
#endif

#include <boost/cstdint.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/one.hpp>

#define BOOST_MPL_MATH_HYPERBOLIC_SINE_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        BOOST_STATIC_CONSTANT( \
            boost::intmax_t \
          , BOOST_PP_CAT(constant_, x) = \
                (((BOOST_MPL_LIMIT_MATH_HYPERBOLIC_SINE_SERIES - x) << 1) + 1) \
              * ((BOOST_MPL_LIMIT_MATH_HYPERBOLIC_SINE_SERIES - x) << 1) \
        ); \
        typedef typename plus< \
                    times< \
                        divides< \
                            angle_squared \
                          , integral_c< \
                                boost::intmax_t \
                              , BOOST_PP_CAT(constant_, x) \
                            > \
                        > \
                      , BOOST_PP_CAT(prefix, x) \
                    > \
                  , one_type \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct hyperbolic_sine_impl
    {
     private:
        typedef typename one_dispatch<NumericTag>::type one_type;

     public:
        template <typename Angle>
        struct apply
        {
         private:
            /*
             * Compile-time Taylor series.
             */
            typedef typename times<Angle,Angle>::type
                    angle_squared;
            typedef one_type
            BOOST_PP_REPEAT(
                BOOST_MPL_LIMIT_MATH_HYPERBOLIC_SINE_SERIES
              , BOOST_MPL_MATH_HYPERBOLIC_SINE_MACRO
              , term_
            )
                    last_term;

         public:
            typedef typename times<Angle,last_term>::type
                    type;
        };
    };

    template <typename Angle>
    struct hyperbolic_sine
      : apply_wrap1<
            hyperbolic_sine_impl<typename Angle::tag>
          , Angle
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, hyperbolic_sine, (Angle))
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_LIMIT_MATH_HYPERBOLIC_SINE_SERIES
#undef BOOST_MPL_MATH_HYPERBOLIC_SINE_MACRO

#endif  // BOOST_MPL_MATH_HYPERBOLIC_SINE_HPP_INCLUDED

