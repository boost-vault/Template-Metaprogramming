// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_ADVANCED_HPP_INCLUDED
#define BOOST_MPL_MATH_ADVANCED_HPP_INCLUDED

#include <boost/mpl/math/integral_gcd.hpp>
#include <boost/mpl/math/integral_lcm.hpp>
#include <boost/mpl/math/gcd.hpp>
#include <boost/mpl/math/lcm.hpp>
#include <boost/mpl/math/factorial.hpp>
#include <boost/mpl/math/integral_power.hpp>
#include <boost/mpl/math/square_root.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/math/logarithm.hpp>
#include <boost/mpl/math/power.hpp>
#include <boost/mpl/math/sine.hpp>
#include <boost/mpl/math/cosine.hpp>
#include <boost/mpl/math/tangent.hpp>
#include <boost/mpl/math/arcus_sine.hpp>
#include <boost/mpl/math/arcus_cosine.hpp>
#include <boost/mpl/math/arcus_tangent.hpp>
#include <boost/mpl/math/hypersine.hpp>
#include <boost/mpl/math/hypercosine.hpp>
#include <boost/mpl/math/hypertangent.hpp>

#endif  // BOOST_MPL_MATH_ADVANCED_HPP_INCLUDED

