// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_FWD_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_FWD_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/math/zero.hpp>

namespace boost { namespace mpl { namespace math {

    template <
        typename NumericConstant_Real
      , typename NumericConstant_Imaginary = zero<NumericConstant_Real>
    >
    struct complex_number;

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename ValueType, boost::intmax_t R, boost::intmax_t I = 0>
#else
    template <typename ValueType, ValueType R, ValueType I = 0>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct complex_number_c;
}}}  // namespace boost::mpl::math

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_FWD_HPP_INCLUDED

