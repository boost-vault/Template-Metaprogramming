// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_EXPONENTIAL_HPP_INCLUDED
#define BOOST_MPL_MATH_EXPONENTIAL_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES
#define BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES 16
#endif

#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/arithmetic/dec.hpp>
#include <boost/preprocessor/arithmetic/sub.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/four.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>

#define BOOST_MPL_MATH_EXPONENTIAL_PRE_ORDER_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        typedef typename plus<BOOST_PP_CAT(prefix, x),four_type>::type \
        /**/

#define BOOST_MPL_MATH_EXPONENTIAL_POST_ORDER_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        typedef typename divides< \
                    BOOST_PP_CAT(prefix, 0) \
                  , plus< \
                        BOOST_PP_CAT(prefix, x) \
                      , BOOST_PP_CAT( \
                            addend_ \
                          , BOOST_PP_SUB( \
                                BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES \
                              , x \
                            ) \
                        ) \
                    > \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct exponential_impl
    {
     private:
        typedef typename one_dispatch<NumericTag>::type
                one_type;
        typedef typename two_dispatch<NumericTag>::type
                two_type;
        typedef typename four_dispatch<NumericTag>::type
                four_type;
        typedef typename plus<two_type,four_type>::type
        BOOST_PP_REPEAT(
            BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES
          , BOOST_MPL_MATH_EXPONENTIAL_PRE_ORDER_MACRO
          , addend_
        )
                BOOST_PP_CAT(
                    addend_
                  , BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES
                );

     public:
        template <typename NumericConstant>
        struct apply
        {
         private:
            /*
             * Compile-time continued-fraction series.
             */
            typedef typename times<NumericConstant,NumericConstant>::type
            BOOST_PP_REPEAT(
                BOOST_PP_INC(BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES)
              , BOOST_MPL_MATH_EXPONENTIAL_POST_ORDER_MACRO
              , dividend_
            )
                    last_dividend;

         public:
            typedef typename plus<
                        divides<
                            times<NumericConstant,two_type>
                          , plus<
                                minus<two_type,NumericConstant>
                              , last_dividend
                            >
                        >
                      , one_type
                    >::type
                    type;
        };
    };

    template <typename NumericConstant>
    struct exponential
      : apply_wrap1<
            exponential_impl<typename NumericConstant::tag>
          , NumericConstant
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            1
          , exponential
          , (NumericConstant)
        )
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_MATH_EXPONENTIAL_MACRO_POST_ORDER
#undef BOOST_MPL_MATH_EXPONENTIAL_MACRO_PRE_ORDER
#undef BOOST_MPL_LIMIT_MATH_EXPONENTIAL_SERIES

#endif  // BOOST_MPL_MATH_EXPONENTIAL_HPP_INCLUDED

