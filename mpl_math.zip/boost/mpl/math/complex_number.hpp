// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_COMPLEX_NUMBER_HPP_INCLUDED
#define BOOST_MPL_MATH_COMPLEX_NUMBER_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/self_typedef.hpp>
#include <boost/mpl/aux_/numeric_constant_2_stream.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/complex_number_tag.hpp>
#include <boost/mpl/math/complex_number_fwd.hpp>
#include <boost/mpl/numeric_cast.hpp>
#include <boost/mpl/math/complex_number/numeric.hpp>
#include <boost/mpl/math/complex_number/comparison.hpp>
#include <boost/mpl/math/complex_number/arithmetic.hpp>
#include <boost/mpl/math/complex_number/advanced.hpp>
#include <boost/mpl/math/complex_number/runtime_cast.hpp>
#include <boost/mpl/math/zero.hpp>

namespace boost { namespace mpl { namespace math {

    /*
     * Each template instance encapsulates a Complex Numeric Constant.
     */
    template <
        typename NumericConstant_Real
      , typename NumericConstant_Imaginary
    >
    struct complex_number
    {
        /*
         * Self-reference.
         */
        BOOST_MPL_AUX_SELF_TYPEDEF(complex_number)

        /*
         * Tag for BOOST_MPL_AUX_NUMERIC_CAST.
         */
        typedef complex_number_tag
                tag;

        /*
         * The relevant parts of a Complex Numeric Constant.
         */
        typedef NumericConstant_Real
                real_part;
        typedef NumericConstant_Imaginary
                imaginary_part;

        /*
         * Sends a text representation of this Complex Numeric Constant to the
         * specified output stream.
         */
        template <typename OutputStream>
        static void extract(OutputStream& out)
        {
            out << '(';
            boost::mpl::aux::numeric_constant_2_stream<
                typename real_part::tag
            >::extract(real_part(), out);
            out << ',';
            boost::mpl::aux::numeric_constant_2_stream<
                typename imaginary_part::tag
            >::extract(imaginary_part(), out);
            out << ')';
        }
    };

    /*
     * Each template instance encapsulates a Complex Numeric Constant.
     */
#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename ValueType, boost::intmax_t R, boost::intmax_t I>
#else
    template <typename ValueType, ValueType R, ValueType I>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct complex_number_c
      : complex_number<integral_c<ValueType,R>,integral_c<ValueType,I> >
    {
    };

    template <>
    struct zero<complex_number_tag>
      : complex_number<
            integral_c<boost::intmax_t,0>
          , integral_c<boost::intmax_t,0>
        >
    {
    };
  }  // namespace math

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<integral_c_tag,math::complex_number_tag>
    {
        template <typename IntegralConstant>
        struct apply
        {
            typedef math::complex_number<IntegralConstant> type;
        };
    };

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<
        math::double_tag
      , math::complex_number_tag
    >
    {
        template <typename DoubleConstant>
        struct apply
        {
            typedef math::complex_number<DoubleConstant> type;
        };
    };

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<
        math::rational_c_tag
      , math::complex_number_tag
    >
    {
        template <typename RationalConstant>
        struct apply
        {
            typedef math::complex_number<RationalConstant> type;
        };
    };

    template <>
    struct BOOST_MPL_AUX_NUMERIC_CAST<
        math::mixed_number_c_tag
      , math::complex_number_tag
    >
    {
        template <typename MixedNumericConstant>
        struct apply
        {
            typedef math::complex_number<MixedNumericConstant> type;
        };
    };
}}  // namespace boost::mpl

/*
 * Operator overload for outputting complex_number instances using an output
 * stream.  NOT FOR BITSHIFTING!
 */
template <
    typename OutputStream
  , typename NumericConstant_Real
  , typename NumericConstant_Imaginary
>
inline OutputStream& operator<<(
    OutputStream& out
  , boost::mpl::math::complex_number<
        NumericConstant_Real
      , NumericConstant_Imaginary
    > const& c
)
{
    boost::mpl::math::complex_number<
        NumericConstant_Real
      , NumericConstant_Imaginary
    >::extract(out);

    return out;
}

#endif  // BOOST_MPL_MATH_COMPLEX_NUMBER_HPP_INCLUDED

