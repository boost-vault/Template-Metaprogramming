// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MATH_PI_HPP_INCLUDED
#define BOOST_MPL_MATH_PI_HPP_INCLUDED

#ifndef BOOST_MPL_LIMIT_MATH_PI_SERIES
#define BOOST_MPL_LIMIT_MATH_PI_SERIES 8
#endif

#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/one.hpp>
#include <boost/mpl/math/two.hpp>
#include <boost/mpl/math/four.hpp>
#include <boost/mpl/math/pi_fwd.hpp>

#define BOOST_MPL_MATH_PI_MACRO(z, x, prefix) \
                BOOST_PP_CAT(prefix, x); \
        typedef typename plus<BOOST_PP_CAT(addend_, x),k_8>::type \
                BOOST_PP_CAT(addend_, BOOST_PP_INC(x)); \
        typedef typename times<BOOST_PP_CAT(dividend_, x),addend_0>::type \
                BOOST_PP_CAT(dividend_, BOOST_PP_INC(x)); \
        typedef typename plus< \
                    divides< \
                        minus< \
                            minus< \
                                minus< \
                                    divides< \
                                        k_4 \
                                      , plus< \
                                            BOOST_PP_CAT( \
                                                addend_ \
                                              , BOOST_PP_INC(x) \
                                            ) \
                                          , k_1 \
                                        > \
                                    > \
                                  , divides< \
                                        k_2 \
                                      , plus< \
                                            BOOST_PP_CAT( \
                                                addend_ \
                                              , BOOST_PP_INC(x) \
                                            ) \
                                          , k_4 \
                                        > \
                                    > \
                                > \
                              , divides< \
                                    k_1 \
                                  , plus< \
                                        BOOST_PP_CAT( \
                                            addend_ \
                                          , BOOST_PP_INC(x) \
                                        ) \
                                      , k_5 \
                                    > \
                                > \
                            > \
                          , divides< \
                                k_1 \
                              , plus< \
                                    BOOST_PP_CAT(addend_, BOOST_PP_INC(x)) \
                                  , k_6 \
                                > \
                            > \
                        > \
                      , BOOST_PP_CAT(dividend_, BOOST_PP_INC(x)) \
                    > \
                  , BOOST_PP_CAT(prefix, x) \
                >::type \
        /**/

namespace boost { namespace mpl { namespace math {

    template <typename NumericTag>
    struct pi_dispatch
    {
        /*
         * Compile-time Bailey-Borwein-Plouffe series.
         */
        typedef typename one_dispatch<NumericTag>::type
                k_1;
        typedef typename two_dispatch<NumericTag>::type
                k_2;
        typedef typename four_dispatch<NumericTag>::type
                k_4;
        typedef typename plus<k_4,k_1>::type
                k_5;
        typedef typename plus<k_4,k_2>::type
                k_6;
        typedef typename plus<k_4,k_4>::type
                k_8;
        typedef typename minus<
                    minus<
                        minus<k_4,divides<k_1,k_2> >
                      , divides<k_1,k_5>
                    >
                  , divides<k_1,k_6>
                >::type
                pre_term_0;
        typedef typename times<k_4,k_4>::type
                addend_0;
        typedef typename plus<
                    divides<
                        minus<
                            minus<
                                minus<
                                    divides<k_4,plus<k_8,k_1> >
                                  , divides<k_1,k_6>
                                >
                              , divides<k_1,plus<k_8,k_5> >
                            >
                          , divides<k_1,plus<k_8,k_6> >
                        >
                      , addend_0
                    >
                  , pre_term_0
                >::type
                pre_term_1;
        typedef typename times<addend_0,addend_0>::type
                dividend_0;
        typedef typename plus<
                    divides<
                        minus<
                            minus<
                                minus<
                                    divides<k_4,plus<addend_0,k_1> >
                                  , divides<k_1,plus<k_8,k_2> >
                                >
                              , divides<k_1,plus<addend_0,k_5> >
                            >
                          , divides<k_1,plus<addend_0,k_6> >
                        >
                      , dividend_0
                    >
                  , pre_term_1
                >::type
        BOOST_PP_REPEAT(
            BOOST_MPL_LIMIT_MATH_PI_SERIES
          , BOOST_MPL_MATH_PI_MACRO
          , term_
        )
                type;
    };
}}}  // namespace boost::mpl::math

#undef BOOST_MPL_MATH_PI_MACRO
#undef BOOST_MPL_LIMIT_MATH_PI_SERIES

#endif  // BOOST_MPL_MATH_PI_HPP_INCLUDED

