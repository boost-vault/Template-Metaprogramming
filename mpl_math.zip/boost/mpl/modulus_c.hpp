// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_MODULUS_C_HPP_INCLUDED
#define BOOST_MPL_MODULUS_C_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/cstdint.hpp>
#include <boost/mpl/aux_/config/static_constant.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/error/zero_divisor.hpp>

namespace boost { namespace mpl {
  namespace aux { namespace modulus_c_ {

    template <typename ValueType>
    struct dispatch;

#if !defined BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
#define BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(value_type, name) \
        template <value_type N1, value_type N2> \
        struct BOOST_PP_CAT(name, _helper) \
        { \
            BOOST_STATIC_CONSTANT(value_type, value = N1 % N2); \
        }; \
        template <value_type N1> \
        struct BOOST_PP_CAT(name, _helper)<N1,0> \
        { \
            BOOST_STATIC_CONSTANT(value_type, value = 0); \
        }; \
        template <value_type N2> \
        struct BOOST_PP_CAT(name, _helper)<0,N2> \
        { \
            BOOST_STATIC_CONSTANT(value_type, value = 0); \
        }; \
        template <> \
        struct BOOST_PP_CAT(name, _helper)<0,0> \
        { \
            BOOST_STATIC_CONSTANT(value_type, value = 0); \
        }; \
        template <> \
        struct dispatch<value_type> \
        { \
            template <value_type N1, value_type N2> \
            struct apply \
            { \
                BOOST_STATIC_CONSTANT( \
                    value_type \
                  , value = (BOOST_PP_CAT(name, _helper)<N1,N2>::value) \
                ); \
            }; \
        }; \
        /**/
#else
#define BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(value_type, name) \
        template <value_type N1> \
        struct BOOST_PP_CAT(name, _helper2) \
        { \
            template <value_type N2> \
            struct apply \
            { \
                BOOST_STATIC_CONSTANT(value_type, value = N1 % N2); \
            }; \
            template <> \
            struct apply<0> \
            { \
                BOOST_STATIC_CONSTANT(value_type, value = 0); \
            }; \
        }; \
        template <> \
        struct BOOST_PP_CAT(name, _helper2)<0> \
        { \
            template <value_type N2> \
            struct apply \
            { \
                BOOST_STATIC_CONSTANT(value_type, value = 0); \
            }; \
        }; \
        template <> \
        struct dispatch<value_type> \
        { \
            template <value_type N1, value_type N2> \
            struct apply \
            { \
                BOOST_STATIC_CONSTANT( \
                    value_type \
                  , value = ( \
                        BOOST_PP_CAT(name, _helper2)< \
                            N1 \
                        >::BOOST_NESTED_TEMPLATE apply<N2>::value \
                    ) \
                ); \
            }; \
        }; \
        /**/
#endif  // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#define BOOST_MPL_MODULUS_C_HELPER_DISPATCH(value_type) \
        BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(value_type, value_type) \
        /**/

BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(signed char, schar)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(char)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(unsigned char, uchar)
#if !defined(BOOST_NO_INTRINSIC_WCHAR_T)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(wchar_t)
#endif  // BOOST_NO_INTRINSIC_WCHAR_T
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(short)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(unsigned short, ushort)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(int)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(unsigned int, uint)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(long)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2(unsigned long, ulong)
#if defined(BOOST_HAS_LONG_LONG)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(long_long_type)
BOOST_MPL_MODULUS_C_HELPER_DISPATCH(ulong_long_type)
#endif  // BOOST_HAS_LONG_LONG

#undef BOOST_MPL_MODULUS_C_HELPER_DISPATCH
#undef BOOST_MPL_MODULUS_C_HELPER_DISPATCH_2
  }}  // namespace aux::modulus_c_

#ifdef BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    template <typename ValueType, boost::intmax_t N1, boost::intmax_t N2>
#else
    template <typename ValueType, ValueType N1, ValueType N2>
#endif  // BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
    struct modulus_c
      : eval_if_c<
            0 == N2
          , boost::mpl::error::zero_divisor
          , integral_c<
                ValueType
              , aux::modulus_c_::dispatch<
                    ValueType
                >::BOOST_NESTED_TEMPLATE apply<N1,N2>::value
            >
        >::type
    {
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_MODULUS_C_HPP_INCLUDED

