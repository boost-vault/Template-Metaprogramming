// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_IS_PRIMITIVE_INTEGRAL_CONSTANT_HPP_INCLUDED
#define BOOST_MPL_IS_PRIMITIVE_INTEGRAL_CONSTANT_HPP_INCLUDED

#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/apply_wrap.hpp>
#include <boost/mpl/tag.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/integral_c_tag.hpp>
#include <boost/mpl/not.hpp>
#include <boost/type_traits/is_same.hpp>

namespace boost { namespace mpl {

    template <typename Tag>
    struct is_primitive_integral_constant_impl
    {
        template <typename T>
        struct apply
        {
            typedef false_ type;
        };
    };

    /*
     * Boolean Constants are not Integral Constants.
     */
    template <>
    struct is_primitive_integral_constant_impl<integral_c_tag>
    {
        template <typename T>
        struct apply
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
          : not_<is_same<typename T::value_type,bool> >
        {
#else
        {
            typedef typename not_<is_same<typename T::value_type,bool> >::type
                    type;
#endif  // BOOST_MPL_CFG_NO_NESTED_FORWARDING
        };
    };

    template <typename T>
    struct is_primitive_integral_constant
      : apply_wrap1<
            is_primitive_integral_constant_impl<typename tag<T>::type>
          , T
        >::type
    {
        BOOST_MPL_AUX_LAMBDA_SUPPORT(1, is_primitive_integral_constant, (T))
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_IS_PRIMITIVE_INTEGRAL_CONSTANT_HPP_INCLUDED

