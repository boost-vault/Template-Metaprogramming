// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_NUMERIC_TAG_HPP_INCLUDED
#define BOOST_MPL_NUMERIC_TAG_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/mpl/aux_/config/integral.hpp>
#include <boost/mpl/integral_c_tag.hpp>
#include <boost/mpl/math/double_tag.hpp>
#include <boost/mpl/math/rational_c_tag.hpp>
#include <boost/mpl/math/mixed_number_c_tag.hpp>
#include <boost/mpl/math/complex_number_tag.hpp>

#define BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(NumericType) \
        template <> \
        struct numeric_tag<NumericType> \
        { \
            typedef integral_c_tag type; \
        }; \
        /**/

namespace boost { namespace mpl {

    template <typename NumericType>
    struct numeric_tag;

    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(bool)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(signed char)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(char)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(unsigned char)
#if !defined(BOOST_NO_INTRINSIC_WCHAR_T)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(wchar_t)
#endif
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(short)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(unsigned short)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(int)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(unsigned int)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(long)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(unsigned long)
#if defined(BOOST_HAS_LONG_LONG)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(long_long_type)
    BOOST_MPL_NUMERIC_INTEGRAL_C_TAG(ulong_long_type)
#endif

    template <>
    struct numeric_tag<double>
    {
        typedef math::double_tag type;
    };
}}  // namespace boost::mpl

#endif  // BOOST_MPL_NUMERIC_TAG_HPP_INCLUDED

