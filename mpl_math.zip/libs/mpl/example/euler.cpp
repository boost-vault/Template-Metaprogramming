// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>

#if 0
#include <boost/mpl/int.hpp>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/complex_number.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/reciprocal.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/math/arcus_tangent.hpp>
#include <boost/mpl/runtime_cast.hpp>
#else
#include <boost/typeof/typeof.hpp>
#include <boost/type_traits/is_function.hpp>
#include <boost/type_traits/is_member_function_pointer.hpp>

struct Foo
{
    void bar();
};

struct Baz
{
};
#endif

using namespace std;
using namespace boost::mpl;

int main()
{
#if 0
    cout << setprecision(36);

    typedef times<
                int_<4>
              , minus<
                    times<
                        int_<4>
                      , math::arcus_tangent<
                            math::reciprocal<math::long_to_double<5L> >
                        >
                    >
                  , math::arcus_tangent<
                        math::reciprocal_integral<math::double_tag,int_<239> >
                    >
                >
            >::type
            pi_t;

    pi_t pi;

    cout << "This program's value of pi is ";
    cout << runtime_cast<double>(pi) << endl;

    math::exponential<math::complex_number<int_<0>,pi_t> >::type
        negative_1;

    cout << "e to the power of i times pi equals " << negative_1 << endl;
#else
    cout << boost::is_member_function_pointer<BOOST_TYPEOF(&Foo::bar)>::value << endl;
    cout << boost::is_function<BOOST_TYPEOF(Baz::bar)>::value << endl;
#endif

    return 0;
}

