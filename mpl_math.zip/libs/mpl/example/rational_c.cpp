// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/rational_c.hpp>
#include <boost/mpl/math/constants.hpp>

using namespace boost::mpl;

int main()
{
    std::cout << std::setprecision(24);

    typedef plus<
                math::rational_c<long,3,4>
              , negate<math::rational_c<int,5,6> >
            >::type
            rational_sum;

    std::cout << "Rational " << rational_sum() << " should equal ";
    std::cout << (3.0L / 4.0 - 5.0L / 6.0) << std::endl;

    std::cout << "The following rationals should equal ";
    std::cout << (3.0L * -8.0) / (-2.0 * 9.0) << std::endl;

    typedef times<
                math::rational_c<int,3,-2>
              , math::rational_c<long,-8,9>
            >::type
            rational_product;

    std::cout << "Value of rational_product = ";
    std::cout << rational_product() << std::endl;

    typedef divides<
                math::rational_c<int,-3,2>
              , math::rational_c<long,9,-8>
            >::type
            rational_quotient;

    std::cout << "Value of rational_quotient = ";
    std::cout << rational_quotient() << std::endl;

    typedef equal_to<rational_sum,rational_product>::type
            equal_s_p;

    std::cout << rational_sum() << " is " << (equal_s_p::value ? "" : "not ");
    std::cout << "equal to " << rational_product() << "." << std::endl;

    typedef less<negate<rational_sum>,negate<rational_quotient> >::type
            less_sn_qn;

    std::cout << "-(" << rational_sum() << ") is ";
    std::cout << (less_sn_qn::value ? "" : "not ");
    std::cout << "less than -(" << rational_quotient() << ")." << std::endl;

    typedef math::rational_c<long,0,4>
            rational_zero1;
    typedef math::rational_c<int,0>
            rational_zero2;
    typedef equal_to<rational_zero1,rational_zero2>::type
            equal_zeros;

    std::cout << rational_zero1() << " is ";
    std::cout << (equal_zeros::value ? "" : "not ");
    std::cout << "equal to " << rational_zero2() << "." << std::endl;

    typedef greater<rational_sum,rational_zero1>::type
            sum_positive;

    std::cout << rational_sum() << " is ";
    std::cout << (sum_positive::value ? "" : "not ");
    std::cout << "positive." << std::endl;

    typedef less_equal<rational_zero2,rational_product>::type
            product_positive;

    std::cout << rational_product() << " is ";
    std::cout << (product_positive::value ? "" : "not ");
    std::cout << "positive." << std::endl;

    typedef math::golden_ratio_dispatch<math::rational_c_tag>::type
            golden_ratio_type;

    std::cout << "The golden ratio is " << golden_ratio_type() << '.';
    std::cout << std::endl;

    typedef math::silver_ratio_dispatch<math::rational_c_tag>::type
            silver_ratio_type;

    std::cout << "The silver ratio is " << silver_ratio_type() << '.';
    std::cout << std::endl;

    typedef math::e_dispatch<math::rational_c_tag>::type
            e_type;

    std::cout << "e = " << e_type() << '.' << std::endl;

#if 1
    typedef math::pi_dispatch<math::rational_c_tag>::type
            pi_type;

    std::cout << "pi = " << pi_type() << '.' << std::endl;
#endif

    return 0;
}

