// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/math/logarithm.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{

    typedef math::exponential<math::long_to_double<1L> >::type e;
    typedef math::logarithm<e>::type                           ln_e;
    typedef math::logarithm<ln_e>::type                        ln_1;

    cout << setprecision(36);
    cout << log(exp(1.0)) << " ~= " << runtime_cast<double>(ln_e()) << endl;
    cout << log(1.0) << " ~= " << runtime_cast<double>(ln_1()) << endl;

    return 0;
}

