// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>
#include <boost/mpl/math/complex_number.hpp>

using namespace std;

int main()
{
    cout << setprecision(24);

    typedef boost::mpl::math::complex_number<
                boost::mpl::integral_c<int,2>
              , boost::mpl::integral_c<long,3>
            >
            p2rp3i;

    cout << "Let c1 be " << p2rp3i() << endl;

    typedef boost::mpl::negate<p2rp3i>::type
            n2rn3i;

    cout << "-c1 is " << n2rn3i() << endl;

    typedef boost::mpl::math::complex_number_c<long,5,6>
            p5rp6i;

    cout << "Let c2 be " << p5rp6i() << endl;

    typedef boost::mpl::plus<p5rp6i,p2rp3i>::type
            p7rp9i;

    cout << "c2 + c1 = " << p7rp9i() << endl;

    typedef boost::mpl::minus<p5rp6i,p2rp3i>::type
            p3rp3i;

    cout << "c2 - c1 = " << p3rp3i() << endl;

    typedef boost::mpl::times<p5rp6i,p2rp3i>::type
            n8rp27i;

    cout << "c2 * c1 = " << n8rp27i() << endl;

    typedef boost::mpl::divides<n8rp27i,p2rp3i>::type
            c2tc1dc1;

    cout << "c2 * c1 / c1 = " << c2tc1dc1() << endl;

    typedef boost::mpl::math::complex_number<
                boost::mpl::math::mixed_number_c<1,1,3>
              , boost::mpl::math::mixed_number_c<3,1,4>
            >
            p1a1o3rp3a1o4;

    cout << "Let c3 be " << p1a1o3rp3a1o4() << endl;

    typedef boost::mpl::divides<p1a1o3rp3a1o4,n2rn3i>::type
            n149o156rn5o26i;

    cout << "-c3 / c1 = " << n149o156rn5o26i() << endl;

    return 0;
}

