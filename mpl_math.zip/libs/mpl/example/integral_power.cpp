// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/int.hpp>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/integral_power.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    cout << setprecision(36);

    math::integral_power<math::long_to_double<7L>,int_<5> >::type
        p16807;
    math::integral_power<
        math::string_c_to_double<'-',0,'.',2>
      , int_<3>
    >::type
        n0p008;

    cout << pow(7.0, 5.0) << " ~= " << runtime_cast<double>(p16807) << endl;
    cout << pow(-.2, 3.0) << " ~= " << runtime_cast<double>(n0p008) << endl;

    return 0;
}

