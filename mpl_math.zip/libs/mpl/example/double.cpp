// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>
#include <boost/mpl/list.hpp>
#include <boost/mpl/for_each.hpp>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/divides.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>
#include <boost/mpl/math/integral_part.hpp>
#include <boost/mpl/math/fractional_part.hpp>

using namespace std;

struct your_functor
{
    template <typename Constant>
    void operator()(Constant const& n)
    {
        typedef typename Constant::mantissa
                n_mantissa;

        cout << endl << "value = " << n << endl;
        cout << "exponent  = " << Constant::exponent << endl;
        cout << "mantissa1 = " << n_mantissa::part1 << endl;
        cout << "mantissa2 = " << n_mantissa::part2 << endl;

        typedef typename boost::mpl::math::numerator<Constant>::type
                numer;
        typedef typename boost::mpl::math::denominator<Constant>::type
                denom;
        typedef typename boost::mpl::math::integral_part<Constant>::type
                i_part;
        typedef typename boost::mpl::math::fractional_part<Constant>::type
                f_part;

        cout << "numer = " << numer() << endl;
        cout << "denom = " << denom() << endl;
        cout << "i_part = " << i_part() << endl;
        cout << "f_part = " << f_part() << endl;
    }
};

int main()
{
    cout << setprecision(36) << hex;

    your_functor f;

    boost::mpl::for_each<
      boost::mpl::list<
#ifndef BOOST_MPL_CFG_NO_MATH_DOUBLE_MACRO
        BOOST_MPL_MATH_DOUBLE(-0.09375)
      , BOOST_MPL_MATH_DOUBLE(3.0625)
      , BOOST_MPL_MATH_DOUBLE(-5.875)
      , BOOST_MPL_MATH_DOUBLE(2147483647.0312497615814208984375)
      , BOOST_MPL_MATH_DOUBLE(7625597484987.1162109359)
#else  // Sorry, no BOOST_MPL_MATH_DOUBLE for you.
        boost::mpl::divides<
            boost::mpl::math::long_to_double<-3L>
          , boost::mpl::math::long_to_double<32L>
        >
      , boost::mpl::divides<
            boost::mpl::math::long_to_double<49L>
          , boost::mpl::math::long_to_double<16L>
        >
      , boost::mpl::divides<
            boost::mpl::math::long_to_double<-47L>
          , boost::mpl::math::long_to_double<8L>
        >
      , boost::mpl::math::string_c_to_double<
          2,1,4,7,4,8,3,6,4,7,'.',0,3,1,2,4,9,7,6,1,5,8,1,4,2,0,8,9,8,4,3,7,5
        >
      , boost::mpl::math::string_c_to_double<
          7,6,2,5,5,9,7,4,8,4,9,8,7,'.',1,1,6,2,1,0,9,3,5,9
        >
#endif  // BOOST_MPL_CFG_NO_MATH_DOUBLE_MACRO
      , boost::mpl::math::pi<double>
      , boost::mpl::math::e<double>
      , boost::mpl::math::golden_ratio<double>
      , boost::mpl::math::silver_ratio<double>
      >
    >(f);

    boost::mpl::for_each<
        boost::mpl::list<
            boost::mpl::math::long_to_double<0L>
          , boost::mpl::math::long_to_double<1L>
          , boost::mpl::math::long_to_double<2L>
          , boost::mpl::math::long_to_double<3L>
          , boost::mpl::math::long_to_double<4L>
          , boost::mpl::math::long_to_double<5L>
          , boost::mpl::math::long_to_double<6L>
          , boost::mpl::math::long_to_double<7L>
          , boost::mpl::math::long_to_double<8L>
          , boost::mpl::math::long_to_double<9L>
        >
    >(f);

    return 0;
}

