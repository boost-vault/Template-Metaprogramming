// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/sine.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    math::sine<
        math::string_c_to_double<0,'.',5,2,3,5,9,8,7,7,5,5,8,3,3,3>
    >::type
        about_one_half;
    math::sine<
        math::string_c_to_double<0,'.',7,8,5,3,9,8,1,6,3,3,7,5>
    >::type
        sqrt_2;
    math::sine<
        math::string_c_to_double<1,'.',0,4,7,1,9,7,5,5,1,1,6,6,6,7>
    >::type
        sqrt_3_over_2;

    cout << setprecision(36);
    cout << sin(0.52359877558333) << " ~= ";
    cout << runtime_cast<double>(about_one_half) << endl;
    cout << sin(0.785398163375) << " ~= ";
    cout << runtime_cast<double>(sqrt_2) << endl;
    cout << sin(1.04719755116667) << " ~= ";
    cout << runtime_cast<double>(sqrt_3_over_2) << endl;

    return 0;
}

