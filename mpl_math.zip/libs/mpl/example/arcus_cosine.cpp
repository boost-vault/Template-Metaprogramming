// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/arcus_cosine.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    math::arcus_cosine<
      math::string_c_to_double<
        0,'.',5
      >
    >::type
        pi_3rds;
    math::arcus_cosine<
      math::string_c_to_double<
        0,'.',7,0,7,1,0,6,7,8,1,1,8,6,5,4,7,5,2,4,4,0,0,8,4,4,3,6,2,1,0,4,8,5
      >
    >::type
        pi_4ths;
    math::arcus_cosine<
      math::string_c_to_double<
        0,'.',8,6,6,0,2,5,4,0,3,7,8,4,4,3,8,6,4,6,7,6,3,7,2,3,1,7,0,7,5,2,9,4
      >
    >::type
        pi_6ths;

    cout << setprecision(36);
    cout << acos(0.5) << " ~= " << runtime_cast<double>(pi_3rds) << endl;
    cout << acos(0.70710678118654752440084436210485) << " ~= ";
    cout << runtime_cast<double>(pi_4ths) << endl;
    cout << acos(0.86602540378443864676372317075294) << " ~= ";
    cout << runtime_cast<double>(pi_6ths) << endl;

    return 0;
}

