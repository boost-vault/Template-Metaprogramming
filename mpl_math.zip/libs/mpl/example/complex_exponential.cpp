// Copyright (C) 2007-2011 Chris Weed
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/complex_number.hpp>
#include <boost/mpl/times.hpp>
#include <boost/mpl/math/exponential.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    typedef times<math::long_to_double<-2L>,math::pi<double> >::type
            minus_two_pi;
    typedef math::complex_number<math::zero<double>,minus_two_pi>
            imag_minus_two_pi;

    cout << setprecision(36) << imag_minus_two_pi() << endl;
    cout << math::exponential<imag_minus_two_pi>::type() << endl;

    return 0;
}

