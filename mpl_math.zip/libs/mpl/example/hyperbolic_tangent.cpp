// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/hyperbolic_tangent.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    math::hyperbolic_tangent<math::long_to_double<2L> >::type tanh2;

    cout << setprecision(36);
    cout << tanh(2.0) << " ~= " << runtime_cast<double>(tanh2) << endl;

    return 0;
}

