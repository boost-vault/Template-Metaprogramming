// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>
#include <boost/mpl/list.hpp>
#include <boost/mpl/for_each.hpp>
#include <boost/mpl/integral_c.hpp>
//#include <boost/mpl/math/big_integral.hpp>
#include <boost/mpl/math/rational_c.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

struct your_functor
{
    template <typename Constant>
    void operator()(Constant const& n)
    {
        cout << runtime_cast<long double>(n) << endl;
    }
};

int main()
{
    cout << setprecision(24);

    typedef list<
                integral_c<int,42>
//              , math::big_integral<'-',5,3,6,8,7,0,9,1,2>
              , math::rational_c<long,-11,16>
              , math::mixed_number_c<2,54,100>
            >
            constants_list;

    for_each<constants_list>(your_functor());

    return 0;
}

