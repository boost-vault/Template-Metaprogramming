// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <boost/mpl/int.hpp>
#include <boost/mpl/math/gcd.hpp>
#include <boost/mpl/math/lcm.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    typedef math::gcd<int_<1>,int_<1> >::type
            gcd_1_1;
    typedef math::gcd<int_<0>,int_<0> >::type
            gcd_0_0;
    typedef math::gcd<int_<7>,int_<0> >::type
            gcd_7_0;
    typedef math::gcd<int_<0>,int_<9> >::type
            gcd_0_9;
    typedef math::gcd<int_<42>,int_<30> >::type
            gcd_42_30;
    typedef math::gcd<int_<3>,int_<-7> >::type
            gcd_3_n7;
    typedef math::gcd<int_<-8>,int_<-9> >::type
            gcd_n8_n9;
    typedef math::gcd<int_<7>,int_<49> >::type
            gcd_7_49;

    cout << "gcd(1,1) = " << gcd_1_1::value << endl;
    cout << "gcd(0,0) = " << gcd_0_0::value << endl;
    cout << "gcd(7,0) = " << gcd_7_0::value << endl;
    cout << "gcd(0,9) = " << gcd_0_9::value << endl;
    cout << "gcd(42,30) = " << gcd_42_30::value << endl;
    cout << "gcd(3,-7) = " << gcd_3_n7::value << endl;
    cout << "gcd(-8,-9) = " << gcd_n8_n9::value << endl;
    cout << "gcd(7,49) = " << gcd_7_49::value << endl;

    typedef math::lcm<int_<1>,int_<1> >::type
            lcm_1_1;
    typedef math::lcm<int_<0>,int_<0> >::type
            lcm_0_0;
    typedef math::lcm<int_<7>,int_<0> >::type
            lcm_7_0;
    typedef math::lcm<int_<0>,int_<9> >::type
            lcm_0_9;
    typedef math::lcm<int_<18>,int_<30> >::type
            lcm_18_30;
    typedef math::lcm<int_<3>,int_<7> >::type
            lcm_3_7;
    typedef math::lcm<int_<8>,int_<9> >::type
            lcm_8_9;
    typedef math::lcm<int_<7>,int_<49> >::type
            lcm_7_49;

    cout << "lcm(1,1) = " << lcm_1_1::value << endl;
    cout << "lcm(0,0) = " << lcm_0_0::value << endl;
    cout << "lcm(7,0) = " << lcm_7_0::value << endl;
    cout << "lcm(0,9) = " << lcm_0_9::value << endl;
    cout << "lcm(18,30) = " << lcm_18_30::value << endl;
    cout << "lcm(3,7) = " << lcm_3_7::value << endl;
    cout << "lcm(8,9) = " << lcm_8_9::value << endl;
    cout << "lcm(7,49) = " << lcm_7_49::value << endl;

    return 0;
}

