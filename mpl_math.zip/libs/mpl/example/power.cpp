// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/power.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    cout << setprecision(36);

    math::power<
        math::long_to_double<2>
      , math::string_c_to_double<2,'.',7,5>
    >::type
        pow_type;

    cout << pow(2.0, 2.75) << " ~= " << runtime_cast<double>(pow_type) << endl;

    return 0;
}

