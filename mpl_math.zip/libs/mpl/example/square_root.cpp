// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <complex>
#include <iostream>
#include <iomanip>
#include <boost/mpl/long.hpp>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/complex_number.hpp>
#include <boost/mpl/math/square_root.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    typedef long_<9>::type
            nine_t;

    math::square_root<nine_t>::type three;
    nine_t nine;

    cout << setprecision(36);
    cout << "The square root of " << nine;
    cout << " is " << three << endl;
    cout << "The runtime version equals " << sqrt(9.0) << endl;

    typedef long_<576>::type
            five_hundred_seventy_six_t;

    math::square_root<five_hundred_seventy_six_t>::type twenty_four;
    five_hundred_seventy_six_t five_hundred_seventy_six;

    cout << "The square root of " << five_hundred_seventy_six;
    cout << " is " << twenty_four << endl;
    cout << "The runtime version equals " << sqrt(576.0) << endl;

    typedef math::string_c_to_double<6,'.',2,5>::type
            p6p25_t;

    math::square_root<p6p25_t>::type p2p5;
    p6p25_t p6p25;

    cout << "The square root of " << runtime_cast<double>(p6p25);
    cout << " is " << runtime_cast<double>(p2p5) << endl;
    cout << "The runtime version equals " << sqrt(6.25) << endl;

    math::square_root<
        math::complex_number<
            math::long_to_double<1L>
          , math::integral_c_to_double<long,1L>
        >
    >::type
        sqrt_1_plus_i;
    complex<double> c_1_plus_i(1.0, 1.0);

    cout << "The square root of 1 + i is " << sqrt_1_plus_i << endl;
    cout << "The runtime version equals " << sqrt(c_1_plus_i) << endl;

    return 0;
}

