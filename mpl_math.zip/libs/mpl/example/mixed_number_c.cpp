// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <iomanip>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>

using namespace boost::mpl;

int main()
{
    std::cout << std::setprecision(24);

    typedef math::mixed_number_c<1,1,3>
            p1n1d3;
    typedef math::mixed_number_c<3,1,4>
            p3n1d4;
    typedef integral_c<int,-2>
            n2;
    typedef integral_c<long,-3>
            n3;
    typedef times<p1n1d3,n2>::type
            prod_r1_r2;

    std::cout << "prod_r1_r2 = " << prod_r1_r2() << std::endl;

    typedef times<p3n1d4,n3>::type
            prod_i1_i2;

    std::cout << "prod_i1_i2 = " << prod_i1_i2() << std::endl;

    typedef plus<prod_r1_r2,prod_i1_i2>::type
            sum_r12_i12;

    std::cout << "sum_r12_i12 = " << sum_r12_i12() << std::endl;

    typedef times<p3n1d4,n2>::type
            prod_i1_r2;

    std::cout << "prod_i1_r2 = " << prod_i1_r2() << std::endl;

    typedef times<p1n1d3,n3>::type
            prod_r1_i2;

    std::cout << "prod_r1_i2 = " << prod_r1_i2() << std::endl;

    typedef minus<prod_i1_r2,prod_r1_i2>::type
            diff_i1r2_r1i2;

    std::cout << "diff_i1r2_r1i2 = " << diff_i1r2_r1i2() << std::endl;

    typedef times<n2,n2>::type
            prod_r2_r2;
    typedef times<n3,n3>::type
            prod_i2_i2;
    typedef plus<prod_r2_r2,prod_i2_i2>::type
            sum_r22_i22;

    std::cout << "sum_r22_i22 = " << sum_r22_i22() << std::endl;

    typedef divides<sum_r12_i12,sum_r22_i22>::type
            quot_1;

    std::cout << "quot_1 = " << quot_1() << std::endl;

    typedef divides<diff_i1r2_r1i2,sum_r22_i22>::type
            quot_2;

    std::cout << "quot_2 = " << quot_2() << std::endl;

    typedef math::mixed_number_c<0,-1,12>
            negative_one_twelfth;
    typedef divides<integral_c<int,1>,negative_one_twelfth>::type
            negative_twelve;

    std::cout << "The inverse of " << negative_one_twelfth();
    std::cout << " is " << negative_twelve() << std::endl;

    typedef math::mixed_number_c<-1,0,3>
            negative_one;
    typedef divides<integral_c<int,1>,negative_one>::type
            negative_one_inverse;

    std::cout << "The inverse of " << negative_one();
    std::cout << " is " << negative_one_inverse() << std::endl;

    return 0;
}

