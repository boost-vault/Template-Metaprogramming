// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/exponential.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    cout << setprecision(36);

    math::exponential<
        math::long_to_double<1L>
    >::type e;

    cout << exp(1.0) << " ~= " << runtime_cast<double>(e) << endl;

    math::exponential<
        times<math::long_to_double<-2L>,math::pi<double> >
    >::type e_neg_2_pi;

    cout << exp(-6.283185307179586476925286766559) << " ~= ";
    cout << runtime_cast<double>(e_neg_2_pi) << endl;

    return 0;
}

