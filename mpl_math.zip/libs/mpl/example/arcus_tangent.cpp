// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cmath>
#include <iostream>
#include <iomanip>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/arcus_tangent.hpp>
#include <boost/mpl/runtime_cast.hpp>

using namespace std;
using namespace boost::mpl;

int main()
{
    math::arcus_tangent<
        math::string_c_to_double<
            0,'.',5,7,7,3,5,0,2,6,9,1,6,9,6,6,7,2,5
        >
    >::type
        pi_6ths;
    math::arcus_tangent<math::long_to_double<1L> >::type
        pi_4ths;
/*
    math::arcus_tangent<
        math::string_c_to_double<
            1,'.',7,3,2,0,5,0,8,0,7,4,4,9,1,6,6,3
        >
    >::type
        pi_3rds;
*/

    cout << setprecision(36);
    cout << atan(0.57735026916966725) << " ~= ";
    cout << runtime_cast<double>(pi_6ths) << endl;
    cout << atan(1.0) << " ~= " << runtime_cast<double>(pi_4ths) << endl;
//    cout << atan(1.7320508074491663) << " ~= ";
//    cout << runtime_cast<double>(pi_3rds) << endl;

    return 0;
}

