// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/mpl/logical.hpp>
#include <boost/mpl/math/numeric.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>
#include <boost/mpl/math/complex_number.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    typedef boost::mpl::math::complex_number<
                boost::mpl::integral_c<int,2>
              , boost::mpl::integral_c<long,3>
            >
            p2rp3i;

    MPL_ASSERT_RELATION(boost::mpl::math::real_part<p2rp3i>::value, ==, 2);
    MPL_ASSERT_RELATION(boost::mpl::math::imaginary_part<p2rp3i>::value, ==, 3);

    typedef boost::mpl::negate<p2rp3i>::type
            n2rn3i;

    MPL_ASSERT_RELATION(boost::mpl::math::real_part<n2rn3i>::value, ==, -2);
    MPL_ASSERT_RELATION(boost::mpl::math::imaginary_part<n2rn3i>::value, ==, -3);

    typedef boost::mpl::math::complex_number_c<long,5,6>
            p5rp6i;

    MPL_ASSERT_RELATION(boost::mpl::math::real_part<p5rp6i>::value, ==, 5);
    MPL_ASSERT_RELATION(boost::mpl::math::imaginary_part<p5rp6i>::value, ==, 6);

    typedef boost::mpl::plus<p5rp6i,p2rp3i>::type
            p7rp9i;

    MPL_ASSERT_RELATION(boost::mpl::math::real_part<p7rp9i>::value, ==, 7);
    MPL_ASSERT_RELATION(boost::mpl::math::imaginary_part<p7rp9i>::value, ==, 9);

    typedef boost::mpl::minus<p5rp6i,p2rp3i>::type
            p3rp3i;

    MPL_ASSERT_RELATION(boost::mpl::math::real_part<p3rp3i>::value, ==, 3);
    MPL_ASSERT_RELATION(boost::mpl::math::imaginary_part<p3rp3i>::value, ==, 3);

    typedef boost::mpl::times<p5rp6i,p2rp3i>::type
            n8rp27i;

    MPL_ASSERT_RELATION(
        boost::mpl::math::real_part<n8rp27i>::value, ==, -8
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::imaginary_part<n8rp27i>::value, ==, 27
    );

    typedef boost::mpl::divides<n8rp27i,p2rp3i>::type
            c2tc1dc1;

    MPL_ASSERT((equal_to<c2tc1dc1,p5rp6i>));

    typedef boost::mpl::math::complex_number<
                boost::mpl::math::mixed_number_c<1,1,3>
              , boost::mpl::math::mixed_number_c<3,1,4>
            >
            p1a1o3rp3a1o4i;
    typedef boost::mpl::divides<p1a1o3rp3a1o4i,n2rn3i>::type
            n149o156rn5o26i;

    MPL_ASSERT((
        boost::mpl::math::is_negative<
            boost::mpl::math::real_part<n149o156rn5o26i>
        >
    ));
    MPL_ASSERT((
        boost::mpl::math::is_zero<
            boost::mpl::math::integral_part<
                boost::mpl::math::real_part<n149o156rn5o26i>
            >
        >
    ));
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<
                boost::mpl::math::real_part<n149o156rn5o26i>
            >
        >::value, ==, -149
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<
                boost::mpl::math::real_part<n149o156rn5o26i>
            >
        >::value, ==, 156
    );
    MPL_ASSERT((
        boost::mpl::math::is_negative<
            boost::mpl::math::imaginary_part<n149o156rn5o26i>
        >
    ));
    MPL_ASSERT((
        boost::mpl::math::is_zero<
            boost::mpl::math::integral_part<
                boost::mpl::math::imaginary_part<n149o156rn5o26i>
            >
        >
    ));
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<
                boost::mpl::math::imaginary_part<n149o156rn5o26i>
            >
        >::value, ==, -5
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<
                boost::mpl::math::imaginary_part<n149o156rn5o26i>
            >
        >::value, ==, 26
    );
}

