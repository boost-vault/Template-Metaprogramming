// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/mpl/math/numeric.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/rational_c.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    typedef boost::mpl::math::rational_c<long,3,4>
            rational_3_4;
    typedef boost::mpl::math::rational_c<int,5,6>
            rational_5_6;

    MPL_ASSERT((
        boost::mpl::less<rational_3_4,rational_5_6>
    ));
    MPL_ASSERT_NOT((
        boost::mpl::greater_equal<rational_3_4,rational_5_6>
    ));
    MPL_ASSERT_NOT((
        boost::mpl::less_equal<negate<rational_3_4>,negate<rational_5_6> >
    ));
    MPL_ASSERT((
        boost::mpl::greater<negate<rational_3_4>,negate<rational_5_6> >
    ));

    typedef boost::mpl::plus<rational_3_4,rational_5_6>::type
            rational_sum;

    MPL_ASSERT_NOT((boost::mpl::math::is_negative<rational_sum>));
    MPL_ASSERT_RELATION(boost::mpl::math::numerator<rational_sum>::value, ==, 19);
    MPL_ASSERT_RELATION(boost::mpl::math::denominator<rational_sum>::value, ==, 12);

    typedef boost::mpl::minus<rational_3_4,rational_5_6>::type
            rational_diff;

    MPL_ASSERT((boost::mpl::math::is_negative<rational_diff>));
    MPL_ASSERT_RELATION(boost::mpl::math::numerator<rational_diff>::value, ==, -1);
    MPL_ASSERT((
        boost::mpl::equal_to<
            boost::mpl::math::denominator<rational_diff>
          , boost::mpl::math::denominator<rational_sum>
        >
    ));

    typedef boost::mpl::math::rational_c<int,-3,2>
            rational_n_3_2;

    MPL_ASSERT((
        boost::mpl::equal_to<
            boost::mpl::plus<rational_sum,rational_diff>
          , boost::mpl::negate<rational_n_3_2>
        >
    ));

    typedef boost::mpl::negate<
                boost::mpl::minus<
                    boost::mpl::plus<rational_3_4,rational_5_6>
                  , rational_3_4
                >
            >::type
            rational_n_5_6;

    MPL_ASSERT((boost::mpl::math::is_negative<rational_n_5_6>));
    MPL_ASSERT_RELATION(boost::mpl::math::numerator<rational_n_5_6>::value, ==, -5);
    MPL_ASSERT_RELATION(boost::mpl::math::denominator<rational_n_5_6>::value, ==, 6);

    typedef boost::mpl::math::rational_c<long,8,-9>
            rational_n_8_9;

    MPL_ASSERT((
        boost::mpl::less<rational_n_3_2,rational_n_8_9>
    ));
    MPL_ASSERT_NOT((
        boost::mpl::greater_equal<rational_n_3_2,rational_n_8_9>
    ));
    MPL_ASSERT_NOT((
        boost::mpl::less_equal<
            boost::mpl::negate<rational_n_3_2>
          , boost::mpl::negate<rational_n_8_9>
        >
    ));
    MPL_ASSERT((
        boost::mpl::greater<
            boost::mpl::negate<rational_n_3_2>
          , boost::mpl::negate<rational_n_8_9>
        >
    ));

    typedef boost::mpl::times<rational_n_3_2,rational_n_8_9>::type
            rational_product;

    MPL_ASSERT_NOT((boost::mpl::math::is_negative<rational_product>));
    MPL_ASSERT_RELATION(boost::mpl::math::numerator<rational_product>::value, ==, 4);
    MPL_ASSERT_RELATION(boost::mpl::math::denominator<rational_product>::value, ==, 3);

    typedef boost::mpl::divides<boost::mpl::integral_c<int,1>,rational_product>::type
            rational_product_reciprocal;

    MPL_ASSERT((
        boost::mpl::equal_to<
            boost::mpl::math::numerator<rational_product_reciprocal>
          , boost::mpl::math::denominator<rational_product>
        >
    ));
    MPL_ASSERT((
        boost::mpl::equal_to<
            boost::mpl::math::denominator<rational_product_reciprocal>
          , boost::mpl::math::numerator<rational_product>
        >
    ));
    MPL_ASSERT_NOT((
        boost::mpl::not_equal_to<rational_product_reciprocal,rational_3_4>
    ));

    typedef boost::mpl::math::rational_c<long,0,4>
            rational_zero1;
    typedef boost::mpl::math::rational_c<int,0>
            rational_zero2;

    MPL_ASSERT((
        boost::mpl::equal_to<rational_zero1,rational_zero2>
    ));
}

