// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

/*
 * Based on the boost/libs/math/test/common_factor_test.cpp file.
 */

#include <boost/mpl/int.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/math/integral_gcd.hpp>
#include <boost/mpl/math/integral_lcm.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    MPL_ASSERT((equal_to<int_<1>,math::integral_gcd<unsigned int,1,1> >));
    MPL_ASSERT((equal_to<int_<0>,math::integral_gcd<unsigned int,0,0> >));
    MPL_ASSERT((equal_to<int_<7>,math::integral_gcd<unsigned int,7,0> >));
    MPL_ASSERT((equal_to<int_<9>,math::integral_gcd<unsigned int,0,9> >));
    MPL_ASSERT((equal_to<int_<6>,math::integral_gcd<unsigned int,42,30> >));
    MPL_ASSERT((equal_to<int_<1>,math::integral_gcd<int,3,-7> >));
    MPL_ASSERT((equal_to<int_<1>,math::integral_gcd<int,-8,-9> >));
    MPL_ASSERT((equal_to<int_<7>,math::integral_gcd<int,7,49> >));
    MPL_ASSERT((equal_to<int_<1>,math::integral_lcm<unsigned int,1,1> >));
    MPL_ASSERT((equal_to<int_<0>,math::integral_lcm<unsigned int,0,0> >));
    MPL_ASSERT((equal_to<int_<0>,math::integral_lcm<unsigned int,7,0> >));
    MPL_ASSERT((equal_to<int_<0>,math::integral_lcm<unsigned int,0,9> >));
    MPL_ASSERT((equal_to<int_<90>,math::integral_lcm<unsigned int,18,30> >));
    MPL_ASSERT((equal_to<int_<21>,math::integral_lcm<int,3,7> >));
    MPL_ASSERT((equal_to<int_<72>,math::integral_lcm<int,8,9> >));
    MPL_ASSERT((equal_to<int_<49>,math::integral_lcm<int,7,49> >));
}

