// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/mpl/math/numeric.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/math/reciprocal.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    typedef boost::mpl::math::mixed_number_c<1,1,3>
            p1n1d3;
    typedef boost::mpl::math::mixed_number_c<3,1,4>
            p3n1d4;

    MPL_ASSERT((boost::mpl::less<p1n1d3,p3n1d4>));
    MPL_ASSERT_NOT((boost::mpl::equal_to<p1n1d3,p3n1d4>));
    MPL_ASSERT_NOT((boost::mpl::greater<p1n1d3,p3n1d4>));

    typedef boost::mpl::integral_c<int,-2>
            n2;

    MPL_ASSERT((boost::mpl::less<n2,p1n1d3>));
    MPL_ASSERT_NOT((boost::mpl::equal_to<n2,p1n1d3>));
    MPL_ASSERT_NOT((boost::mpl::greater<n2,p1n1d3>));

    typedef boost::mpl::integral_c<long,-3>
            n3;
    typedef boost::mpl::negate<n3>::type
            p3;

    MPL_ASSERT((less<p1n1d3,p3>));
    MPL_ASSERT_NOT((equal_to<p1n1d3,p3>));
    MPL_ASSERT_NOT((greater<p1n1d3,p3>));

    typedef boost::mpl::times<p1n1d3,n2>::type
            prod_r1_r2;

    MPL_ASSERT((boost::mpl::math::is_negative<prod_r1_r2>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<prod_r1_r2>::value, ==, -2
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<prod_r1_r2>
        >::value, ==, -2
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<prod_r1_r2>
        >::value, ==, 3
    );

    typedef boost::mpl::times<p3n1d4,n3>::type
            prod_i1_i2;

    MPL_ASSERT((boost::mpl::math::is_negative<prod_i1_i2>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<prod_i1_i2>::value, ==, -9
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<prod_i1_i2>
        >::value, ==, -3
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<prod_i1_i2>
        >::value, ==, 4
    );

    typedef boost::mpl::plus<prod_r1_r2,prod_i1_i2>::type
            sum_r12_i12;

    MPL_ASSERT((boost::mpl::math::is_negative<sum_r12_i12>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<sum_r12_i12>::value, ==, -12
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<sum_r12_i12>
        >::value, ==, -5
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<sum_r12_i12>
        >::value, ==, 12
    );

    typedef boost::mpl::times<p3n1d4,n2>::type
            prod_i1_r2;

    MPL_ASSERT((boost::mpl::math::is_negative<prod_i1_r2>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<prod_i1_r2>::value, ==, -6
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<prod_i1_r2>
        >::value, ==, -1
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<prod_i1_r2>
        >::value, ==, 2
    );

    typedef boost::mpl::times<p1n1d3,n3>::type
            prod_r1_i2;

    MPL_ASSERT((boost::mpl::math::is_negative<prod_r1_i2>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<prod_r1_i2>::value, ==, -4
    );
    MPL_ASSERT((
        boost::mpl::math::is_zero<
            boost::mpl::math::fractional_part<prod_r1_i2>
        >
    ));

    typedef boost::mpl::minus<prod_i1_r2,prod_r1_i2>::type
            diff_i1r2_r1i2;

    MPL_ASSERT((boost::mpl::math::is_negative<diff_i1r2_r1i2>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<diff_i1r2_r1i2>::value, ==, -2
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<diff_i1r2_r1i2>
        >::value, ==, -1
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<diff_i1r2_r1i2>
        >::value, ==, 2
    );

    typedef boost::mpl::times<n2,n2>::type
            prod_r2_r2;
    typedef boost::mpl::times<n3,n3>::type
            prod_i2_i2;
    typedef boost::mpl::plus<prod_r2_r2,prod_i2_i2>::type
            sum_r22_i22;

    MPL_ASSERT_NOT((boost::mpl::math::is_negative<sum_r22_i22>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<sum_r22_i22>::value, ==, 13
    );
    MPL_ASSERT((
        boost::mpl::math::is_zero<
            boost::mpl::math::fractional_part<sum_r22_i22>
        >
    ));

    typedef boost::mpl::divides<sum_r12_i12,sum_r22_i22>::type
            quot_1;

    MPL_ASSERT((boost::mpl::math::is_negative<quot_1>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<quot_1>::value, ==, 0
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<quot_1>
        >::value, ==, -149
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<quot_1>
        >::value, ==, 156
    );

    typedef boost::mpl::divides<diff_i1r2_r1i2,sum_r22_i22>::type
            quot_2;

    MPL_ASSERT((boost::mpl::math::is_negative<quot_2>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<quot_2>::value, ==, 0
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<quot_2>
        >::value, ==, -5
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<quot_2>
        >::value, ==, 26
    );

    typedef boost::mpl::math::mixed_number_c<0,-1,12>
            negative_one_twelfth;
    typedef boost::mpl::math::reciprocal<negative_one_twelfth>
            negative_twelve;

    MPL_ASSERT((
        boost::mpl::equal_to<
            boost::mpl::math::denominator<
                boost::mpl::math::fractional_part<negative_one_twelfth>
            >
          , boost::mpl::negate<
                boost::mpl::math::integral_part<negative_twelve>
            >
        >
    ));
    MPL_ASSERT((
        boost::mpl::equal_to<
            boost::mpl::math::integral_part<negative_one_twelfth>
          , boost::mpl::math::numerator<
                boost::mpl::math::fractional_part<negative_twelve>
            >
        >
    ));

    typedef boost::mpl::math::mixed_number_c<-1,0,3>
            negative_one;
    typedef boost::mpl::math::reciprocal<negative_one>
            negative_one_reciprocal;

    MPL_ASSERT((boost::mpl::equal_to<negative_one_reciprocal,negative_one>));
}

