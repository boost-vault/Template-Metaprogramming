// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

/*
 * Based on the boost/libs/math/test/common_factor_test.cpp file.
 */

#include <boost/mpl/int.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/math/gcd.hpp>
#include <boost/mpl/math/lcm.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    MPL_ASSERT((equal_to<int_<1>,math::gcd<int_<1>,int_<1> > >));
    MPL_ASSERT((equal_to<int_<0>,math::gcd<int_<0>,int_<0> > >));
    MPL_ASSERT((equal_to<int_<7>,math::gcd<int_<7>,int_<0> > >));
    MPL_ASSERT((equal_to<int_<9>,math::gcd<int_<0>,int_<9> > >));
    MPL_ASSERT((equal_to<int_<6>,math::gcd<int_<42>,int_<30> > >));
    MPL_ASSERT((equal_to<int_<1>,math::gcd<int_<3>,int_<7> > >));
    MPL_ASSERT((equal_to<int_<1>,math::gcd<int_<8>,int_<9> > >));
    MPL_ASSERT((equal_to<int_<7>,math::gcd<int_<7>,int_<49> > >));
    MPL_ASSERT((equal_to<int_<1>,math::lcm<int_<1>,int_<1> > >));
    MPL_ASSERT((equal_to<int_<0>,math::lcm<int_<0>,int_<0> > >));
    MPL_ASSERT((equal_to<int_<0>,math::lcm<int_<7>,int_<0> > >));
    MPL_ASSERT((equal_to<int_<0>,math::lcm<int_<0>,int_<9> > >));
    MPL_ASSERT((equal_to<int_<90>,math::lcm<int_<18>,int_<30> > >));
    MPL_ASSERT((equal_to<int_<21>,math::lcm<int_<3>,int_<7> > >));
    MPL_ASSERT((equal_to<int_<72>,math::lcm<int_<8>,int_<9> > >));
    MPL_ASSERT((equal_to<int_<49>,math::lcm<int_<7>,int_<49> > >));
}

