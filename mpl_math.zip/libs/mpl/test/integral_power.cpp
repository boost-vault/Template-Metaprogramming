// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/mpl/int.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/math/is_negative.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>
#include <boost/mpl/math/integral_part.hpp>
#include <boost/mpl/math/fractional_part.hpp>
#include <boost/mpl/math/integral_power.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    typedef boost::mpl::math::integral_power<
                boost::mpl::math::mixed_number_c<-7,0,1>
              , boost::mpl::int_<5>
            >::type
            n16807;

    MPL_ASSERT((boost::mpl::math::is_negative<n16807>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<n16807>::value, ==, -16807
    );
    MPL_ASSERT((
        boost::mpl::math::is_zero<boost::mpl::math::fractional_part<n16807> >
    ));

    typedef boost::mpl::math::integral_power<
                boost::mpl::math::mixed_number_c<5,0,1>
              , boost::mpl::int_<-3>
            >::type
            p1_125;

    MPL_ASSERT_NOT((boost::mpl::math::is_negative<p1_125>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<p1_125>::value, ==, 0
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<p1_125>
        >::value, ==, 1
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<p1_125>
        >::value, ==, 125
    );
}

