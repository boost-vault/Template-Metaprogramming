// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/mpl/is_numeric_constant.hpp>
#include <boost/mpl/math/numeric.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/double.hpp>
#include <boost/mpl/math/rational_c.hpp>
#include <boost/mpl/math/mixed_number_c.hpp>
#include <boost/mpl/vector.hpp>
#include <boost/mpl/vector_c.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    typedef boost::mpl::integral_c<int,42>
            secret_of_life;

    MPL_ASSERT((boost::mpl::is_numeric_constant<secret_of_life>));
    MPL_ASSERT_NOT((boost::mpl::math::is_negative<secret_of_life>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<secret_of_life>::value, ==, 42
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<secret_of_life>::value, ==, 1
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<secret_of_life>::value, ==, 42
    );
    MPL_ASSERT((
        boost::mpl::math::is_zero<
            boost::mpl::math::fractional_part<secret_of_life>
        >
    ));

    typedef boost::mpl::math::rational_c<int,-3,2>
            negative_three_halves;

    MPL_ASSERT((boost::mpl::is_numeric_constant<negative_three_halves>));
    MPL_ASSERT((boost::mpl::math::is_negative<negative_three_halves>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<negative_three_halves>::value, ==, -3
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<negative_three_halves>::value, ==, 2
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<negative_three_halves>::value, ==, -1
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<negative_three_halves>
        >::value, ==, -1
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<negative_three_halves>
        >::value, ==, 2
    );

    typedef boost::mpl::math::mixed_number_c<4,5,8>
            shoe_size;

    MPL_ASSERT((boost::mpl::is_numeric_constant<shoe_size>));
    MPL_ASSERT_NOT((boost::mpl::math::is_negative<shoe_size>));
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<shoe_size>::value, ==, 37
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<shoe_size>::value, ==, 8
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::integral_part<shoe_size>::value, ==, 4
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::numerator<
            boost::mpl::math::fractional_part<shoe_size>
        >::value, ==, 5
    );
    MPL_ASSERT_RELATION(
        boost::mpl::math::denominator<
            boost::mpl::math::fractional_part<shoe_size>
        >::value, ==, 8
    );

    typedef boost::mpl::math::string_c_to_double<4,'.',6,2,5>
            shoe_size_d;

    MPL_ASSERT((boost::mpl::is_numeric_constant<shoe_size_d>));
    MPL_ASSERT((boost::mpl::equal_to<shoe_size,shoe_size_d>));
    MPL_ASSERT_NOT((
        boost::mpl::is_numeric_constant<
            boost::mpl::vector<
                secret_of_life
              , negative_three_halves
              , shoe_size
              , shoe_size_d
            >
        >
    ));
    MPL_ASSERT_NOT((
        boost::mpl::is_numeric_constant<
            boost::mpl::vector_c<int,0,1,2,3,4,5,6,7,8,9>
        >
    ));
}

