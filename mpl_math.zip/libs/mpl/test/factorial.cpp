// Copyright (C) 2005-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/mpl/int.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/math/factorial.hpp>
#include <boost/mpl/aux_/test.hpp>

MPL_TEST_CASE()
{
    MPL_ASSERT((equal_to<math::factorial<int_<0> >,int_<1> >));
    MPL_ASSERT((equal_to<math::factorial<int_<1> >,int_<1> >));
    MPL_ASSERT((equal_to<math::factorial<int_<2> >,int_<2> >));
    MPL_ASSERT((equal_to<math::factorial<int_<3> >,int_<6> >));
    MPL_ASSERT((equal_to<math::factorial<int_<4> >,int_<24> >));
    MPL_ASSERT((equal_to<math::factorial<int_<5> >,int_<120> >));
    MPL_ASSERT((equal_to<math::factorial<int_<6> >,int_<720> >));
    MPL_ASSERT((equal_to<math::factorial<int_<7> >,int_<5040> >));
    MPL_ASSERT((equal_to<math::factorial<int_<8> >,int_<40320> >));
    MPL_ASSERT((equal_to<math::factorial<int_<9> >,int_<362880> >));
    MPL_ASSERT((equal_to<math::factorial<int_<10> >,int_<3628800> >));
}

