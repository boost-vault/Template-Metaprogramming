//          Copyright (C) 2010 Hal Finkel.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <limits>
#include <iostream>
#include <iomanip>

#include <boost/mpl/cf.hpp>
#include <boost/mpl/cf/constants.hpp>
#include <boost/mpl/for_each.hpp>

using namespace std;
using namespace boost::mpl;
using namespace boost::mpl::cf_constants;

struct value_printer
{
	template< typename U > void operator()(U x)
	{
		cout << " " << U::value;
	}
};

template <typename T, typename V>
static void printv()
{
	cout << setprecision(numeric_limits<T>::digits10);
	T v = V::template value<T>();
	cout << v << endl;
};

template <typename V>
static void print(const char *name)
{
	cout << name << " = [";
	boost::mpl::for_each< V >( value_printer() ); cout << "]" << endl;

	printv<float, V>();
	printv<double, V>();
	printv<long double, V>();
	cout << endl;
};

static void printer()
{
	print< pi >("pi");
	print< boost::mpl::plus< one, one >::type >("one + one");
	print< boost::mpl::plus< one, pi >::type >("one + pi");
	print< boost::mpl::minus< one, pi >::type >("one - pi");
	print< boost::mpl::plus< cf_c<1, 2>, cf_c<0, 4> >::type >("3/2 + 1/4");
	print< boost::mpl::plus< cf_c<0, 7>, cf_c<0, 15> >::type >("1/7 + 1/15");
	print< boost::mpl::plus< pi, pi >::type >("pi + pi");
	print< boost::mpl::times< int_<2>, pi >::type >("2*pi");
	print< boost::mpl::divides< pi, pi >::type >("pi/pi");
	print< boost::mpl::negate< pi >::type >("-pi");
	print< boost::mpl::plus< int_<4>, boost::mpl::negate< pi >::type >::type >("4 + -pi");
	print< infinity >("infinity");

	// should not compile:
	//print< cf_c<1, -2> >("oops");
	//print< cf_c<1, 1, 0> >("oops");

	cout << "pi == pi: " << boost::mpl::equal_to< pi, pi >::value << endl;
	cout << "pi != pi: " << boost::mpl::not_equal_to< pi, pi >::value << endl;
	cout << "2 == [1 1]: " << boost::mpl::equal_to< cf_c<2>, cf_c<1, 1> >::value << endl;
	cout << "-2 != [-1 -1]: " << boost::mpl::not_equal_to< cf_c<-2>, cf_c<-1, -1> >::value << endl;
	cout << "one == 2: " << boost::mpl::equal_to< one, cf_c<2> >::value << endl;
}

int main()
{
	printer();
	return 0;
}

