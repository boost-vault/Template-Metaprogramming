//          Copyright (C) 2010 Hal Finkel.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <limits>
#include <iostream>
#include <iomanip>
#include <cmath>

#include <boost/mpl/cf.hpp>
#include <boost/mpl/cf/constants.hpp>
#include <boost/mpl/cf/trig.hpp>
#include <boost/mpl/for_each.hpp>

using namespace std;
using namespace boost::mpl;
using namespace boost::mpl::cf_constants;

struct value_printer
{
	template< typename U > void operator()(U x)
	{
		cout << " " << U::value;
	}
};

template <typename T, typename V>
static void printv()
{
	cout << setprecision(numeric_limits<T>::digits10);
	T v = V::template value<T>();
	cout << v << endl;
};

template <typename V>
static void print(const char *name)
{
	cout << name << " = [";
	boost::mpl::for_each< V >( value_printer() ); cout << "]" << endl;

	printv<float, V>();
	printv<double, V>();
	printv<long double, V>();
	cout << endl;
};

static void printer()
{
	print< boost::mpl::sin< cf_c<3> >::type >("sin(3)");
	cout << std::sin(3.0l) << endl;
	print< boost::mpl::cos< cf_c<3> >::type >("cos(3)");
	cout << std::cos(3.0l) << endl;
}

int main()
{
	printer();
	return 0;
}

