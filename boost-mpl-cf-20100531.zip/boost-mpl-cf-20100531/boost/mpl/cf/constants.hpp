// Copyright (C) 2010 Hal Finkel
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_CF_CONSTANTS_HPP
#define BOOST_MPL_CF_CONSTANTS_HPP

#include <boost/mpl/limits/cf.hpp>
#include <boost/mpl/cf_c.hpp>

#include <boost/preprocessor/seq/enum.hpp>
#include <boost/preprocessor/seq/first_n.hpp>

namespace boost { namespace mpl {
namespace cf_constants {
struct zero : cf_c<0> {};
struct one  : cf_c<1> {};
struct half : cf_c<0, 2> {};
struct infinity : cf0<> {};

struct e            : cf_c<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_FIRST_N(BOOST_MPL_LIMIT_CF_SIZE,
		(2)(1)(2)(1)(1)(4)(1)(1)(6)(1)(1)(8)(1)(1)(10)(1)(1)(12)(1)(1)))> {};
struct pi           : cf_c<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_FIRST_N(BOOST_MPL_LIMIT_CF_SIZE,
		(3)(7)(15)(1)(292)(1)(1)(1)(2)(1)(3)(1)(14)(2)(1)(1)(2)(2)(2)(2)))> {};
struct root_two     : cf_c<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_FIRST_N(BOOST_MPL_LIMIT_CF_SIZE,
		(1)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)(2)))> {};
struct golden_ratio : cf_c<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_FIRST_N(BOOST_MPL_LIMIT_CF_SIZE,
		(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)))> {};
struct tan_one      : cf_c<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_FIRST_N(BOOST_MPL_LIMIT_CF_SIZE,
		(1)(1)(1)(3)(1)(5)(1)(7)(1)(9)(1)(11)(1)(13)(1)(15)(1)(17)(1)(19)))> {};
} // namespace cf_constants
}}

#endif // BOOST_MPL_CF_CONSTANTS_HPP

