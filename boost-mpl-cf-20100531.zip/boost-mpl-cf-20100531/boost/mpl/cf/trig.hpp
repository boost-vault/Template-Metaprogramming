// Copyright (C) 2010 Hal Finkel
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_CF_TRIG_HPP
#define BOOST_MPL_CF_TRIG_HPP

#include <boost/mpl/limits/cf.hpp>
#include <boost/mpl/cf.hpp>
#include <boost/mpl/cf_c.hpp>
#include <boost/mpl/cf/constants.hpp>

#include <boost/preprocessor/seq/enum.hpp>
#include <boost/preprocessor/seq/first_n.hpp>

namespace boost { namespace mpl {
// The series evaluation algorithm is from (Algorithm 1 in the paper):
// Convergence Acceleration of Alternating Series.
//      Henri Cohen, Fernando Rodriguez Villegas, and Don Zagier.
//      Experimental Mathematics. 9 (1). 2000.

namespace aux { namespace cf {
template< template< typename, typename, typename > class A, typename X, typename X2, typename N, typename K >
struct alternating_series_inner
{
	typedef typename minus<cf_c<1>, typename times<
		typename A< X, X2, K >::type,
		typename alternating_series_inner< A, X, X2, N, typename next<K>::type >::type
	>::type>::type type;
};

template< template< typename, typename, typename > class A, typename X, typename X2, typename N >
struct alternating_series_inner<A, X, X2, N, integral_c<cf_element_value_type, 0> >
{
	typedef typename times<
		typename A< X, X2, integral_c<cf_element_value_type, 0> >::type,
		typename alternating_series_inner< A, X, X2, N, integral_c<cf_element_value_type, 1> >::type
	>::type type;
};

template< template< typename, typename, typename > class A, typename X, typename X2, typename N >
struct alternating_series_inner<A, X, X2, N, N >
{
	typedef cf_c<1> type;
};

template< template< typename, typename, typename > class A, typename X, typename N >
struct alternating_series
{
	typedef typename alternating_series_inner< A, X, typename times<X, X>::type, N, integral_c<cf_element_value_type, 0> >::type type;
};

template< typename X, typename X2, typename K >
struct sin_term
{
	typedef typename times<integral_c<cf_element_value_type, 2>, K>::type two_k;

	typedef typename divides<X2,
		cf1<typename times<
			two_k,
			typename plus< two_k, integral_c<cf_element_value_type, 1> >::type
		>::type>
	>::type type;
};

template< typename X, typename X2 >
struct sin_term< X, X2, integral_c<cf_element_value_type, 0> >
{
	typedef X type;
};

template< typename X, typename X2, typename K >
struct cos_term
{
	typedef typename times<integral_c<cf_element_value_type, 2>, K>::type two_k;

	typedef typename divides<X2,
		cf1<typename times<
			typename minus< two_k, integral_c<cf_element_value_type, 1> >::type,
			two_k
		>::type>
	>::type type;
};

template< typename X, typename X2 >
struct cos_term< X, X2, integral_c<cf_element_value_type, 0> >
{
	typedef cf_c<1> type;
};

template< typename X, typename N >
struct sin
{
	typedef typename alternating_series<sin_term, X, N>::type type;
};

template< typename X, typename N >
struct cos
{
	typedef typename alternating_series<cos_term, X, N>::type type;
};

template< typename SX, typename SX2 >
struct sin_5x_inner3
{
	// sin(5x) = 16 * sin^5 (x)  -  20 * sin^3 (x)  +  5 * sin(x)
	// sin(5x) = sin(x) (5 - sin^2 (x) (20  - 16 * sin^2 (x) ))

	typedef typename times<SX,
		typename minus<cf_c<5>,
			typename times<SX2,
				typename minus<cf_c<20>,
					typename times<cf_c<16>, SX2>::type
				>::type
			>::type
		>::type
	>::type type;
};

template< typename SX >
struct sin_5x_inner2
{
	typedef typename sin_5x_inner3<SX, typename times<SX, SX>::type>::type type;
};

template< typename X, typename N >
struct sin_5x_inner
{
	typedef typename sin_5x_inner2<typename sin<X, N>::type>::type type;
};

template< typename X, typename N >
struct sin_5x
{
	typedef typename sin_5x_inner<typename divides< X, cf_c<5> >::type, N>::type type;
};

template< typename CX2 >
struct cos_4x_inner3
{
	// cos(4x) = 8 * ( cos^4 (x)  -  cos^2 (x) )  +  1
	// cos(4x) = 8 * cos^2 (x) * (cos^2(x) - 1) + 1

	typedef typename plus<cf_c<1>,
		typename times<cf_c<8>,
			typename times<CX2,
				typename minus< CX2, cf_c<1> >::type
			>::type
		>::type
	>::type type;
};

template< typename CX >
struct cos_4x_inner2
{
	typedef typename cos_4x_inner3<typename times<CX, CX>::type>::type type;
};

template< typename X, typename N >
struct cos_4x_inner
{
	typedef typename cos_4x_inner2<typename cos<X, N>::type>::type type;
};

template< typename X, typename N >
struct cos_4x
{
	typedef typename cos_4x_inner<typename divides< X, cf_c<4> >::type, N>::type type;
};

}}

template< typename X, typename N = integral_c<cf_element_value_type, 8> >
struct sin
{
	typedef typename aux::cf::sin_5x<X, N>::type type;
};

template< typename X, typename N = integral_c<cf_element_value_type, 8> >
struct cos
{
	typedef typename aux::cf::cos_4x<X, N>::type type;
};

}}

#endif // BOOST_MPL_CF_TRIG_HPP

