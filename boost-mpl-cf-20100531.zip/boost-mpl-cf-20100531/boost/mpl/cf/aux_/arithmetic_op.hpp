
#ifndef BOOST_MPL_CF_AUX_ARITHMETIC_OP_HPP_INCLUDED
#define BOOST_MPL_CF_AUX_ARITHMETIC_OP_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2000-2004
// Copyright Hal Finkel 2010
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: clear.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/logical.hpp>
#include <boost/mpl/min_max.hpp>
#include <boost/mpl/pop_front.hpp>
#include <boost/mpl/push_back.hpp>
#include <boost/mpl/empty.hpp>
#include <boost/mpl/clear.hpp>
#include <boost/mpl/front.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/cf/aux_/cf0.hpp>
#include <boost/mpl/cf/aux_/tag.hpp>
#include <boost/mpl/cf/aux_/sign.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/size_t.hpp>

#include <boost/config.hpp>
#include <boost/static_assert.hpp>
#include <boost/utility/enable_if.hpp>

#include <limits>

namespace boost { namespace mpl {
namespace aux { namespace cf {

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

// This an implementation of Gosper's algorithm, except that
// all types are precomputed to, at most, BOOST_MPL_LIMIT_CF_SIZE values.
// See: http://perl.plover.com/yak/cftalk/

struct arithmetic_op_tag {};

template< typename X, typename Y,
	typename A, typename B, typename C, typename D,
	typename E, typename F, typename G, typename H,
	typename R = cf0<>, typename HadOverflow = false_  >
struct arithmetic_op
{
	typedef A a;
	typedef B b;
	typedef C c;
	typedef D d;
	typedef E e;
	typedef F f;
	typedef G g;
	typedef H h;

	typedef X x;
	typedef Y y;

	typedef R r;
	typedef HadOverflow had_overflow;

	typedef arithmetic_op_tag tag;
	typedef arithmetic_op type;
};

typedef integral_c<cf_element_value_type, cf_element_value_max > element_max;

typedef integral_c<cf_element_value_type, 1> one;
typedef integral_c<cf_element_value_type, 0> zero;
typedef integral_c<cf_element_value_type, -1> minus_one;

template< typename X, typename Y, typename Enable = void >
struct minus_or_void_inner
{
	typedef typename minus<X, Y>::type type;
};

template< typename X, typename Y >
struct minus_or_void_inner< X, Y, typename enable_if<
		and_<
			not_< same_sign< X, Y > >,
			greater<
				typename abs< Y >::type,
				typename minus< element_max, typename abs< X >::type >::type
			>
		>
	>::type >
{
	typedef void_ type;
};

template< typename X, typename Y, typename Enable = void >
struct minus_or_void_
{
	typedef typename minus_or_void_inner<X, Y>::type type;
};

template< typename X, typename Y >
struct minus_or_void_< X, Y, typename enable_if<
		or_<
			is_void_< X >,
			is_void_< Y >
		>
	>::type >
{
	typedef void_ type;
};

template< typename X, typename Y, typename Enable = void >
struct plus_or_void_inner
{
	typedef typename plus<X, Y>::type type;
};

template< typename X, typename Y >
struct plus_or_void_inner< X, Y, typename enable_if<
		and_<
			same_sign< X, Y >,
			greater<
				typename abs< Y >::type,
				typename minus< element_max, typename abs< X >::type >::type
			>
		>
	>::type >
{
	typedef void_ type;
};

template< typename X, typename Y, typename Enable = void >
struct plus_or_void_
{
	typedef typename plus_or_void_inner<X, Y>::type type;
};

template< typename X, typename Y >
struct plus_or_void_< X, Y, typename enable_if<
		or_<
			is_void_< X >,
			is_void_< Y >
		>
	>::type >
{
	typedef void_ type;
};

template< typename X, typename Y, typename Enable = void >
struct times_or_void_inner2
{
	typedef typename times<X, Y>::type type;
};

template< typename X, typename Y >
struct times_or_void_inner2< X, Y, typename enable_if<
		greater<
			typename next< typename abs< Y >::type >::type,
			typename divides< element_max, typename abs< X >::type >::type
		>
	>::type >
{
	typedef void_ type;
};

template< typename X, typename Y, typename Enable = void >
struct times_or_void_inner
{
	typedef typename times_or_void_inner2<X, Y>::type type;
};

template< typename X, typename Y >
struct times_or_void_inner< X, Y, typename enable_if<
		or_<
			is_zero< X >,
			is_zero< Y >
		>
	>::type >
{
	typedef zero type;
};

template< typename X, typename Y, typename Enable = void >
struct times_or_void_
{
	typedef typename times_or_void_inner<X, Y>::type type;
};

template< typename X, typename Y >
struct times_or_void_< X, Y, typename enable_if<
		or_<
			is_void_< X >,
			is_void_< Y >
		>
	>::type >
{
	typedef void_ type;
};

template< typename IV >
struct any_values_are_void_ : or_<
	or_<
		is_void_< typename IV::a >, is_void_< typename IV::b >,
		is_void_< typename IV::c >, is_void_< typename IV::d >
	>,
	or_<
		is_void_< typename IV::e >, is_void_< typename IV::f >,
		is_void_< typename IV::g >, is_void_< typename IV::h >
	> > {};

template< typename AO, typename Q >
struct egest_values
{
	typedef typename AO::e a;
	typedef typename AO::f b;
	typedef typename AO::g c;
	typedef typename AO::h d;

	typedef typename minus_or_void_<
		typename AO::a,
		typename times_or_void_< Q, typename AO::e >::type
	>::type e;

	typedef typename minus_or_void_<
		typename AO::b,
		typename times_or_void_< Q, typename AO::f >::type
	>::type f;

	typedef typename minus_or_void_<
		typename AO::c,
		typename times_or_void_< Q, typename AO::g >::type
	>::type g;

	typedef typename minus_or_void_<
		typename AO::d,
		typename times_or_void_< Q, typename AO::h >::type
	>::type h;
};

template< typename AO, typename Q, typename Enable = void >
struct egest
{
	typedef egest_values< AO, Q > ev;
	typedef arithmetic_op< typename AO::x, typename AO::y,
		typename ev::a, typename ev::b, typename ev::c, typename ev::d,
		typename ev::e, typename ev::f, typename ev::g, typename ev::h,
		typename push_back< typename AO::r, Q >::type, typename AO::had_overflow > type;
};

template< typename AO, typename Q >
struct egest< AO, Q, typename enable_if<
		and_<
			not_< is_void_< Q > >,
			or_<
				typename AO::had_overflow,
				any_values_are_void_< egest_values< AO, Q > >
			>
		>
	>::type >
{
	typedef arithmetic_op< typename AO::x, typename AO::y,
		typename AO::e, typename AO::f, typename AO::g, typename AO::h,
		zero, zero, zero, zero,
		typename push_back< typename AO::r, Q >::type, true_ > type;

};

template< typename AO, typename Q >
struct egest< AO, Q, typename enable_if<
		is_void_< Q >
	>::type >
{
	typedef void_ type;
};

template< typename AO >
struct ingest_x_values
{
	typedef typename plus_or_void_<
		typename AO::c,
		typename times_or_void_< typename front< typename AO::x >::type, typename AO::a >::type
	>::type a;

	typedef typename plus_or_void_<
		typename AO::d,
		typename times_or_void_< typename front< typename AO::x >::type, typename AO::b >::type
	>::type b;

	typedef typename AO::a c;
	typedef typename AO::b d;

	typedef typename plus_or_void_<
		typename AO::g,
		typename times_or_void_< typename front< typename AO::x >::type, typename AO::e >::type
	>::type e;

	typedef typename plus_or_void_<
		typename AO::h,
		typename times_or_void_< typename front< typename AO::x >::type, typename AO::f >::type
	>::type f;

	typedef typename AO::e g;
	typedef typename AO::f h;
};

template< typename AO, typename Enable = void >
struct ingest_x
{
	typedef ingest_x_values< AO > iv;
	typedef arithmetic_op< typename pop_front< typename AO::x >::type, typename AO::y,
		typename iv::a, typename iv::b, typename iv::c, typename iv::d,
		typename iv::e, typename iv::f, typename iv::g, typename iv::h,
		typename AO::r, typename AO::had_overflow > type;
};

template< typename AO >
struct ingest_x < AO, typename enable_if<
		and_<
			not_< empty< typename AO::x > >,
			any_values_are_void_< ingest_x_values< AO > >
		>
	>::type >
{
	typedef arithmetic_op< typename clear< typename AO::x >::type, typename AO::y,
		typename AO::a, typename AO::b, typename AO::a, typename AO::b,
		typename AO::e, typename AO::f, typename AO::e, typename AO::f,
		typename AO::r, true_ > type;
};

template< typename AO >
struct ingest_x < AO, typename enable_if<
		empty< typename AO::x >
	>::type >
{
	typedef arithmetic_op< typename AO::x, typename AO::y,
		typename AO::a, typename AO::b, typename AO::a, typename AO::b,
		typename AO::e, typename AO::f, typename AO::e, typename AO::f,
		typename AO::r, typename AO::had_overflow > type;
};


template< typename AO >
struct ingest_y_values
{
	typedef typename plus_or_void_<
		typename AO::b,
		typename times_or_void_< typename front< typename AO::y >::type, typename AO::a >::type
	>::type a;

	typedef typename AO::a b;

	typedef typename plus_or_void_<
		typename AO::d,
		typename times_or_void_< typename front< typename AO::y >::type, typename AO::c >::type
	>::type c;

	typedef typename AO::c d;

	typedef typename plus_or_void_<
		typename AO::f,
		typename times_or_void_< typename front< typename AO::y >::type, typename AO::e >::type
	>::type e;

	typedef typename AO::e f;

	typedef typename plus_or_void_<
		typename AO::h,
		typename times_or_void_< typename front< typename AO::y >::type, typename AO::g >::type
	>::type g;

	typedef typename AO::g h;
};

template< typename AO, typename Enable = void >
struct ingest_y
{
	typedef ingest_y_values< AO > iv;
	typedef arithmetic_op< typename AO::x, typename pop_front< typename AO::y >::type,
		typename iv::a, typename iv::b, typename iv::c, typename iv::d,
		typename iv::e, typename iv::f, typename iv::g, typename iv::h,
		typename AO::r, typename AO::had_overflow > type;
};

template< typename AO >
struct ingest_y < AO, typename enable_if<
		and_<
			not_< empty< typename AO::y > >,
			any_values_are_void_< ingest_y_values< AO > >
		>
	>::type >
{
	typedef arithmetic_op< typename AO::x, typename clear< typename AO::y >::type,
		typename AO::a, typename AO::a, typename AO::c, typename AO::c,
		typename AO::e, typename AO::e, typename AO::g, typename AO::g,
		typename AO::r, true_ > type;
};

template< typename AO >
struct ingest_y < AO, typename enable_if<
		empty< typename AO::y >
	>::type >
{
	typedef arithmetic_op< typename AO::x, typename AO::y,
		typename AO::a, typename AO::a, typename AO::c, typename AO::c,
		typename AO::e, typename AO::e, typename AO::g, typename AO::g,
		typename AO::r, typename AO::had_overflow > type;
};

// Note: void_ represents infinity here.

template< typename N, typename M, typename Enable = void >
struct abs_minus_or_void_
{
	typedef typename minus<
		typename max< N, M >::type,
		typename min< N, M >::type
	>::type type;
};

template < typename N, typename M >
struct abs_minus_or_void_< N, M, typename enable_if<
		or_< is_void_< N >, is_void_< M > >
	>::type >
{
	typedef typename eval_if<
		and_< is_void_< N >, is_void_< M > >,
		zero, void_ >::type type;
};

template< typename N, typename M, typename Enable = void >
struct max_or_void_
{
	typedef typename max< N, M >::type type;
};

template < typename N, typename M >
struct max_or_void_< N, M, typename enable_if<
		or_< is_void_< N >, is_void_< M > >
	>::type >
{
	typedef void_ type;
};

template< typename N, typename M, typename Enable = void >
struct greater_equal_or_void_
{
	typedef typename greater_equal< N, M >::type type;
};

template < typename N, typename M >
struct greater_equal_or_void_< N, M, typename enable_if<
		or_< is_void_< N >, is_void_< M > >
	>::type >
{
	typedef typename eval_if<
		and_< is_void_< M >, not_ < is_void_< N > > >,
		false_, true_ >::type type;
};

template< typename AERatio, typename BFRatio, typename CGRatio, typename DHRatio >
struct should_ingest_y
{
	typedef typename greater_equal_or_void_<
		typename max_or_void_<
			typename abs_minus_or_void_< AERatio, BFRatio >::type,
			typename abs_minus_or_void_< CGRatio, DHRatio >::type
		>::type,
		typename max_or_void_<
			typename abs_minus_or_void_< AERatio, CGRatio >::type,
			typename abs_minus_or_void_< BFRatio, DHRatio >::type
		>::type
	>::type type;
};

template< typename N, typename D, typename Enable = void >
struct ratio_or_void_
{
	typedef typename divides< N, D >::type type;
};

template < typename N, typename D >
struct ratio_or_void_< N, D, typename enable_if<
		is_zero< D >
	>::type >
{
	typedef void_ type;
};

template< typename AO, typename Enable = void >
struct result
{
	typedef typename ratio_or_void_< typename AO::a, typename AO::e >::type ae_ratio;
	typedef typename ratio_or_void_< typename AO::b, typename AO::f >::type bf_ratio;
	typedef typename ratio_or_void_< typename AO::c, typename AO::g >::type cg_ratio;
	typedef typename ratio_or_void_< typename AO::d, typename AO::h >::type dh_ratio;

	typedef typename eval_if <
		and_<
			is_same< ae_ratio, bf_ratio >,
			is_same< bf_ratio, cg_ratio >,
			is_same< cg_ratio, dh_ratio >
		>, typename egest< AO, ae_ratio >::type,
		typename eval_if<
			typename should_ingest_y< ae_ratio, bf_ratio, cg_ratio, dh_ratio >::type,
			typename ingest_y< AO >::type, typename ingest_x< AO >::type
		>::type
	>::type next_type;

	typedef typename result< next_type >::type type;
};

template< typename AO >
struct result< AO, typename enable_if<
		or_ <
			and_<
				is_zero< typename AO::e >,
				is_zero< typename AO::f >,
				is_zero< typename AO::g >,
				is_zero< typename AO::h >
			>,
			equal_to< size< typename AO::r >, mpl::size_t< BOOST_MPL_LIMIT_CF_SIZE > >
		>
	>::type >
{
	typedef typename AO::r type;
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

} // namespace cf
} // namespace aux

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long N, long M >
struct plus_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: aux::cf::result < aux::cf::arithmetic_op < N1, N2,
		aux::cf::zero, aux::cf::one, aux::cf::one, aux::cf::zero,
		aux::cf::zero, aux::cf::zero, aux::cf::zero, aux::cf::one > >::type {};
};

template< long N, long M >
struct minus_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: aux::cf::result < aux::cf::arithmetic_op < N1, N2,
		aux::cf::zero, aux::cf::one, aux::cf::minus_one, aux::cf::zero,
		aux::cf::zero, aux::cf::zero, aux::cf::zero,  aux::cf::one > >::type {};
};

template< long N, long M >
struct times_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: aux::cf::result < aux::cf::arithmetic_op < N1, N2,
		aux::cf::one, aux::cf::zero, aux::cf::zero, aux::cf::zero,
		aux::cf::zero, aux::cf::zero, aux::cf::zero, aux::cf::one > >::type {};
};

template< long N, long M >
struct divides_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: aux::cf::result < aux::cf::arithmetic_op < N1, N2,
		aux::cf::zero, aux::cf::one, aux::cf::zero, aux::cf::zero,
		aux::cf::zero, aux::cf::zero, aux::cf::one, aux::cf::zero > >::type {};
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
}}

#endif // BOOST_MPL_CF_AUX_ARITHMETIC_OP_HPP_INCLUDED
