
// NO INCLUDE GUARDS, THE HEADER IS INTENDED FOR MULTIPLE INCLUSION

#if defined(BOOST_PP_IS_ITERATING)

// Copyright Aleksey Gurtovoy 2000-2004
// Copyright Hal Finkel 2010
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: numbered_c.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#include <boost/preprocessor/enum_params.hpp>
#include <boost/preprocessor/enum_shifted_params.hpp>
#include <boost/preprocessor/comma_if.hpp>
#include <boost/preprocessor/repeat.hpp>
#include <boost/preprocessor/dec.hpp>
#include <boost/preprocessor/cat.hpp>

#include <boost/mpl/cf/aux_/value.hpp>

#define i_ BOOST_PP_FRAME_ITERATION(1)

#define AUX778076_CF_C_PARAM_FUNC(unused, i_, param) \
    BOOST_PP_COMMA_IF(i_) \
    integral_c<cf_element_value_type,BOOST_PP_CAT(param,i_)> \
    /**/

template< BOOST_PP_ENUM_PARAMS(i_, cf_element_value_type C) >
struct BOOST_PP_CAT(BOOST_PP_CAT(cf,i_),_c)
    : BOOST_PP_CAT(cf,i_)< BOOST_PP_REPEAT(i_,AUX778076_CF_C_PARAM_FUNC,C) >
{
    typedef BOOST_PP_CAT(BOOST_PP_CAT(cf,i_),_c) type;
    typedef cf_element_value_type value_type;

    BOOST_MPL_CF_MAKE_VALUE_ACCESSOR(i_)
};

#undef AUX778076_CF_C_PARAM_FUNC

#undef i_

#endif // BOOST_PP_IS_ITERATING
