
// NO INCLUDE GUARDS, THE HEADER IS INTENDED FOR MULTIPLE INCLUSION

#if defined(BOOST_PP_IS_ITERATING)

// Copyright Aleksey Gurtovoy 2000-2004
// Copyright Hal Finkel 2010
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: numbered.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#include <boost/preprocessor/enum_params.hpp>
#include <boost/preprocessor/enum_shifted_params.hpp>
#include <boost/preprocessor/comma_if.hpp>
#include <boost/preprocessor/control/expr_if.hpp>
#include <boost/preprocessor/control/if.hpp>
#include <boost/preprocessor/repeat.hpp>
#include <boost/preprocessor/dec.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/logical/not.hpp>

#include <boost/mpl/cf/aux_/value.hpp>

#define i_ BOOST_PP_FRAME_ITERATION(1)

#if i_ > 0

template<
      BOOST_PP_ENUM_PARAMS(i_, typename T)
    >
struct BOOST_PP_CAT(cf,i_)
{
    typedef aux::cf_tag<i_> tag;
    typedef BOOST_PP_CAT(cf,i_) type;

#define AUX778076_CF_ITEM(unused, i_, unused2) \
    typedef BOOST_PP_CAT(T,i_) BOOST_PP_CAT(item,i_); \
    /**/

    BOOST_PP_REPEAT(i_, AUX778076_CF_ITEM, unused)
#undef AUX778076_CF_ITEM
    typedef void_ BOOST_PP_CAT(item,i_);
    typedef BOOST_PP_CAT(T,BOOST_PP_DEC(i_)) back;

    // Borland forces us to use 'type' here (instead of the class name)
    typedef v_iter<type,0> begin;
    typedef v_iter<type,i_> end;

    // Static cast to assert that:
    //  - All elements are non-zero (except the first)
    //  - All elements have the same sign (except the first if it is zero)
#if i_ > 1
#define AUX778076_CF_ITEM(unused, i_, unused2) \
    BOOST_PP_EXPR_IF(i_, \
        BOOST_PP_EXPR_IF(BOOST_PP_DEC(i_), && ) \
        ( \
            BOOST_PP_IF(BOOST_PP_NOT(BOOST_PP_DEC(i_)), \
                aux::cf::is_zero< item0 >::value ||, !aux::cf::is_zero< BOOST_PP_CAT(item,i_) >::value &&) \
            aux::cf::same_sign< BOOST_PP_CAT(item,BOOST_PP_DEC(i_)), BOOST_PP_CAT(item,i_) >::value \
        ) \
    ) \
    /**/

    BOOST_STATIC_ASSERT((BOOST_PP_REPEAT(i_, AUX778076_CF_ITEM, unused)));
#undef AUX778076_CF_ITEM
#endif

    BOOST_MPL_CF_MAKE_VALUE_ACCESSOR(i_)
};

template<>
struct push_front_impl< aux::cf_tag<BOOST_PP_DEC(i_)> >
{
    template< typename CF, typename T > struct apply
    {
        typedef BOOST_PP_CAT(cf,i_)<
              T
              BOOST_PP_COMMA_IF(BOOST_PP_DEC(i_))
              BOOST_PP_ENUM_PARAMS(BOOST_PP_DEC(i_), typename CF::item)
            > type;
    };
};

template<>
struct pop_front_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
    {
        typedef BOOST_PP_CAT(cf,BOOST_PP_DEC(i_))<
              BOOST_PP_ENUM_SHIFTED_PARAMS(i_, typename CF::item)
            > type;
    };
};


template<>
struct push_back_impl< aux::cf_tag<BOOST_PP_DEC(i_)> >
{
    template< typename CF, typename T > struct apply
    {
        typedef BOOST_PP_CAT(cf,i_)<
              BOOST_PP_ENUM_PARAMS(BOOST_PP_DEC(i_), typename CF::item)
              BOOST_PP_COMMA_IF(BOOST_PP_DEC(i_))
              T
            > type;
    };
};

template<>
struct pop_back_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
    {
        typedef BOOST_PP_CAT(cf,BOOST_PP_DEC(i_))<
              BOOST_PP_ENUM_PARAMS(BOOST_PP_DEC(i_), typename CF::item)
            > type;
    };
};

#endif // i_ > 0

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION) \
    && !defined(BOOST_MPL_CFG_NO_NONTYPE_TEMPLATE_PARTIAL_SPEC)

template< typename V >
struct v_at<V,i_>
{
    typedef typename V::BOOST_PP_CAT(item,i_) type;
};

#else

namespace aux {
template<> struct v_at_impl<i_>
{
    template< typename V_ > struct result_
    {
        typedef typename V_::BOOST_PP_CAT(item,i_) type;
    };
};
}

template<>
struct at_impl< aux::cf_tag<i_> >
{
    template< typename V_, typename N > struct apply
    {
        typedef typename aux::v_at_impl<BOOST_MPL_AUX_VALUE_WKND(N)::value>
            ::template result_<V_>::type type;
    };
};

#if i_ > 0
template<>
struct front_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
    {
        typedef typename CF::item0 type;
    };
};

template<>
struct back_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
    {
        typedef typename CF::back type;
    };
};

template<>
struct empty_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
        : false_
    {
    };
};
#endif

template<>
struct size_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
        : long_<i_>
    {
    };
};

template<>
struct O1_size_impl< aux::cf_tag<i_> >
    : size_impl< aux::cf_tag<i_> >
{
};

template<>
struct clear_impl< aux::cf_tag<i_> >
{
    template< typename CF > struct apply
    {
        typedef cf0<> type;
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#undef i_

#endif // BOOST_PP_IS_ITERATING
