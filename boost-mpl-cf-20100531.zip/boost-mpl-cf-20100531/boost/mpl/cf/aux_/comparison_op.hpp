
#ifndef BOOST_MPL_CF_AUX_COMPARISON_OP_HPP_INCLUDED
#define BOOST_MPL_CF_AUX_COMPARISON_OP_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2000-2004
// Copyright Hal Finkel 2010
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: clear.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/equal.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/logical.hpp>
#include <boost/mpl/min_max.hpp>
#include <boost/mpl/pop_front.hpp>
#include <boost/mpl/pop_back.hpp>
#include <boost/mpl/push_back.hpp>
#include <boost/mpl/empty.hpp>
#include <boost/mpl/back.hpp>
#include <boost/mpl/front.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/cf/aux_/cf0.hpp>
#include <boost/mpl/cf/aux_/tag.hpp>
#include <boost/mpl/cf/aux_/sign.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/size_t.hpp>

#include <boost/utility/enable_if.hpp>

namespace boost { namespace mpl {
namespace aux { namespace cf {
#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

// For comparison, the numbers are normalized to a canonical form where they
// do not end with 1 or -1 (since [x, 1] = x + 1/1 = [x + 1]).

template< typename N, typename Enable = void >
struct normalize_inner
{
	typedef N type;
};

template< typename N >
struct normalize_inner< N, typename enable_if<
		is_one< typename abs< typename back< N >::type >::type >
	>::type >
{
	typedef typename pop_back< N >::type N_short;
	typedef typename pop_back< N_short>::type N_short2;
	typedef typename push_back< N_short2,
		typename plus<
			typename back< N_short >::type,
			typename back< N >::type
		>::type
	>::type type;
};

template< typename N, typename Enable = void >
struct normalize
{
	typedef typename normalize_inner< N >::type type;
};

template< typename N >
struct normalize< N, typename enable_if<
		less< typename size< N >::type, mpl::size_t<2> >
	>::type >
{
	typedef N type;
};

template< typename N, typename M, typename First = false_, typename Enable = void >
struct compare_less
{
	typedef false_ type;
};

template< typename N, typename M, typename Enable = void >
struct compare_less_inner
{
	typedef less<
		typename front< N >::type, typename front< M >::type
	> type;
};

template< typename N, typename M >
struct compare_less_inner< N, M, typename enable_if<
		equal_to< typename front< N >::type, typename front< M >::type >
	>::type >
{
	typedef typename compare_less<
		typename pop_front< M >::type, typename pop_front< N >::type
	>::type type;
};

template< typename N, typename M, typename First >
struct compare_less< N, M, First, typename enable_if<
		not_< or_< empty< N >, empty< M > > >
	>::type >
{
	typedef typename compare_less_inner< N, M >::type type;
};

template< typename N, typename M, typename First >
struct compare_less< N, M, First, typename enable_if<
		and_< empty< N >, not_< empty< M > >, not_< First > >
	>::type >
{
	typedef is_negative< typename front< M >::type > type;
};

template< typename N, typename M, typename First >
struct compare_less< N, M, First, typename enable_if<
		and_< not_< empty< N > >, empty< M >, not_< First > >
	>::type >
{
	typedef not_< is_negative< typename front< N >::type > > type;
};

template< typename N, typename M, typename First >
struct compare_less< N, M, First, typename enable_if<
		and_< empty< N >, not_< empty< M > >, First >
	>::type >
{
	typedef false_ type;
};

template< typename N, typename M, typename First >
struct compare_less< N, M, First, typename enable_if<
		and_< not_< empty< N > >, empty< M >, First >
	>::type >
{
	typedef true_ type;
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
}}

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

// equal is done element-by-element and is handled
// by the default sequence implementation.

template< long N, long M >
struct equal_to_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: equal<
		typename aux::cf::normalize< N1 >::type,
		typename aux::cf::normalize< N2 >::type
	> {};
};

template< long N, long M >
struct not_equal_to_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: not_< equal<
		typename aux::cf::normalize< N1 >::type,
		typename aux::cf::normalize< N2 >::type
	> > {};
};

template< long N, long M >
struct less_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: aux::cf::compare_less<
		typename aux::cf::normalize< N1 >::type,
		typename aux::cf::normalize< N2 >::type,
		true_
	>::type {};
};

template< long N, long M >
struct greater_equal_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: not_< typename aux::cf::compare_less<
		typename aux::cf::normalize< N1 >::type,
		typename aux::cf::normalize< N2 >::type,
		true_
	>::type > {};
};

template< long N, long M >
struct greater_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: aux::cf::compare_less<
		typename aux::cf::normalize< N2 >::type,
		typename aux::cf::normalize< N1 >::type,
		true_
	>::type {};
};

template< long N, long M >
struct less_equal_impl< aux::cf_tag<N>, aux::cf_tag<M> >
{
    template< typename N1, typename N2 > struct apply
	: not_< typename aux::cf::compare_less<
		typename aux::cf::normalize< N2 >::type,
		typename aux::cf::normalize< N1 >::type,
		true_
	>::type > {};
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
}}

#endif // BOOST_MPL_CF_AUX_COMPARISON_OP_HPP_INCLUDED
