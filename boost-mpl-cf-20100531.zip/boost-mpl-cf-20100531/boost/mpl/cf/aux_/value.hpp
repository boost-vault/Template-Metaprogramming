// Copyright (C) 2010 Hal Finkel
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_MPL_CF_AUX_VALUE_HPP
#define BOOST_MPL_CF_AUX_VALUE_HPP

#include <limits>
#include <boost/preprocessor/arithmetic/dec.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/control/if.hpp>
#include <boost/preprocessor/repetition/repeat_from_to.hpp>

#include <boost/mpl/aux_/config/force_inline.hpp>
#include <boost/mpl/at.hpp>

#define BOOST_MPL_CF_MAKE_VALUE_ACCESSORN(unused1,j_,unused2) + V(1)/(V(at_c<type, BOOST_PP_INC(j_)>::type::value)
#define BOOST_MPL_CF_MAKE_VALUE_ACCESSORE(unused1,unused2,unused3) )
#define BOOST_MPL_CF_MAKE_VALUE_ACCESSORP(j_) V(at_c<type, 0>::type::value) \
		BOOST_PP_REPEAT(j_,BOOST_MPL_CF_MAKE_VALUE_ACCESSORN,unused) \
		BOOST_PP_REPEAT(j_,BOOST_MPL_CF_MAKE_VALUE_ACCESSORE,unused)
#define BOOST_MPL_CF_MAKE_VALUE_ACCESSOR(j_) \
	template <typename V> \
	static MPL_FORCEINLINE V value() \
	{ \
		return \
			BOOST_PP_IF(j_,BOOST_MPL_CF_MAKE_VALUE_ACCESSORP(BOOST_PP_DEC(j_)),std::numeric_limits<V>::infinity()); \
	} \
	/**/

#endif // BOOST_MPL_CF_AUX_VALUE_HPP

