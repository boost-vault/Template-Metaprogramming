
#ifndef BOOST_MPL_CF_AUX_TAG_HPP_INCLUDED
#define BOOST_MPL_CF_AUX_TAG_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2000-2004
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: tag.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#include <climits>
#include <boost/config.hpp>
#include <boost/mpl/aux_/nttp_decl.hpp>

namespace boost { namespace mpl { namespace aux {

struct v_iter_tag;

template< BOOST_MPL_AUX_NTTP_DECL(long, N) > struct cf_tag
{
	BOOST_STATIC_CONSTANT(int, value = 0);
};

} // namespace aux

#if defined(BOOST_HAS_LONG_LONG)

typedef long long cf_element_value_type;

#if defined(BOOST_MPL_PREPROCESSING_MODE)
#undef LLONG_MAX
#endif

static const cf_element_value_type cf_element_dummy_value = LLONG_MAX;
static const cf_element_value_type cf_element_value_max = cf_element_dummy_value - 1LL;

#elif defined(BOOST_HAS_MS_INT64)

typedef __int64 cf_element_value_type;

#if defined(BOOST_MPL_PREPROCESSING_MODE)
#undef _I64_MAX
#endif

static const cf_element_value_type cf_element_dummy_value = _I64_MAX;
static const cf_element_value_type cf_element_value_max = cf_element_dummy_value - 1i64;

#else

typedef long cf_element_value_type;

#if defined(BOOST_MPL_PREPROCESSING_MODE)
#undef LONG_MAX
#endif

static const cf_element_value_type cf_element_dummy_value = LONG_MAX;
static const cf_element_value_type cf_element_value_max = cf_element_dummy_value - 1L;

#endif

}}

#endif // BOOST_MPL_CF_AUX_TAG_HPP_INCLUDED
