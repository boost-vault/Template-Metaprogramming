
#ifndef BOOST_MPL_CF_AUX_SIGN_HPP_INCLUDED
#define BOOST_MPL_CF_AUX_SIGN_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2000-2004
// Copyright Hal Finkel 2010
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: clear.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/logical.hpp>
#include <boost/mpl/min_max.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/size_t.hpp>

#include <boost/config.hpp>
#include <boost/utility/enable_if.hpp>

#include <limits>

namespace boost { namespace mpl {
namespace aux { namespace cf {

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< typename X >
struct is_zero : equal_to< X, integral_c< typename X::value_type, 0 > > {};

template< typename X >
struct is_one : equal_to< X, integral_c< typename X::value_type, 1 > > {};

template< typename X >
struct is_positive : greater< X, integral_c< typename X::value_type, 0 > > {};

template< typename X >
struct is_negative : less< X, integral_c< typename X::value_type, 0 > > {};

template< typename X, typename Enable = void >
struct sign
{
	typedef integral_c< typename X::value_type, 0 > type;
};

template< typename X >
struct sign< X, typename enable_if<
		is_positive< X >
	>::type >
{
	typedef integral_c< typename X::value_type, 1 > type;
};

template< typename X >
struct sign< X, typename enable_if<
		and_<
			is_negative< X >,
			bool_< std::numeric_limits< typename X::value_type >::is_signed >
		>
	>::type >
{
	typedef integral_c< typename X::value_type, -1 > type;
};

template< typename X, typename Y >
struct same_sign : equal_to< typename sign< X >::type, typename sign< Y >::type > {};

template< typename X, typename Enable = void >
struct abs
{
	typedef X type;
};

template< typename X >
struct abs< X, typename enable_if<
		is_negative< X >
	>::type >
{
	typedef typename negate< X >::type type;
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

} // namespace cf
} // namespace aux
}}

#endif // BOOST_MPL_CF_AUX_SIGN_HPP_INCLUDED

