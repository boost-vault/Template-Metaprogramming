
#ifndef BOOST_MPL_CF_HPP_INCLUDED
#define BOOST_MPL_CF_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2000-2004
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: cf.hpp 49239 2008-10-10 09:10:26Z agurtovoy $
// $Date: 2008-10-10 05:10:26 -0400 (Fri, 10 Oct 2008) $
// $Revision: 49239 $

#if !defined(BOOST_MPL_PREPROCESSING_MODE)
#   include <boost/mpl/limits/cf.hpp>
#   include <boost/mpl/aux_/na.hpp>
#   include <boost/mpl/aux_/config/preprocessor.hpp>

#   include <boost/preprocessor/inc.hpp>
#   include <boost/preprocessor/cat.hpp>
#   include <boost/preprocessor/stringize.hpp>

#if !defined(BOOST_NEEDS_TOKEN_PASTING_OP_FOR_TOKENS_JUXTAPOSING)
#   define AUX778076_CF_HEADER \
    BOOST_PP_CAT(cf, BOOST_MPL_LIMIT_CF_SIZE).hpp \
    /**/
#else
#   define AUX778076_CF_HEADER \
    BOOST_PP_CAT(cf, BOOST_MPL_LIMIT_CF_SIZE)##.hpp \
    /**/
#endif

#   include BOOST_PP_STRINGIZE(boost/mpl/cf/AUX778076_CF_HEADER)
#   undef AUX778076_CF_HEADER
#endif

#include <boost/mpl/aux_/config/use_preprocessed.hpp>

#if !defined(BOOST_MPL_CFG_NO_PREPROCESSED_HEADERS) \
    && !defined(BOOST_MPL_PREPROCESSING_MODE)

#   define BOOST_MPL_PREPROCESSED_HEADER cf.hpp
#   include <boost/mpl/aux_/include_preprocessed.hpp>

#else

#   include <boost/mpl/limits/cf.hpp>

#   define AUX778076_SEQUENCE_NAME cf
#   define AUX778076_SEQUENCE_LIMIT BOOST_MPL_LIMIT_CF_SIZE
#   include <boost/mpl/aux_/sequence_wrapper.hpp>

#endif // BOOST_MPL_CFG_NO_PREPROCESSED_HEADERS

#include <boost/mpl/cf/aux_/numeric_cast.hpp>
#include <boost/mpl/cf/aux_/arithmetic_op.hpp>
#include <boost/mpl/cf/aux_/negate.hpp>
#include <boost/mpl/cf/aux_/comparison_op.hpp>

#endif // BOOST_MPL_CF_HPP_INCLUDED
