/*
    Copyright 2005-2007 Adobe Systems Incorporated
   
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

/*************************************************************************************************/

#ifndef BOOST_MPL_AUX_CONFIG_FORCE_INLINE_HPP
#define BOOST_MPL_AUX_CONFIG_FORCE_INLINE_HPP

#include <boost/config.hpp>

#ifdef _DEBUG
#    define MPL_FORCEINLINE inline
#else
#ifdef NDEBUG
#if   defined(_MSC_VER)
#    define MPL_FORCEINLINE __forceinline
#elif defined(__GNUC__) && __GNUC__ > 3
#    define MPL_FORCEINLINE inline __attribute__ ((always_inline))
#else
#    define MPL_FORCEINLINE inline
#endif
#else
#    define MPL_FORCEINLINE inline
#endif
#endif

#endif // BOOST_MPL_AUX_CONFIG_FORCE_INLINE_HPP

