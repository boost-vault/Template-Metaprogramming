//range_c for enumerations which can include all of the enumeration
#ifndef BOOST_MPL_RANGE_ALL_HPP_INCLUDED
#define BOOST_MPL_RANGE_ALL_HPP_INCLUDED
#include "boost/mpl/limits_c.hpp"
#include <boost/mpl/aux_/range_c/tag.hpp>
#include <boost/mpl/aux_/range_c/iterator.hpp>

namespace boost{ namespace mpl{

  template
  < typename Tstart
  , typename Tfinish
  >
struct range_partial
{
    typedef aux::half_open_range_tag tag;
    typedef typename Tstart::value_type value_type;

    typedef Tstart start;
    typedef Tfinish finish;
    typedef r_iter<start> begin;
    typedef r_iter<finish> end;
};

//minus specializations:
//  These are needed to get mpl::size to work
//  on range_partial.
//
template<typename T, T Tfinish, T Tstart>
struct minus<limits_c<T,Tfinish>,limits_c<T,Tstart> >
  : minus<integral_c<unsigned,Tfinish>,integral_c<unsigned,Tstart> >
{
};

template<typename T, T Tstart>
struct minus< limits_end<T>, limits_c<T,Tstart> >
  : minus< integral_c<unsigned,limits_end<T>::value>, integral_c<unsigned,Tstart> >
{
};

  template
  < typename T
  , T Start
  , T Finish
  >
struct range_open_c
  : range_partial<limits_c<T, Start>, limits_c<T, Finish> >
/**@brief
 * Range from Start to Finish-1.
 */
{
    typedef range_open_c type;
};

  template
  < typename T
  , T Start
  >
struct range_c_max
  : range_partial<limits_c<T, Start>, limits_end<T> >
/**@brief
 * Range from Start to max element of T.
 */
{
    typedef range_c_max type;
};

  template
  < typename T
  >
  struct
range_all
  : range_partial< typename next<limits_rend<T> >::type, limits_end<T> >
/**@brief
 * Range including all elements in T.
 */
{
    typedef range_all type;
};

}}//exit boost::mpl namespace
#endif
