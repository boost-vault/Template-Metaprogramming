//integral_c for enumerations
#ifndef BOOST_MPL_LIMITS_C_HPP_INCLUDED
#define BOOST_MPL_LIMITS_C_HPP_INCLUDED
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/deref.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/aux_/largest_int.hpp>

namespace boost{ namespace mpl{

  template
  < typename T
  , T Tvalue
  >
struct limits_c
  : integral_c<T,Tvalue>
/**@brief
 *  integral_c where next and prior have "limits".
 *  See next and prior specializations on limits_c.
 */
{
};

template< typename T>
struct min_limit_c
/**@brief
 *  Enable the lazy evaluation used in next<limits_rend<T> >.
 */
{
    typedef limits_c<T,aux::integral_rank<T>::min_limit> type;
};

  template
  < typename T
  >
struct limits_end
/**@brief
 *  one after the max value of T.
 */
{
    typedef limits_end type;
    typedef T value_type;
    typedef integral_c_tag tag;

        static 
      typename aux::integral_rank<T>::diff_type const
    value=aux::integral_rank<T>::max_limit+1
    ;
};
  
  template
  < typename T
  >
struct limits_rend
/**@brief
 *  one before the min value of T.
 */
{
    typedef T value_type;
    typedef integral_c_tag tag;
    
        static 
      typename aux::integral_rank<T>::diff_type const
    value=aux::integral_rank<T>::min_limit-1
    ;
};

  template
  < typename T
  , T Tvalue
  >
struct next
  < limits_c
    < T
    , Tvalue
    > 
  >
{
    typedef limits_c<T,T(Tvalue+1)> type;
};

  template
  < typename T
  >
struct next
  < limits_c
    < T
    , aux::integral_rank<T>::max_limit
    > 
  >
{
    typedef limits_end<T> type;
};

  template
  < typename T
  >
struct next
  < limits_rend<T>
  >
{
        typedef 
      typename eval_if_c
      < aux::integral_rank<T>::min_limit <= aux::integral_rank<T>::max_limit
      , min_limit_c<T>
      , limits_end<T>
      >::type
    type
    ;
};

  template
  < typename T
  , T Tvalue
  >
struct prior
  < limits_c
    < T
    , Tvalue
    > 
  >
{
    typedef limits_c<T,T(Tvalue-1)> type;
};

  template
  < typename T
  >
struct prior
  < limits_c
    < T
    , aux::integral_rank<T>::min_limit
    > 
  >
{
    typedef limits_rend<T> type;
};

}}//exit boost::mpl namespace
#endif
