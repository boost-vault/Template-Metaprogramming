//define enum0..enum2 for use by some test drivers
#ifndef LIBS_MPL_TEST_ENUM0_2_HPP_INCLUDED
#define LIBS_MPL_TEST_ENUM0_2_HPP_INCLUDED
#include "boost/mpl/limits_c.hpp"
#include <boost/mpl/vector_c.hpp>
#include <iostream>

enum enum0
{ 
};

enum enum1
{ i1_0
};

enum enum2
{ i2_0
, i2_1
};

namespace boost { namespace mpl { namespace aux {

template<> struct integral_rank<enum0> : integral_rank<unsigned> 
{
    typedef unsigned diff_type;
    static diff_type const min_limit=1;
    static diff_type const max_limit=min_limit-1;
};

template<> struct integral_rank<enum1> : integral_rank<unsigned> 
{
    typedef unsigned diff_type;
    typedef enum1 limits_type;
    static limits_type const min_limit=i1_0;
    static limits_type const max_limit=i1_0;
};

template<> struct integral_rank<enum2> : integral_rank<unsigned> 
{
    typedef unsigned diff_type;
    typedef enum2 limits_type;
    static limits_type const min_limit=i2_0;
    static limits_type const max_limit=i2_1;
};

}}}

template<typename Enumeration>
struct range_expected
;

template<>
struct range_expected<enum0>
{
        typedef
      boost::mpl::vector_c
      < enum0
      >
    indices_type
    ;
};

template<>
struct range_expected<enum1>
{
        typedef
      boost::mpl::vector_c
      < enum1
      , i1_0
      >
    indices_type
    ;
};

template<>
struct range_expected<enum2>
{
        typedef
      boost::mpl::vector_c
      < enum2
      , i2_0
      , i2_1
      >
    indices_type
    ;
};

template<typename>
char const* name_enum(void)
;
template<>
char const* name_enum<enum0>(void)
{
    return "enum0";
}
template<>
char const* name_enum<enum1>(void)
{
    return "enum1";
}
template<>
char const* name_enum<enum2>(void)
{
    return "enum2";
}

  struct
print_limits_c
{
      template
      < typename T
      , T Tvalue
      >
      void
    operator()(boost::mpl::limits_c<T,Tvalue>&)const
    {
        std::cout<<name_enum<T>()<<"("<<Tvalue<<")\n";
    }
      template
      < typename T
      , T Tvalue
      >
      void
    operator()(boost::mpl::integral_c<T,Tvalue>&)const
    {
        std::cout<<name_enum<T>()<<"("<<Tvalue<<")\n";
    }
};


#include <boost/mpl/equal.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/for_each.hpp>
#include <boost/mpl/arg.hpp>

  template
  < typename Enumeration
  , typename RangeActual
  >
  bool
range_expected_is_actual
  ( void
  )
{
    using namespace boost;
    typedef typename range_expected<Enumeration>::indices_type expected_type;
    std::cout<<"range_expected_is_actual for enumeration="<<name_enum<Enumeration>()<<"\n";
    bool result = mpl::equal
      < expected_type
      , RangeActual
      , mpl::equal_to<mpl::arg<1>, mpl::arg<2> >  
      >::value;
    if(true)
    {
        print_limits_c enum_printer;
        std::cout<<"expected_type=\n";
        mpl::for_each<expected_type>(enum_printer);
        std::cout<<"RangeActual=\n";
        mpl::for_each<RangeActual>(enum_printer);
    }
    return result; 
}

#endif
