//Test range_all template.
#include "enum0_2.hpp"
#include "boost/mpl/range_all.hpp"

#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/for_each.hpp>
#include <boost/test/unit_test.hpp>

using namespace boost;

namespace test = unit_test_framework;

template<typename Enum>
void simple_test(void)
{
    std::cout<<"simple_test for Enum="<<name_enum<Enum>()<<"\n";
    typedef mpl::range_all<Enum> range_enum;
    unsigned const range_expected_size
      =mpl::aux::integral_rank<Enum>::max_limit+1
      -mpl::aux::integral_rank<Enum>::min_limit  ;
    unsigned const range_actual_size=mpl::size<range_enum>::value;
    //std::cout<<"range_expected_size="<<range_expected_size<<"\n";
    //std::cout<<"range_actual_size="<<range_actual_size<<"\n";
    typedef mpl::limits_end<Enum> lend;
    BOOST_CHECK((is_same<typename range_enum::finish,lend>::value));
    BOOST_CHECK(range_actual_size == range_expected_size);
    BOOST_CHECK((range_expected_is_actual<Enum,range_enum>()));
}    
test::test_suite* init_unit_test_suite(int argc, char* argv[])
{
    test::test_suite* test = BOOST_TEST_SUITE("range_enum tests");
    test->add(BOOST_TEST_CASE(&simple_test<enum0>));
    test->add(BOOST_TEST_CASE(&simple_test<enum1>));
    test->add(BOOST_TEST_CASE(&simple_test<enum2>));
    return test;
}
